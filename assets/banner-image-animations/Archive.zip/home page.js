(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AgCAAIAFAA");
	this.shape.setTransform(-7.9,-137.4,4.004,4.084);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AABACIgBgD");
	this.shape_1.setTransform(-30.3,137,4.004,4.084);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAEiiIgHFF");
	this.shape_2.setTransform(-25.2,71.5,4.004,4.084);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgEinIAKFP");
	this.shape_3.setTransform(23.3,69.4,4.004,4.084);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgbgUIA3Ap");
	this.shape_4.setTransform(9.6,-7.8,4.004,4.084);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("Ag1iDIBZAgIAPB1IAAB2");
	this.shape_5.setTransform(21.5,-49.6,4.004,4.084);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("ADHnIIkcgrIgvHzIg+H5");
	this.shape_6.setTransform(-22,-57.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAWivIAEBUIAADUIg1A0");
	this.shape_7.setTransform(-12.3,-65.6,4.004,4.084);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_8.setTransform(-41.8,-7.1,4.004,4.084);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_9.setTransform(-41.8,-7.1,4.004,4.084);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDADQgCACgDAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_10.setTransform(-30,-107.7,4.004,4.084);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_11.setTransform(-30,-107.7,4.004,4.084);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_12.setTransform(-35.6,-58,4.004,4.084);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHAAQAIAAAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_13.setTransform(-35.6,-58,4.004,4.084);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_14.setTransform(-23.7,5,4.004,4.084);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.498)").s().p("AgGAAQgBgHAHAAQAHAAAAAHQAAAIgHAAQgHAAABgIg");
	this.shape_15.setTransform(-23.7,5,4.004,4.084);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_16.setTransform(25.6,137.8,4.004,4.084);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgCACgBQAIABAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_17.setTransform(25.6,137.8,4.004,4.084);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_18.setTransform(-26.8,137.8,4.004,4.084);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHgBQADABADACQACACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_19.setTransform(-26.8,137.8,4.004,4.084);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_20.setTransform(-24.6,72.5,4.004,4.084);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_21.setTransform(-24.6,72.5,4.004,4.084);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCACQgDADgDAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_22.setTransform(22.8,69.3,4.004,4.084);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQADAAADADQACACAAACQAAADgCACQgDADgDAAQgHAAAAgIg");
	this.shape_23.setTransform(22.8,69.3,4.004,4.084);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCADQgDACgDAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_24.setTransform(20.8,0.7,4.004,4.084);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQAIAAAAAHQAAADgCADQgDACgDAAQgHAAAAgIg");
	this.shape_25.setTransform(20.8,0.7,4.004,4.084);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_26.setTransform(-1.6,-16.3,4.004,4.084);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgHAHABQAIgBAAAHQAAAHgIAAQgCAAgCgCg");
	this.shape_27.setTransform(-1.6,-16.3,4.004,4.084);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_28.setTransform(41.8,6.2,4.004,4.084);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_29.setTransform(41.8,6.2,4.004,4.084);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_30.setTransform(41.8,-42,4.004,4.084);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_31.setTransform(41.8,-42,4.004,4.084);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_32.setTransform(36.2,-90.2,4.004,4.084);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_33.setTransform(36.2,-90.2,4.004,4.084);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_34.setTransform(-1.6,-103.4,4.004,4.084);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_35.setTransform(-1.6,-103.4,4.004,4.084);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_36.setTransform(-3.2,-137.7,4.004,4.084);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_37.setTransform(-3.2,-137.7,4.004,4.084);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45.9,-141.9,91.9,283.8);


(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AgCAAIAFAA");
	this.shape.setTransform(-3.1,-137.4,4.004,4.084);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AABACIgBgD");
	this.shape_1.setTransform(-25.5,137,4.004,4.084);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAEiiIgHFF");
	this.shape_2.setTransform(-20.4,71.4,4.004,4.084);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgFijIALFH");
	this.shape_3.setTransform(28,70.9,4.004,4.084);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgbgUIA3Ap");
	this.shape_4.setTransform(14.4,-7.8,4.004,4.084);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("Ag1iDIBZAgIAPB1IAAB2");
	this.shape_5.setTransform(26.3,-49.6,4.004,4.084);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("ABAhmIhGgKIg1Dm");
	this.shape_6.setTransform(-22.7,-61.4,4.004,4.084);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAXiuIAEBUIAADUIg2Ay");
	this.shape_7.setTransform(-7.6,-66.2,4.004,4.084);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_8.setTransform(-46.6,-13.2,4.004,4.084);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_9.setTransform(-46.6,-13.2,4.004,4.084);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDADQgCACgDAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_10.setTransform(-25.2,-107.7,4.004,4.084);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_11.setTransform(-25.2,-107.7,4.004,4.084);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_12.setTransform(-35,-61.1,4.004,4.084);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHAAQAIAAAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_13.setTransform(-35,-61.1,4.004,4.084);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_14.setTransform(-18.9,5,4.004,4.084);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.498)").s().p("AgGAAQgBgHAHAAQAHAAAAAHQAAAIgHAAQgHAAABgIg");
	this.shape_15.setTransform(-18.9,5,4.004,4.084);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_16.setTransform(30.4,137.8,4.004,4.084);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgCACgBQAIABAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_17.setTransform(30.4,137.8,4.004,4.084);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_18.setTransform(-22,137.8,4.004,4.084);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHgBQADABADACQACACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_19.setTransform(-22,137.8,4.004,4.084);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_20.setTransform(-19.8,72.5,4.004,4.084);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_21.setTransform(-19.8,72.5,4.004,4.084);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCACQgDADgDAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_22.setTransform(27.6,69.3,4.004,4.084);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQADAAADADQACACAAACQAAADgCACQgDADgDAAQgHAAAAgIg");
	this.shape_23.setTransform(27.6,69.3,4.004,4.084);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCADQgDACgDAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_24.setTransform(25.6,0.7,4.004,4.084);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQAIAAAAAHQAAADgCADQgDACgDAAQgHAAAAgIg");
	this.shape_25.setTransform(25.6,0.7,4.004,4.084);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_26.setTransform(3.2,-16.3,4.004,4.084);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgHAHABQAIgBAAAHQAAAHgIAAQgCAAgCgCg");
	this.shape_27.setTransform(3.2,-16.3,4.004,4.084);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_28.setTransform(46.6,6.2,4.004,4.084);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_29.setTransform(46.6,6.2,4.004,4.084);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_30.setTransform(46.6,-42,4.004,4.084);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_31.setTransform(46.6,-42,4.004,4.084);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_32.setTransform(41,-90.2,4.004,4.084);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_33.setTransform(41,-90.2,4.004,4.084);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_34.setTransform(3.2,-103.4,4.004,4.084);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_35.setTransform(3.2,-103.4,4.004,4.084);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_36.setTransform(1.6,-137.7,4.004,4.084);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_37.setTransform(1.6,-137.7,4.004,4.084);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.7,-141.9,101.5,283.8);


(lib.Tween42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1BF8FE").ss(0.2).p("AgCAAIAFAA");
	this.shape.setTransform(-3.1,-137.4,4.004,4.084);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1BF8FE").ss(0.2).p("AABACIgBgD");
	this.shape_1.setTransform(-25.5,137,4.004,4.084);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.5).p("AAEiiIgHFF");
	this.shape_2.setTransform(-20.4,71.4,4.004,4.084);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.5).p("AgFijIALFH");
	this.shape_3.setTransform(28,70.9,4.004,4.084);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.5).p("AgbgUIA3Ap");
	this.shape_4.setTransform(14.4,-7.8,4.004,4.084);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(0.5).p("Ag1iDIBZAgIAPB1IAAB2");
	this.shape_5.setTransform(26.3,-49.6,4.004,4.084);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.5).p("ABAhmIhGgKIg1Dm");
	this.shape_6.setTransform(-22.7,-61.4,4.004,4.084);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAXiuIAEBUIAADUIg2Ay");
	this.shape_7.setTransform(-7.6,-66.2,4.004,4.084);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_8.setTransform(-46.6,-13.2,4.004,4.084);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_9.setTransform(-25.2,-107.7,4.004,4.084);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHAAQAAgGAHAAQAIAAAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_10.setTransform(-35,-61.1,4.004,4.084);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGAAQgBgHAHAAQAHAAAAAHQAAAIgHAAQgHAAABgIg");
	this.shape_11.setTransform(-18.9,5,4.004,4.084);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHAAQAAgCADgCQACgCACgBQAIABAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_12.setTransform(30.4,137.8,4.004,4.084);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgHAAQAAgGAHgBQADABADACQACACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_13.setTransform(-22,137.8,4.004,4.084);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_14.setTransform(-19.8,72.5,4.004,4.084);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgHAAQAAgHAHAAQADAAADADQACACAAACQAAADgCACQgDADgDAAQgHAAAAgIg");
	this.shape_15.setTransform(27.2,69.3,4.004,4.084);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgHAAQAAgHAHAAQAIAAAAAHQAAADgCADQgDACgDAAQgHAAAAgIg");
	this.shape_16.setTransform(25.6,0.7,4.004,4.084);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgEAFQgDgCAAgDQAAgHAHABQAIgBAAAHQAAAHgIAAQgCAAgCgCg");
	this.shape_17.setTransform(3.2,-16.3,4.004,4.084);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_18.setTransform(46.6,6.2,4.004,4.084);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_19.setTransform(46.6,-42,4.004,4.084);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_20.setTransform(41,-90.2,4.004,4.084);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_21.setTransform(3.2,-103.4,4.004,4.084);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_22.setTransform(1.6,-137.7,4.004,4.084);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.7,-140.9,99.5,281.8);


(lib.Tween36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2EFFFF").s().p("AgGB4QgHgDAAgHIgBg3QgVgLgOgTQgOgVgCgUIgxgUQgGgBAAgJQAAgDACgCQABgBAAAAQABAAABAAQAAAAABAAQAAAAABABIAwATQADgTAPgIQAOgJAUAFIAAg0QABgGAHACQAHAEAAAFIAAA0QAWALAOASQAOAUAEAUQAbAJAeAGQAIACAAAIQAAAHgIgCQgegFgbgJQgEATgPAKQgPAKgVgFIAAA3QAAAAAAABQAAABgBAAQAAABAAAAQAAABAAAAIgDABIgDgBg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.1,-12,24.2,24.2);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#383C40").s().p("AgDAHQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgGAFgDQABgBAAAAQABAAAAAAQABAAAAAAQABAAABAAQAAAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAAGgGADIgCABIgBAAg");
	this.shape.setTransform(1.1,-92.2,3.829,3.829);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#383C40").s().p("AhHgLQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAICOAZIABABIgBABg");
	this.shape_1.setTransform(28.6,-87.2,3.829,3.829);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#383C40").s().p("AhOBlIABgCICajGIABAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBABIiaDGIgBABg");
	this.shape_2.setTransform(-28.7,-54,3.829,3.829);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E2022").s().p("AgECGIgBkRIAKAGIABERg");
	this.shape_3.setTransform(-62.7,41.2,3.829,3.829);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B2E31").s().p("AijgqIFGi9IABESIlGC9gAiFgcIABDTIEJiZIAAjUg");
	this.shape_4.setTransform(2.1,6.2,3.829,3.829);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#303437").s().p("AioBbIFGi8IALAGIlGC8g");
	this.shape_5.setTransform(-0.2,-47.5,3.829,3.829);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D3D3D3").s().p("AiJBKIEIiZIAMAGIkKCZg");
	this.shape_6.setTransform(-0.2,-35.6,3.829,3.829);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFF9F5").s().p("AiEgcIEJiaIAADUIkJCZgAh0CVICIhPIgTgbIAoASIBGiDIgFgCQAEgNAAgLQAAgVgNgHQgNgHgSAKQgKAGgNAOIgLgEIg6BsIgWgdg");
	this.shape_7.setTransform(2,6.2,3.829,3.829);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#838383").s().p("AgEBoIgBjUIAKAGIABDTg");
	this.shape_8.setTransform(-51,34.5,3.829,3.829);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A85A24").s().p("AgnBVIBEivIALAGIhDCvg");
	this.shape_9.setTransform(-31.9,28.2,3.829,3.829);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFB740").s().p("AAAhXIAVAeIgLAWIAoASIATAaIiJBPg");
	this.shape_10.setTransform(-16.5,29.5,3.829,3.829);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7B7B7B").s().p("AAFAMIgUgeIAKAHIAVAdg");
	this.shape_11.setTransform(-14.6,0.4,3.829,3.829);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D3D3D3").s().p("AhJAkICIhOIALAHIiIBOg");
	this.shape_12.setTransform(-18.7,46.8,3.829,3.829);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#329C99").s().p("AgiA0IA6htIALAHIg6Bsg");
	this.shape_13.setTransform(1,-14.7,3.829,3.829);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#AED051").s().p("AhKAvIBHiBIAJAEQgUAcAAAbQABAVAMAHQAMAHASgLQANgGALgOQALgPAFgQIAGADIhHCCg");
	this.shape_14.setTransform(16,-2.5,3.829,3.829);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#303437").s().p("AiKBKIEJiZIAMAHIkKCYg");
	this.shape_15.setTransform(0.1,45.8,3.829,3.829);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#329C99").s().p("AgKAIIAKgVIALAGIgLAVg");
	this.shape_16.setTransform(-12.5,10.3,3.829,3.829);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FD0B22").s().p("AgeA2QgNgIAAgVQAAgbAVgbQANgPAJgFQASgLANAIQANAHAAAVQAAAKgEANQgGAPgKAPQgLAOgNAHQgKAGgJAAQgGAAgFgCg");
	this.shape_17.setTransform(27.2,-21.1,3.829,3.829);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E1B039").s().p("AgPAGQALgLAJgHIALAHQgKAFgKANg");
	this.shape_18.setTransform(21,-38.1,3.829,3.829);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#C09730").s().p("AgMAJQAFgLAHgKIACgCIALAGIgCACQgIAKgEALg");
	this.shape_19.setTransform(14.1,-30,3.829,3.829);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#A07D26").s().p("AABAbQgMgHAAgUQAAgPAIgSIAKAHQgHARAAAPQAAAUAMAIg");
	this.shape_20.setTransform(10.6,-13.8,3.829,3.829);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#C09730").s().p("AgCADIgLgGQAJgCAHAEIALAGQgIgEgIACg");
	this.shape_21.setTransform(33.4,-43.5,3.829,3.829);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E1B039").s().p("AgLAAQAFgDAHgCIALAFQgHACgFAEg");
	this.shape_22.setTransform(27.6,-42.7,3.829,3.829);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#999999").s().p("AgDAWQAEgMAAgKQAAgUgMgIIALAGQAMAIAAATQAAALgEANg");
	this.shape_23.setTransform(39.6,-32.8,3.829,3.829);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3BBBB8").s().p("AgWAJQAIgCAFgEQAKgFALgMIALAGQgLAMgLAGQgGAEgGABg");
	this.shape_24.setTransform(26.7,-5.6,3.829,3.829);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#34A19E").s().p("AgCACIgLgFQAIADAIgBIALAFIgGAAQgGAAgEgCg");
	this.shape_25.setTransform(16.7,-1.3,3.829,3.829);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#7B7B7B").s().p("AAEAKIgSgaIALAHIASAag");
	this.shape_26.setTransform(4,26.5,3.829,3.829);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1E2022").s().p("AgEBnIgBjUIAKAGIABDVg");
	this.shape_27.setTransform(50.8,-24.3,3.829,3.829);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B8683").s().p("AgHACIAEgJIALAGIgFAJg");
	this.shape_28.setTransform(39.6,-21.2,3.829,3.829);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#34A19E").s().p("AgMAJQAJgKAFgNIALAGQgFALgJAMg");
	this.shape_29.setTransform(36.1,-14.8,3.829,3.829);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3BBBB8").s().p("AgWAJQAIgCAFgEQAKgFALgMIALAGQgLAMgLAGQgGAEgGABg");
	this.shape_30.setTransform(26.7,-5.6,3.829,3.829);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#B2B2B2").s().p("AgoA+IBGiCIALAGIhGCDg");
	this.shape_31.setTransform(29,3.2,3.829,3.829);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-94.9,129.8,189.9);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgKgjIAcAIIAAA5IgjAGg");
	this.shape.setTransform(0,0,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.4,-13,12.8,26.1);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFF9F5").s().p("AguAoQgCgDADgFQAEgJAJgKIAQgQQAVgXAAgQQAQADAPgBQAIgBADgCQABACgBAEIgDAqQgXATgPAIQgWAMgVAAQgIgBgBgDg");
	this.shape.setTransform(0,0,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.2,-15.9,34.5,31.9);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgSgkIAdAFIAIA4IghAMg");
	this.shape.setTransform(0,0,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.8,-13.1,13.7,26.3);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFF9F5").s().p("AgpAvQgCgCABgGQADgKAIgLIANgSQAJgNAEgGQAFgMgBgLQAQACAOgEQAIgBACgDQACACAAAEIACAqQgWAXgMAJQgUAQgVACQgIAAgBgDg");
	this.shape.setTransform(0,0,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.5,-17.8,31.1,35.6);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgIAeQgKgEgEgPQAAgFACgGQAFgQAOgOIAYAJIAAAcQABAEgDADQgEAEgEgHIgCgMIgDAMQgDAOgDAFQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgHgBg");
	this.shape.setTransform(0,0,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.4,-11.3,16.8,22.6);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#142849").s().p("Ah1G6IgHsdQAMhCBBgbQAhgNAdAAQBPAYAYBCQALAhgGAcQhBGcgeFog");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.5,-46.1,25.1,92.3);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#142849").s().p("AgxHGQgrgCgjggQgwgoADhGIAzp8QAJhdBagbQBZgbA3BLQAvA9AEBgQACAwgIAiQgMAvhGHBQgJAygkAjQgkAggrAAIgKAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.3,-45.4,34.6,90.9);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#143151").s().p("AgSGqQhWnwgYjfQgFhGAxgmQAbgVAngDIBFALQBFAZACBDIAHLsg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.9,-42.5,25.8,85.1);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#143151").s().p("AgYHUQg6gSgShNQgch3gSluIgPlWQDVgXBKAFQAmACgHAHQAMCAgQKyQgDAvgWAcQgiAxhDgHQgJACgKAAQgPAAgRgGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-47.3,32.4,94.8);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#143151").s().p("AhtDcQimgZgci3IAFizIDYg/QAQgGB0AHIBzAIIBDAbQBCAuAGBsQADBdhkBUQhZBKhoAUQgJACgNAAQgkAAhBgNg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-23.3,60.8,46.7);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5E63").s().p("AAMBbQgNgEgEgNIgch5QgHgTAOgQIADgDQALgIAMAEQAOADAGANIAQCKQABAKgIAJQgGAHgHAAIgEAAg");
	this.shape.setTransform(0,0,3.443,3.443);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.5,-31.5,25.1,63);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgDAdQgJgBAAgEQgBgFADgKIADgJQgGAJgCABQgHAEgBgFQgBgEACgDIAMgTIAGgLIAaAAQAEAWgEAPQgDAIgDADQgJAJgIAAIgCAAg");
	this.shape.setTransform(0,0,3.443,3.443);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.3,-10,16.6,20.1);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5E63").s().p("AgJBJIgMh/QAAgNAJgGIAJgDQAOgCAHAJQADAEAAAEIABCKg");
	this.shape.setTransform(0,0,3.443,3.443);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.4,-26.6,15,53.2);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.8)").s().p("EgBQAl+QAAAAgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIA7ABQABAAAAAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAIg8gBgEAAlAl9QgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABgBIA8gBQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAIg8ACQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAgBAAAAgEgCLAl7Ig8gDQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQgBgBABAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAIA7ADQABABAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIgDACIAAgBgEACdAl5QgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABgBIA8gEQAAAAABAAQAAAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIg8AEIAAABIgDgCgEgECAlzIg8gGQgBgBAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAIA8AHQAAAAAAAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgDABIAAAAgEAEVAlvQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAIA7gIQABAAAAAAQABAAAAABQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIg8AHIgBABIgDgCgEgF5AllIg7gKQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAIA7AKQABAAAAAAQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgEABIAAAAgEAGNAlgQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAIA7gKQAAAAABAAQAAAAABABQAAAAABAAQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAQgBABAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAIg7AKIAAAAIgDgBgEgHvAlQIg6gMQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQABgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAAAAAIA7AMQABABAAAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBAAAAABIgDABIgBgBgEAIDAlLQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABgBQAAAAABAAIA6gNQABAAAAAAQAAAAABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQAAAAgBABIg7AMIgBAAIgCgBgEgJkAk2Ig6gPQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAIA6APQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAAAABIgDAAIgBAAgEAJ4AkwQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAAAAAQABgBAAAAIA6gQQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABQABAAAAABQgBAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBABAAAAIg6AQIgCAAIgCgBgEgLXAkXIg6gSQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAIA5ASQAAAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAIgCABIgBAAgEALsAkPQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAIA4gTQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQABAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAIg4ATIgCABIgCgBgEgNJAjxIg4gVQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAIA4AVQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIgDAAIgBAAgEANcAjoQAAAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAIA3gWQABAAAAAAQABAAAAAAQABAAAAAAQABAAABAAQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAAAAAIg5AWIgBABIgDgBgEgO4AjFIg3gYQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABgBAAAAQABABAAAAQABAAAAAAIA2AYQABAAAAAAQABABAAAAQAAAAABABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIgBAAIgCAAgEAPMAi7QAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAIA3gZQAAAAAAAAQABAAAAgBQABAAAAABQABAAAAAAQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAABABAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAIg2AZIgCAAIgCAAgEgQlAiTIg1gbQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAIA2AbQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABgBAAIgBAAIgDgBgEAQ5AiIQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQABAAAAgBIA2gbQAAAAABAAQAAAAABgBQAAAAABABQAAAAABAAQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABQgBAAAAAAQAAABgBAAIg1AbIgCABIgCAAgEgSPAhcIg0geQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABIAzAdQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgCAAIgCAAgEASjAhPQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBIA0geQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAAAAAAAIg0AfIgCAAIgCAAgEgT2AgfIgyggQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAgBAAAAQABAAAAAAQABABAAAAQABAAAAAAIAzAhQAAAAAAAAQABABAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQAAABgBAAIgBAAIgDgBgEAUKAgSQgBgBAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBAAAAQABgBAAAAQAAAAABgBIAyghQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQAAAAgBABIgyAhIgCABIgBAAgA1afdIgwgjQgBAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAAAIAxAjQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAIgBAAIgDgBgAVtfOQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAwgjQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABABAAAAQABAAAAAAQAAAAABABQAAAAABABQAAAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgxAkIgDABIAAAAgA26eWIgvglQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAgBAAQAAgBABgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAABAAIAuAlQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBABIgDgCgAXMeGQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAIAvglQAAgBABAAQAAAAABAAQAAAAAAAAQABgBABAAQAAABAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAIguAmIgDABIgBAAgA4XdKIgtgnQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAIAtAoQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQABABgBAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAABIgBAAIgDgCgAYoc6QAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBIAtgnQAAgBABAAQAAAAAAAAQABAAAAAAQABgBAAABQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIgsAoIgDABIgBAAgA5wb7IgrgqQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQABgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAABIArAoQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQABAAgBABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAAIgDgBgAZ9boQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBIArgpQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAgBQABABAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAABAAQgBABAAAAQAAABAAAAQAAABAAAAQgBABAAAAIgrApQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBgA7NagIgqgrQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABgBQABABAAAAQAAAAABAAQAAAAABAAQAAABAAAAIAqArQAAAAABABQAAAAAAABQAAAAAAABQAAAAABABQgBAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAgAbPaXQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBIArgsQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAgBQABAAAAABQABAAAAAAQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAABABAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABgBAAIgqAtQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQgBAAAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAgA8cZKQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAAAIgogtQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABgBAAAAQABABAAAAQABAAAAAAQABAAAAABQAAAAABAAIAnAtQABABAAAAQAAAAAAABQAAAAAAABQABAAAAABQgBAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgDACIgBgBgAciY+QAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBABAAIAnguQABAAAAAAQAAgBABAAQAAAAABAAQAAAAAAgBQABAAABABQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgoAtQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAIgBAAIgDgBgA9qXvQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAAAIgmgvQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABABAAIAkAuQABABAAAAQAAABAAAAQAAAAAAABQABAAgBABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgEACIAAgBgAdwXiQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAIAlgvQABgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAIgkAwQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAIgBAAIgDgBgA+zWSQgBgBAAAAQgBAAAAAAQAAAAgBgBQAAAAgBAAIgjgxQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAAAQAAABAAAAIAkAxQAAAAAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgEABIAAAAgAe5WCQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAIAjgxQABAAAAgBQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABIgkAxQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAIAAAAIgEgBgA/4UwQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAAAgBIghgyQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAAAQABABAAAAQAAAAABABIAgAyQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBAAAAABIgDABIgBAAgAf+UgQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIAggzQABAAAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABIghAyQAAABAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAIgBABIgDgBgEgg4ATKQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAIgeg0QAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAIAeA0QAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIgCAAIgCAAgEAg+AS6QAAgBgBAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAeg1QAAAAAAAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAgBABIgdA0QgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgCAAIgCAAgEghzARiQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAAAAAgBIgbg1QgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAIAbA2QAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAIgCABIgCAAgEAh4ARQQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAbg2QAAgBAAAAQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQgBABAAAAQAAABAAAAIgbA2QAAABAAAAQAAAAgBABQAAAAgBAAQAAABAAAAIgCAAIgCgBgEginAP2QgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAIgYg3QAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAAAQAAABABAAQAAABAAAAIAYA2QAAABAAAAQAAABABAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABQAAAAAAAAIgDABIgBgBgEAisAPkQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBIAYg3QAAAAAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAABIgYA3QgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAIgCABIgCgBgEgjWAOIQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAIgVg4QAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIAWA4QAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgCAAIgCgBgEAjbAN2QgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBIAVg4QAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAABQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABABAAQAAABgBAAQAAABAAAAIgVA5QAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAABIgDAAIgBAAgEgj/AMYQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBIgSg5QAAAAAAgBQgBAAAAgBQABAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABIATA5QAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAIgCABIgCgBgEAkEAMFQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIASg6QAAAAABgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAgBQABAAAAABQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIgSA5QAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAIgCABIgBAAgEgkjAKlQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIgQg6QAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABIAPA6QAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgCAAIgCgBgEAkmAKRQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAOg6QAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIgPA6QAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIgCAAIgCAAgEglBAIxQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBIgMg6QAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAIAMA6QAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQAAAAgBABIgBAAIgDgBgEAlDAIdQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBIAMg7QAAAAAAgBQABAAAAgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAAAQABABAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAAAAAABIgLA7QgBABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAIgCABIgBAAgEglYAG7QAAAAgBgBQAAAAAAAAQAAgBgBAAQAAgBAAAAIgKg7QAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAAAQABABAAAAQABABAAAAQAAAAAAABQAAAAAAABIAKA6QAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAIgBAAIgDgBgEAlZAGmQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAIAIg7QAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAIgJA7QAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgEACIAAgBgEglpAFFQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAgBIgGg7QgBgBABgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAABAAIAGA8QAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAIAAAAIgDgBgEAlpAEwQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAIAFg8QABAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAABAAQAAgBABABQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQABAAgBABIgFA8QgBAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAIgDABIgBAAgEgl1ADNQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBgBAAIgDg8QgBgBABAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABgBAAABQABAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABABAAIADA8QABABgBAAQAAABAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAIAAABIgEgCgEAl0AC5QgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIADg8QABgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQABABgBAAIgDA8QAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgDABIAAAAgEgl7ABVQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAIgBg8QAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABgBQABABAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABIABA8QAAAAAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAQAAAAgBAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAgBAAAAgEAl2ABAQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBAAAAgBIABg8IAAAAIAAgcQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQABAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAAAIAAAcIAAAAIAAA8QgBABAAAAQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAgEgl8gAmQAAAAgBAAQAAgBAAAAQAAgBAAAAQgBAAAAgBIACg8QAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABgBAAABQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABIgBA7QgBABAAAAQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBgEAl1gBUQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAgBgBIgCg8QAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABgBQAAAAABABQAAAAABAAQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAIACA9QABAAgBABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAAIgDgBgEgl0gCbQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIAEg8QABgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQABAAAAABIgFA7QAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgDABIAAAAgEAlvgDNQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgFg8QgBgBABgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAAAIAGA9QAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBABIAAAAIgDgCgEglqgESQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAgBIAHg7QAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAABABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAIgHA7QAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgDABIAAAAgEAljgFFQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIgJg8QAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAABIAJA7QAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAIgBAAIgDgBgEglbgGIQgBgBAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAIAKg7QAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABIgJA6QgBABAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgEABIAAAAgEAlRgG8QAAAAgBAAQAAAAAAgBQAAAAgBgBQAAAAAAAAIgMg8QAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABIAMA8QAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBABIgDgCgEglGgH+QgBAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBIANg6QAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABIgNA6QAAABAAAAQgBAAAAABQAAAAAAABQgBAAAAAAIgDABIgBAAgEAk5gIyQAAAAgBAAQAAgBAAAAQAAgBgBAAQAAAAAAgBIgOg6QAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAAAQABABAAAAIAOA7QAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAIgBAAIgDgBgEgkrgJzQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAQg6QAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIgPA5QAAABgBAAQAAABAAAAQAAAAgBABQAAAAgBAAIgCABIgBAAgEAkcgKnQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIgRg5QAAAAAAgBQgBAAAAgBQABAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABIARA6QAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgCAAIgCgBgEgkLgLmQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBIATg5QAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABIgTA5QAAAAAAAAQAAABgBAAQAAABAAAAQgBAAAAABIgCAAIgCAAgEAj5gMaQgBAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAIgUg5QAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIAVA5QAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAIgCAAIgCgBgEgjkgNYQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAWg4QAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABIgVA3QAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAIgCABIgCgBgEAjOgOKQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIgYg4QAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAABgBQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABIAYA3QAAAAAAABQABAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABIgCAAIgCAAgEgi3gPHQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAZg2QAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQgBABAAAAQAAABAAAAIgZA3QAAAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAIgCABIgCgBgEAiegP5QAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAgBgBIgag1QAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABgBQAAAAABABQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIAaA3QABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAIgCABIgCgBgEgiEgQzQgBgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIAbg2QAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQABAAAAABQgBAAAAABQAAAAAAABIgbA1QgBABAAAAQAAAAgBABQAAAAgBAAQAAABAAAAIgCAAIgCAAgEAhpgRkQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBIgdg0QAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAIAdA1QAAAAAAABQAAAAABABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAIgCABIgCAAgEghMgSeQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAfgzQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAIgeA1QgBAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgCAAIgCgBgEAgugTMQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAIggg0QgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABAAQABABAAAAQAAAAABAAQAAABABAAQAAAAAAABIAgAzQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAAAAAAAIgDABIgBAAgEggOgUFQAAAAgBAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBIAhgyQAAAAAAgBQABAAAAAAQABAAAAgBQAAAAABAAQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAABABAAQAAAAAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBABIghAyQAAAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAIgBAAIgDgBgAft0yQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAIgigxQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABgBQAAAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABABAAAAQABAAAAAAQAAAAABABQAAAAABAAIAiAyQABABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAABAAAAQgBAAAAABQAAAAAAABQgBAAAAAAIgDABIgBAAgA/L1oQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAIAkgxQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAAAQABABAAAAQABABAAAAQAAAAAAABQAAAAABABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAIgjAxQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAIgBAAIgDgBgAen2UQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAIgkgwQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABgBQAAAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAQABABAAAAQABAAAAAAQAAAAABABQAAAAABABIAkAvQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgDABIgBAAgA+D3IQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAIAmgvQABAAAAAAQAAgBABAAQAAAAABAAQAAAAAAAAQABgBABABQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgmAuQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAIAAAAIgDgBgAde3yQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBIgmgtQgBgBAAAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQABAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAABABAAQAAAAABAAQAAAAABABQAAAAAAAAIAnAuQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgDABIAAAAgA824lQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBIApgtQAAgBABAAQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABQAAAAAAAAQAAABgBAAIgoAuQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBABIAAAAIgDgCgAcQ5NQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAIgpgsQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABgBQABABAAAAQAAAAABAAQAAAAABAAQAAABAAAAIAqAsQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIgDACIAAgBgA7l5+QAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAABAAIArgtQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAIgrAtQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAAIgDgBgAa66lIgKgKIgdgdQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQABgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABgBQAAABAAAAQABAAAAAAQABAAAAAAQABABAAAAIAdAdIAKAKQAAAAABABQAAAAAAABQAAAAAAABQAAAAABAAQgBABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBABQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAgA6Q7VQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBIAsgpQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgrAoQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBgAZn71IgsgoQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAIAtAoQAAABABAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAAIgDgBgA418kQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBIAugnQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABIgtAnIgDABIgBAAgAYN9FIgugmQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABABAAAAIAvAnQAAAAAAAAQABABAAAAQAAABAAAAQAAABABAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAABIAAAAIgEgCgA3a9xQAAAAgBAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAIAvgkQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAABIgvAkIgDABIgBAAgAWv+RIgwgkQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAIAxAkQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAQgBABAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAIAAABIgEgCgA17+5QAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAIAxgiQABgBAAAAQABAAAAAAQABgBAAAAQAAAAABABQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBAAAAABIgxAiIgDABIgBAAgAVO/YIgxghQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAAAAAQABgBAAAAQABAAAAAAQABABAAAAQABAAAAAAIAyAiQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAIgBAAIgDgBgA0Z/9QAAAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQABgBAAAAQAAAAAAgBQABAAAAgBQAAAAABAAIAzggQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAAAgBAAIgyAgIgCABIgCAAgEATqggaIgzgfQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABIA0AfQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAABAAAAIgCAAIgCgBgEgSzgg8QAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIA0geQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIg0AdIgCABIgCAAgEASCghWIg1gdQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAIA2AdQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQABABAAAAQgBABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAIgCABIgCgBgEgRKgh2QgBAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBgBAAQAAgBABAAQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAIA2gaQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAgBABIg1AaIgCABIgCgBgEAQXgiOIg2gZQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABgBAAAAQABABAAAAQABAAAAAAIA3AZQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABgBAAIgBAAIgDgBgEgPegiqQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBgBAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAABgBQAAAAAAAAIA3gYQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAAAAAIg3AYIgDABIgBgBgEAOqgi/Ig4gWQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAIA4AXQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIgCABIgCgBgEgNvgjYQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAIA4gVQABAAAAAAQABgBAAAAQABABAAAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIg5AVIgBABIgCgBgEAM6gjqIg5gUQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABgBQAAAAABABQAAAAAAAAIA5ATQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABIgDAAIgBAAgEgL+gkBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAgBAAAAIA6gSQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQABAAAAABQgBAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQAAABgBAAIg5ASIgCAAIgCgBgEALIgkQIg6gQQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAIA6ARQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQAAAAABABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgCABIgCgBgEgKMgkjQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAIA6gOQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIg7APIgBAAIgDgBgEAJUgkvIg6gNQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABABIA7ANQAAAAABABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAIgCABIgCAAgEgIXgk/QAAAAgBAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQABAAAAAAQABAAAAgBQAAAAABAAIA7gMQABAAAAAAQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIg7AMIgBAAIgDgBgEAHfglJIg7gKQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAIA8AKQAAABABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBAAAAAAIgDACIgBgBgEgGhglVQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAIA7gJQABAAAAAAQABAAAAABQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIg8AJIAAAAIgEgBgEAFoglcIg7gIQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQAAAAABgBQAAAAABgBQAAAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAIA8AIQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgDABIgBAAgEgEpgllQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAIA8gGQABAAABAAQAAAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAAAAAIg9AGIgBAAIgDgBgEADxglpIg7gFQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQABgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAIA7AFQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAIgDACIgBAAgEgCwglwQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABgBIA8gCQAAgBABABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAgBAAQAAAAgBABIg8ACIAAABIgDgCgEAB6glxIg7gCQgBgBAAAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQAAgBABAAIA8ADQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAABQABAAAAABQgBAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgDACIgBAAgEgA4gl1QAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQABAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABgBIA0AAIADAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAIgDAAIg0ABQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243.6,-243.6,487.2,487.2);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5B79F7").s().p("AprhbQCfjjEvivQFPjCG6hbIAANmQm4BalRDDQkvCvifDjg");
	this.shape.setTransform(0,0,1.869,1.869);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-115.8,-145.5,231.7,291.1), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#01A4FF","rgba(0,0,0,0)"],[0,1],23.7,510.7,23.7,-277).s().p("EgeAAx5Qlui2jNjsQjGjigZj7MgAChcBMBU5AAAMAAABb7QgUD6jIDlQjNDulyC4QscGPxlAAQxmAAsbmPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-271.6,-359.1,543.3,718.3), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(91,121,247,0.498)").s().p("AnmhQQFahQEIirQDuibB9jIIAAL/Qh9DIjuCbQkICslaBPg");
	this.shape.setTransform(0,0,2.236,2.236);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-108.8,-153.5,217.7,307), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#9B42E8","rgba(0,0,0,0)"],[0,1],107.1,272,107.1,-207.5).s().p("EAAAAoGQoIAAlwivQlwivAAj4MAAAhG1MAnRAAAMAAABG1QAAD4lwCvQlwCvoJAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-125.7,-256.5,251.4,513.2), null);


(lib.iot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAAQAAgEAMAAQAOAAAAAEQgBACgEACQgDABgGAAQgMAAAAgFg");
	this.shape.setTransform(89.8,-11.8,4.802,4.802);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(121));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAmAaQggAAgWgJQgXgJAAgLQAAgMAXgJIADABQgYAIAAAMQAAALAWAHQAVAIAgAAIACAAIAAADg");
	this.shape_1.setTransform(71.5,-9.8,4.802,4.802);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(2).to({_off:false},0).wait(119));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABLAxQhAAAgrgRQgugRABgXQAAgXApgRIACABQgqARABAWQAAAWAsAQQAsARA+AAIADAAIAAACg");
	this.shape_2.setTransform(54,-7.3,4.802,4.802);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(4).to({_off:false},0).wait(117));

	// Layer_4
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABxBJQhgAAhDgaQhDgZAAgjQgBgiA9gZIACABQg8AZgBAhQABAiBDAZQBCAZBfAAIAFAAIAAACg");
	this.shape_3.setTransform(35.8,-4.9,4.802,4.802);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(6).to({_off:false},0).wait(115));

	// Layer_5
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ACZBjQiCgBhbgiQhcgjAAgvQAAguBQgiIADABQgmAQgVAUQgWAUAAAXQAAAuBcAjQBaAhCBABIAIAAIAAACg");
	this.shape_4.setTransform(16.4,-2.4,4.802,4.802);
	this.shape_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(8).to({_off:false},0).wait(113));

	// Layer_6
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AC9B5QigAAhxgrQhygqAAg7QAAg4BhgqIADABQgvAUgZAYQgaAZAAAcQAAA6BxAqQBxArCfAAIAKAAIAAABg");
	this.shape_5.setTransform(-0.9,0,4.802,4.802);
	this.shape_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(10).to({_off:false},0).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(83.3,-14.1,13,4.8);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhLA0IAAhnICXAAIAABng");
	mask.setTransform(7.6,5.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D1D1F").s().p("AgLALIgBghIAYAIIABAlg");
	this.shape.setTransform(1.3,8.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E0E0E2").s().p("AgGAGQgBgCABgEQABgDACgCQADgDACAAQADAAABADQAEAFgHAGQgCADgCAAQgDgBgCgCg");
	this.shape_1.setTransform(4.6,7.8);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,5.8,5.3,4.7), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCKIAAkTIETAAIAAETg");
	mask.setTransform(13.8,13.8);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiJCKIAAkTIETAAIAAETg");
	this.shape.setTransform(13.8,13.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,27.7,27.7), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgKBcQgEgDgBgEIAAizQABAEAEADQAKAGALgGQAEgDAAgDIAACyQABAEgFADQgFADgGAAQgEAAgGgDg");
	mask.setTransform(1.6,9.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#7C5241","#FFFFFF"],[0,1],-1.5,0,1.5,0).s().p("AgPBfIAAi9IAeAAIAAC9g");
	this.shape.setTransform(1.6,9.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,3.1,19), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgPAJIAAgRIAeAAIAAARg");
	mask.setTransform(1.6,0.9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D7E8D9").s().p("AgKAGQgEgDgBgDQABgDAEgCQAKgHALAHQAFACgBADQABADgFADQgFAEgGAAQgEAAgGgEg");
	this.shape.setTransform(1.6,0.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0,0,3.1,1.8), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag/AlIAAhJIB/AAIAABJg");
	mask.setTransform(6.4,3.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgsAaQgSgKgBgQQAAgPATgKQATgLAZAAQAbAAATALQASALAAAOIAAAAQAAAPgSALQgTALgbAAQgZAAgTgLg");
	this.shape.setTransform(6.4,3.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,12.9,7.4), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhXAyIAAhkICuAAIAABkg");
	mask_1.setTransform(8.8,5.1);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag9AkQgagPAAgVQAAgUAagPQAagPAjAAQAkABAaAPQAZAOAAAUIAAABQAAAUgZAPQgaAOgkAAQgjAAgagOg");
	this.shape_1.setTransform(8.8,5.1);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(0,0,17.5,10.1), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgQAlIAAhKIAhAAIAABKg");
	mask.setTransform(1.7,3.8);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgFAYIgDgBIgEgFIgBgHIAAgWIABgGIAEgEIADgDIAFgBIAGABIAEADIACAEIABAGIAAAWIgBAHIgCAFIgEABIgGABIgFgBgAAAgRIgCABIgBADIAAACIAAAWIAAAEIABACIACABIAAAAIACAAIABgBIABgCIAAgEIAAgWIAAgCIgBgDIgBgBIgCgBg");
	this.shape.setTransform(1.7,3.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0,0,3.4,7.5), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgBACIAAgDIADAAIAAADg");
	mask.setTransform(0.2,0.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AAAABQAAAAgBAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAIgBABIAAgBg");
	this.shape.setTransform(0.2,0.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0,0.4,0.4), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgDAEIAAgHIAHAAIAAAHg");
	mask.setTransform(0.4,0.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgCADQgCgDACgBQACgDACADQADABgDADIgCABIgCgBg");
	this.shape.setTransform(0.4,0.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0,0.7,0.7), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgFAGIAAgLIALAAIAAALg");
	mask.setTransform(0.6,0.6);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgDAEQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQADgFAEAFQAAAAABABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape.setTransform(0.6,0.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0,1.2,1.2), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgDAEIAAgHIAHAAIAAAHg");
	mask.setTransform(0.4,0.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgCADQgCgDACgCQACgCADACQADACgDADIgDABIgCgBg");
	this.shape.setTransform(0.4,0.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0,0,0.8,0.8), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgDADIAAgFIAHAAIAAAFg");
	mask.setTransform(0.4,0.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgCACIgBgCIABgBQACgDACADQABAAAAABQABAAAAAAQAAABgBAAQAAABgBAAIgCABIgCgBg");
	this.shape.setTransform(0.4,0.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0,0.7,0.7), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgFAGIAAgLIALAAIAAALg");
	mask.setTransform(0.6,0.6);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgDAEQAAgBgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQABgBAAAAQAEgEADAEQABAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAgBgBAAg");
	this.shape.setTransform(0.6,0.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0,0,1.2,1.2), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgFAGIAAgLIALAAIAAALg");
	mask.setTransform(0.6,0.6);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgDAEQgEgEAEgDQAAgBAAAAQABgBAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQABAAAAABQABAAAAABQAFADgFAEQAAABgBAAQgBABAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape.setTransform(0.6,0.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,1.2,1.3), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEAEIAAgHIAIAAIAAAHg");
	mask.setTransform(0.5,0.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgCADQgDgDADgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAgBQAAABABAAQAAAAAAAAQABAAAAAAQAAABABAAQADACgDADIgDACIgCgCg");
	this.shape.setTransform(0.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgGAHIAAgNIANAAIAAANg");
	mask.setTransform(0.7,0.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgEAFQgEgFAEgEQAEgFAFAFQAFAEgFAFQgDACgCAAQgBAAgDgCg");
	this.shape.setTransform(0.7,0.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0,1.4,1.4), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgBACIAAgDIADAAIAAADg");
	mask.setTransform(0.2,0.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgBAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAg");
	this.shape.setTransform(0.2,0.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0,0,0.5,0.4), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgDAEIAAgHIAHAAIAAAHg");
	mask.setTransform(0.4,0.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape.setTransform(0.4,0.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgGAHIAAgNIANAAIAAANg");
	mask.setTransform(0.7,0.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgGAAQAAgGAGAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape.setTransform(0.7,0.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,1.4,1.4), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEAFIAAgJIAJAAIAAAJg");
	mask.setTransform(0.5,0.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape.setTransform(0.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,0,1,1), null);


(lib.ClipGroup_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgDAEIAAgHIAHAAIAAAHg");
	mask_1.setTransform(0.4,0.4);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#62E9FA").s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape_1.setTransform(0.4,0.4);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_1, new cjs.Rectangle(0,0,0.8,0.8), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgGAHIAAgNIANAAIAAANg");
	mask.setTransform(0.7,0.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#62E9FA").s().p("AgGAAQAAgGAGAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape.setTransform(0.7,0.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,1.5,1.4), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgHAIIAAgPIAPAAIAAAPg");
	mask_1.setTransform(0.8,0.8);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#62E9FA").s().p("AgHAAQABgGAGgBQADABACACQADACAAACQAAAIgIAAQgGAAgBgIg");
	this.shape_1.setTransform(0.8,0.8);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(0,0,1.5,1.5), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ao3KAIAAz/IRuAAIAAT/g");
	mask.setTransform(56.8,64);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#63E2F6").s().p("AACAlIAAgzIgQAAIAAgKIAGAAIAGgCIAEgEQACgDABgDIAKAAIAABJg");
	this.shape.setTransform(100.7,5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(96.7,0,10.2,13.3), null);


(lib.ClipGroup_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgFAFIAAgJIAKAAIAAAJg");
	mask_2.setTransform(0.6,0.5);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#62E9FA").s().p("AgFAAQABgEAEAAQAGAAgBAEQABAFgGAAQgEAAgBgFg");
	this.shape_2.setTransform(0.6,0.5);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_2, new cjs.Rectangle(0,0,1.1,1.1), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgHAJIAAgRIAPAAIAAARg");
	mask.setTransform(0.8,0.9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA0588").s().p("AgFAGQgCgCAAgEQAAgDACgCQACgCADgBQADABADACQACACAAADQAAAEgCACQgDACgDABQgDgBgCgCg");
	this.shape.setTransform(0.8,0.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.ClipGroup_1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AjcHRIAAuhIG4AAIAAOhg");
	mask_3.setTransform(22.1,46.5);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5099F8").s().p("AjcGeIAAtvQC3BTCBC+QCAC/AAC5QAAC7iABDQg3AchAAAQhXAAhqg0g");
	this.shape_3.setTransform(22.1,46.6);

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_3, new cjs.Rectangle(0,0,44.1,93.1), null);


(lib.ClipGroup_1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AjcHOIAAubIG4AAIAAObg");
	mask_4.setTransform(22.1,46.2);

	// Layer_3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5099F8").s().p("AhbC1QiAi9gBiyQABiyCAhDQCBhEC2BTIAANuQi2hbiBi+g");
	this.shape_4.setTransform(22.1,46.1);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_4, new cjs.Rectangle(0,0,44.1,92.4), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhDBNIAAiZICHAAIAACZg");
	mask_1.setTransform(6.8,7.7);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOAnIg1gKQgEgBAAgDIAAgbQAAgIgGgGQgIgLgCgLIA5AAQAAAIAGABIA3AJIABADIAAACQAAAFgEgBIgJAAIAAAXQgCAJgJgBIgRgDIAAARQAAAEgEABg");
	this.shape_2.setTransform(7.1,11.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxAVQAGgVATgLQATgMAVAFQAWAGAMASIgjAGQgHABAAAIg");
	this.shape_3.setTransform(6,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA/AbIg0gJQgEgBAAgDIAAgFIhBAAQgDAAgDgCQgDgDAAgEQAAgCADgDQADgDADAAIBBAAIAAgFQAAgDAEgBIA0gJIADABQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAIAAAtQAAAEgFAAg");
	this.shape_4.setTransform(6.8,5.8);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,13.6,15.3), null);


(lib.ClipGroup_6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhbAAIAfgRQAfgSAaAAQATAAAOAJIA+AjQgSgJgWABQgYACgbAPIgdASg");
	mask_1.setTransform(12.4,11.9);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#8265F6","#43A5EE"],[0,1],-1.1,-1.8,-16.5,-25.9).s().p("Ah8gOICjhoIBWCFIijBog");
	this.shape_1.setTransform(12.5,11.9);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_1, new cjs.Rectangle(3.3,8.4,18.4,7.2), null);


(lib.ClipGroup_5_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Ah8AUIAFgDQAOAEAMAGIgXgMIBfg2QAbgQAZAAIACAAQAQAAAOAIIA+AkQgQgJgVABQgWACgZAOIhnA7g");
	mask_2.setTransform(17.6,17);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#8265F6","#43A5EE"],[0,1],5.7,8.9,-9.7,-15.2).s().p("AiwgWIDliTIB7DBIjkCSg");
	this.shape_2.setTransform(17.7,17);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_2, new cjs.Rectangle(5.1,11.4,25,11.2), null);


(lib.ClipGroup_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#8265F6","#43A5EE"],[0,1],7.8,12.2,-7.6,-11.9).s().p("AgRgBIAWgQIANATIgWAQg");
	this.shape_1.setTransform(1.8,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_1, new cjs.Rectangle(0,0,3.7,3.5), null);


(lib.ClipGroup_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AjPC/IAAgIQAAhpBAhuQBAhvBag1QAzgeAwAAQAhAAAYAPIApAYIgDACQg7gRhIArQhaA0hABuQhBBwABBoIAAAIg");
	mask_2.setTransform(41.3,41.6);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#8265F6","#43A5EE"],[0,1],5.8,9.2,-9.5,-14.9).s().p("AmdhfIH1lAIFGH/In2FAg");
	this.shape_2.setTransform(41.4,41.6);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_2, new cjs.Rectangle(20.6,18.9,41.6,45.4), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#8265F6","#43A5EE"],[0,1],7.8,12.2,-7.6,-11.9).s().p("AgRgBIAWgQIANATIgWAQg");
	this.shape_1.setTransform(1.8,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(0,0,3.7,3.5), null);


(lib.ClipGroup_1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("Ag1CEQglgWAAg8QAAg9AlhAQAjg8AugfIA/AkQgwAggiA7QgkA/AAA+QAAA7AiAWg");
	mask_5.setTransform(24.3,25);

	// Layer_3
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#8265F6","#43A5EE"],[0,1],-3.5,-5.6,-18.8,-29.7).s().p("AjyhGIEYizIDNFAIkZCzg");
	this.shape_5.setTransform(24.3,25);

	var maskedShapeInstanceList = [this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_5, new cjs.Rectangle(15.2,8.3,18.2,33.4), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AmyFjQgUgZAAgqQAAg+AlhAQAjg8AwgfIAAgIQgBhnBBhwQA/hvBcg0QA6giAzAEQAxAEAdAoIBng8QAcgQAaAAQAeAAASAWQASAXABAnIAegRQA1gfAmAWQAlAWABA8IAAABQAAA8gmBBQglBBg1AfIqMF4QgeARgcAAQggAAgTgXg");
	mask_2.setTransform(79.1,78.2);

	// Layer_3
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#43A5EE","#B6FFFF"],[0,1],-19.2,-31.5,7.9,13.1).s().p("AsWitIPnpgIJGO8IvoJfg");
	this.shape_5.setTransform(79.1,78.2);

	var maskedShapeInstanceList = [this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(33.6,40.4,91,75.7), null);


(lib.ClipGroup_10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEgBQAJgBAAgFIAAAJQAAAFgIABg");
	mask_1.setTransform(0.5,0.8);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00213B").s().p("AAAgCQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAAAIAAAIQAAABAAAAQAAAAAAABQgBAAAAABQAAAAAAAAg");
	this.shape_1.setTransform(0.9,0.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002845").s().p("AgDgDQAFgBABgBIABAJQgBABgFABg");
	this.shape_2.setTransform(0.4,0.9);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_1, new cjs.Rectangle(0,0,1,1.5), null);


(lib.ClipGroup_9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgOgBQAOgEAPgCIAAAIQgQACgNAFg");
	mask_1.setTransform(1.5,0.8);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002845").s().p("AgOgBQAOgEAPgCIAAAJQgPABgOAFg");
	this.shape_1.setTransform(1.5,0.8);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_1, new cjs.Rectangle(0,0,3.1,1.6), null);


(lib.ClipGroup_8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgDAAIAAgIQABAGAFACIABAJQgGgCgBgHg");
	mask_1.setTransform(0.4,0.9);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00213B").s().p("AgDAAIAAgIQABAGAFACIABAJQgGgCgBgHg");
	this.shape_1.setTransform(0.4,0.9);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_1, new cjs.Rectangle(0,0.1,0.7,1.8), null);


(lib.ClipGroup_7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AiVDnIAAnNIErAAIAAHNg");
	mask_1.setTransform(15,23.1);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#86D1EC").s().p("AhOA6IgUgKQgFgDgBgEQgBgEADgEIAgglQAHgIABgKIAFghQABgEAEgBQAEgCAGACIBMAXQAHACAGAEIAKAGIAuApQAEAEgCACQgDADgGABIg4AFQgQACgOAFIg+AWQgGACgGAAQgHAAgHgEg");
	this.shape_1.setTransform(14.3,6.7);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_1, new cjs.Rectangle(3.8,0.5,21.1,12.4), null);


(lib.ClipGroup_6_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgLADIgBgIQAMAFANgEIAAAJQgGABgGAAQgGAAgGgDg");
	mask_2.setTransform(1.3,0.6);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002845").s().p("AgHAFIAAgIQAIABAHgDIAAAJQgFACgFAAIgFgBg");
	this.shape_2.setTransform(1.8,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00213B").s().p("AgDADIgBgIQAEACAFABIAAAIQgFAAgDgDg");
	this.shape_3.setTransform(0.5,0.6);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_2, new cjs.Rectangle(0,0,2.6,1.3), null);


(lib.ClipGroup_5_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AgBAFIAAgRQAAAGACABIABASQgDgBAAgHg");
	mask_3.setTransform(0.2,1.4);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#848484").s().p("AgBAFIAAgRQAAAGACABIABASQgDgBAAgHg");
	this.shape_3.setTransform(0.2,1.4);

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_3, new cjs.Rectangle(0,0.2,0.5,2.6), null);


(lib.ClipGroup_4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AggAPIgBgSQAHADAVgCQAWgEARgKIAAASQgQAKgXAEIgQABQgIAAgDgCg");
	mask_2.setTransform(3.4,1.7);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9A9A9A").s().p("AgeARIgBgSQAMABARgDQATgEAOgJIABASQgOAJgTAEQgNACgJAAIgHAAg");
	this.shape_2.setTransform(3.7,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#848484").s().p("AgBAJIgBgSIAEABIABASg");
	this.shape_3.setTransform(0.3,2.3);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_2, new cjs.Rectangle(0,0,6.9,3.4), null);


(lib.ClipGroup_3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AiVDnIAAnNIErAAIAAHNg");
	mask_3.setTransform(15,23.1);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF3E45").s().p("AgmgNIAGgHIBHAlIgMAEg");
	this.shape_3.setTransform(18,3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhpBBQgFgDADgMQAEgPAPgKIBohBIAVgaIBIAmIgqAPIhoBBQgQAKgYAEIgQABQgIAAgEgCg");
	this.shape_4.setTransform(10.9,7.5);

	var maskedShapeInstanceList = [this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_3, new cjs.Rectangle(0,0.9,21.9,13.4), null);


(lib.ClipGroup_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgFABQACgEADAAIAAAAIAGADIgBAAQgDAAgCAEg");
	mask_2.setTransform(0.6,0.4);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002845").s().p("AgFABQACgEADAAIAAAAIAGADIgBAAQgDAAgCAEg");
	this.shape_2.setTransform(0.6,0.4);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_2, new cjs.Rectangle(0,0,1.2,0.8), null);


(lib.ClipGroup_1_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	mask_6.graphics.p("AgDAAIACgCIAFACIgCADg");
	mask_6.setTransform(0.4,0.3);

	// Layer_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002845").s().p("AgDAAIACgCIAFACIgCADg");
	this.shape_6.setTransform(0.4,0.3);

	var maskedShapeInstanceList = [this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_6, new cjs.Rectangle(0,0,0.7,0.5), null);


(lib.ClipGroup_4_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("Ao/IQIAAwfIR/AAIAAQfg");
	mask_3.setTransform(57.6,52.8);

	// Layer_3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgRCJQg2gWggg4Qgeg3AHg3QAHg3AngZQAogZAxASQA0ARAjA1QAkA2gEA5QgDA8gsAcQgZAQgcAAQgWAAgXgKgAg+hkQgeATgFAqQgGApAYAqQAYAqAoAQQAoAQAhgVQAhgUADgtQADgrgbgpQgagogngNQgPgGgOAAQgVAAgRALg");
	this.shape_4.setTransform(88,90.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgKB7QgegfgTg8QgSg5ACg0QADgzAXgLQAXgMAfAhQAhAhAVA4QAVA4gFAwQgEAygaAOQgIAFgJAAQgSAAgUgVgAgmhoQgRAJgCAmQgDAnAPArQAOAsAXAYQAWAXATgKQAUgLADglQADglgQgqQgPgrgZgYQgRgSgOAAQgFAAgFACg");
	this.shape_5.setTransform(11.1,43.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AH0IAIgtgPQAKhWgfhJQgjhShJgdQhLgeg0A4QgsAvgIBRQidhQh0hKQiOhbhshjQAEhLgShBQgUhIgsg0Qg3g/gbA4QgNAcgCAoQgGgGgHgJQgNgrADg8IAFgyIATAEQABggAGg1QAFgcALgDQAGgCAFAFQAAgBAAAAQABgBAAAAQABAAAAAAQABABABAAIACACQAPgdAWgZQALgMAJgHIgCgGQAKgFAMAFQAGACADAEQBeBRCLBbQBRA1CfBiQAXAOAQAcQA6BqA4BbIArAPQAFACAAAGQBYAjBJAoQAkATATANIABAGQAkAZAWAfQALAQADAKIAHA+IAaAaIAEAzIgUBMQANAbgCASIgEAAQgTAAgsgNgAIYGVIgEAlQAAAaAPAFQAJgCAEgdQACgSAAgQIgCgMQgFgBgGAAQgMAAgBAKgAG4C6QgLAHANAgQAMAgAUAUQARAQALAFQAGADADgBQALgWgjgyQgegrgOAAIgDABgACMAnIAFADQAIADAOAEQAWAGAMgEQgwhPhFh6IgngOQA1B0AqBXgABiAUIhTjDQhGgigsgZQgvgbhAgsIgMCHQBCAxAwAeQAuAdBKAnQgDgNAFgJQAGgLALgBQATADALARQAIAMACAKQABAGgFAHIAEAIIAbAOIAAAAgAiyhNQAAgEgIgHIgHgHQABgNgLgHQgIgGgGACIgEAEIgMgIQgMgHAAAEQgBAHAVAQIABAIQACAJAKAGQAJAHAGgDIADgGQAPALABgGgAnSmHQBDBGAuAqQA/A7A7ArIALiGQg/gsgmgfQgoghg3g2gAoilnQgCAMAFAGQAGAIACgHIAQg2QAGgTgIgKQgEgFgDAAQgNAAgFBFgAnsnRQgKAPgFAMIAGAIQASgmAmglIgHgIQgVASgTAeg");
	this.shape_6.setTransform(57.5,52.5);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_3, new cjs.Rectangle(0,0,115.1,105.6), null);


(lib.ClipGroup_3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AvsSWMAAAgkrIfYAAMAAAAkrg");
	mask_4.setTransform(100.5,117.4);

	// Layer_3
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AivE+QpEkBj3otIABgDQD4ItJFEAQILDnKMhBIgDAGQiNAOiGAAQnqAAmai2g");
	this.shape_5.setTransform(100.3,184.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AKvPDQhSAAg4gEQg1gDhUgKIgHDHIgGACIAIjKQhQgJg2gLQg0gJhPgTIgLDDIgGABIAMjFQhPgTgwgPQgygPhHgbIgOC/IgGAAIAPjBQhHgbgugVQgugUhBgkIgQC8IgFAAIAQi/QhCgkgogbQgpgbg5gtIgQC9IgEgBIAQi/Qg7gugighQgkgjgxg3IgODBIgDgCIANjDQgyg5gdgqQgfgrgphGIgIDKIgDgDIAHjMQgjg+gWgsQgWgugfhIIACgCQAdBHAXAtQAVArAkA+IAIjOQgmhAgYgvQgXgwghhNIABgDQAhBNAXAvQAXAuAmBAIAIjPQgohEgZgxQgZgygkhSIABgCQAkBRAZAxQAYAxAoBCIAIjPQhIh5g+iMIACgBQA7CGBJB6IAJjRQg5hehVixIABgCQBDCRBKB7IAIjTIABABQg6hfhdi8IACgCQDZGtEHDyQErEVGnBmIABgBIAAABQBJAPAyAHQAxAIBNAGIACgBIAAABQBLAHA0ACQAyABBPgBIAFgCIAAACQCTgBCOgTIgCAEQiOAUiRACIgEDFQCWgDCPgVIgDAFQiOAWiUACIgFDGQCVgCCUgXIgCAFQiSAWiVADIgEDIQCYgBCVgaIgDAGQiQAYiaACIgFDKQCbAACWgZIgCAGQiYAYiXABIgEDPQCgABCVgXIgDAGQiYAXiagCIgEDMIgHACgAGcOtQBUAKA1ADQA4AEBSAAIAEjPQhRABg3gDQg0gDhSgJgACON9QBPASA0AKQA2AJBQALIAIjNQhPgIg1gJQg0gJhMgRgAhvMvQBHAaAyAQQAxAPBOATIAMjHQhMgSgygOQgwgPhGgagAlYLFQBAAjAvAVQAsAVBJAbIAPjEQhIgagsgUQgugVhAgigAGlLdQBQAIA2ADQA2ACBSgBIAFjKQhSABg1gCQg1gChPgIgACbKwQBKASA2AJQAyAIBSAJIAJjJQhQgIgzgHQg0gIhLgRgAopI8QA6AtApAbQApAbBBAkIAQjDQhBgjgogbQgpgbg6gugAhfJnQBHAaAwAOQAxAPBMARIAMjFQhNgRgugOQgxgOhFgZgAlHH+QBBAkAtAUQAuAVBGAZIAPjCQhIgagrgTQgugVg/gigArfGPQAxA4AkAjQAjAgA7AvIAPjDQg6gugjgjQglgjgyg5gAGtIPQBRAIAzACQA4ACBPgBIAEjIQhPACg1gCQg1gChOgHgACnHmQBLARAzAHQA0AJBPAIIAIjGQhPgIgygIQgzgHhJgQgAoYF1QA5AtAqAcQAoAaBCAkIARjBQhCglgogaQgqgbg5gvgAhQGgQBGAYAwAPQAxAOBLAQIAMjEQhNgQgugOQgxgOhDgYgAk2E4QBAAjAuAVQAsAUBHAZIAPjBQhGgagsgTQgugVg/gjgAt6C4QAqBGAeAqQAeAqAxA5IAOjHQgzg8gegqQghgtgrhHgArRDEQAzA6AkAjQAjAiA7AuIAQjCQg6gvgkgjQglgkg0g7gAG2FEQBOAHA0ACQA1ACBPgCIAFjGQhOABg1gCQgzgBhNgHgACzEdQBKAQAzAIQAyAIBOAGIAIjGQhMgGgygHQgxgIhKgPgAoGCuQA5AuAqAcQAoAbBBAjIAQjCQhAgjgogbQgqgcg6gugAhBDYQBEAZAxAOQAvANBLAQIALjFQhJgPgugNQgwgNhEgYgAklByQA/AjAuAUQAsAUBGAZIAPjCQhFgYgrgUQgtgUhAgjgAtxgcQAqBIAhAtQAeAqAzA9IAPjGQhahmhKh/gArDgGQA0A7AmAjQAkAjA6AvIAQjBQg7gxgkgkQgngkgzg+gAG+B6QBMAGA0ACQAzABBQAAIAEjGQhOAAgzgBQg0gChKgGgAC/BUQBIAPAzAHQAxAIBOAHIAHjGQhMgHgvgHQgzgHhHgPgAn2gYQA6AtAqAcQAoAbBAAkIARjCQhAgkgogbQgrgcg5gwgAgxAQQBCAZAxANQAuANBKAQIAMjFQhKgQgtgMQgwgOhBgYgAkThUQA+AiAuAVQAqATBGAYIAPjEQhFgZgqgTQgugVg+gigAtqjvQBKB9BaBnIANjHQhbhrhNiCgAq0jSQAzA9AnAlQAkAjA8AxIAQjFQg7gxgmgkQgmgmg2g/gAnljiQA6AwAqAcQAoAbBBAlIAQjFQhBglgngbQgqgdg7gxgAthnFQBLCABdBtIAPjIQhfhvhQiHgAqmmgQA2BAAmAlQAmAlA6AxIARjHQg8gygmgmQgmgng3hBgAtZqbQBRCIBeBtIANjKQgtg2gwhGQgigwg0hSg");
	this.shape_6.setTransform(100.5,116.9);

	var maskedShapeInstanceList = [this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_4, new cjs.Rectangle(0,0,200.9,234.8), null);


(lib.ClipGroup_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("ADVRyQl5hTkfjEQlmj0jDmWIAA17QAbBUBBB7QCBD1C/DBQEKEOFdB/QG2CdIghMIAATkQhaANiQABIgXAAQkVAAkCg5g");
	mask_3.setTransform(100.5,119.5);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5998F8").s().p("ApyO5Ijmh+IPT7zILeGUIAAXdg");
	this.shape_3.setTransform(115.3,163.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5998F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_4.setTransform(78.2,156.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#5998F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_5.setTransform(77.5,156.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5A99F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_6.setTransform(76.7,156);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5B99F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_7.setTransform(76,155.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#5B99F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_8.setTransform(75.2,155.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5C9AF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_9.setTransform(74.5,154.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#5C9AF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_10.setTransform(73.7,154.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5D9BF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_11.setTransform(73,153.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5E9BF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_12.setTransform(72.2,153.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5E9BF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_13.setTransform(71.5,153.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#5F9CF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_14.setTransform(70.7,152.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#609CF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_15.setTransform(70,152.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#619DF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_16.setTransform(69.2,151.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#619DF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_17.setTransform(68.5,151.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#629DF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_18.setTransform(67.7,151);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#639DF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_19.setTransform(67,150.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#649EF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_20.setTransform(66.2,150.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#659EF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_21.setTransform(65.5,149.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#659FF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_22.setTransform(64.7,149.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#669FF8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_23.setTransform(64,149);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#67A0F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_24.setTransform(63.2,148.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#68A0F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_25.setTransform(62.5,148.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#69A1F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_26.setTransform(61.7,147.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#69A1F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_27.setTransform(61,147.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6AA2F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_28.setTransform(60.2,146.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#6BA3F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_29.setTransform(59.5,146.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#6CA3F8").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_30.setTransform(58.7,146.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#6DA4F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_31.setTransform(58,145.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#6EA4F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_32.setTransform(57.2,145.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#6FA5F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_33.setTransform(56.5,144.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#6FA5F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_34.setTransform(55.7,144.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#70A6F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_35.setTransform(55,144);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#71A6F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_36.setTransform(54.2,143.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#72A7F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_37.setTransform(53.5,143.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#73A8F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_38.setTransform(52.7,142.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#74A8F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_39.setTransform(52,142.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#75A9F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_40.setTransform(51.2,141.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#76A9F9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_41.setTransform(50.5,141.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#77AAF9").s().p("AntN4IPT7zIAIAEIvTbzg");
	this.shape_42.setTransform(49.7,141.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#78AAF9").s().p("AnrN6IAAgKIPP7rIAIAEIvTbzg");
	this.shape_43.setTransform(49.2,140.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#79ABF9").s().p("AnnNmIPH7dIAIAEIvPbrg");
	this.shape_44.setTransform(48.8,139.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#79ACF9").s().p("AnjNfIPA7PIAHAEIvHbdg");
	this.shape_45.setTransform(48.4,138.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#7AACF9").s().p("AngNZIO57CIAIAEIvBbPg");
	this.shape_46.setTransform(48.1,137.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#7BADF9").s().p("AncNSIOx61IAIAEIu5bDg");
	this.shape_47.setTransform(47.7,136.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#7CADF9").s().p("AnYNLIOq6nIAHAEIuxa1g");
	this.shape_48.setTransform(47.3,135.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#7DAEF9").s().p("AnUNEIOi6ZIAHAEIupang");
	this.shape_49.setTransform(46.9,134.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#7EAFF9").s().p("AnRM+IOb6MIAHAEIuiaZg");
	this.shape_50.setTransform(46.6,133.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#7FAFF9").s().p("AnNM3IOT5/IAIAEIubaNg");
	this.shape_51.setTransform(46.2,132.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#80B0F9").s().p("AnJMwIOL5wIAIADIuTZ/g");
	this.shape_52.setTransform(45.8,131.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#81B0F9").s().p("AnFMpIOE5jIAHAEIuLZxg");
	this.shape_53.setTransform(45.4,130);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#82B1F9").s().p("AnCMjIN95WIAHAEIuEZjg");
	this.shape_54.setTransform(45.1,128.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#83B2F9").s().p("Am+MbIN15HIAIAEIt9ZVg");
	this.shape_55.setTransform(44.7,127.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#84B2F9").s().p("Am6MVINt46IAIAEIt1ZHg");
	this.shape_56.setTransform(44.3,126.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#85B3F9").s().p("Am2MNINm4rIAHADIttY6g");
	this.shape_57.setTransform(43.9,125.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#86B4F9").s().p("AmzMHINf4fIAIAFItnYsg");
	this.shape_58.setTransform(43.6,124.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#87B4F9").s().p("AmvMAINX4RIAIAEItfYfg");
	this.shape_59.setTransform(43.2,123.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#88B5F9").s().p("AmrL5INQ4DIAHAEItXYRg");
	this.shape_60.setTransform(42.8,122.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#89B5F9").s().p("AmnLzINI32IAHAEItPYDg");
	this.shape_61.setTransform(42.4,121.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#8AB6F9").s().p("AmkLsINB3pIAHAFItIX2g");
	this.shape_62.setTransform(42.1,120.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#8BB7FA").s().p("AmgLlIM53aIAIADItBXpg");
	this.shape_63.setTransform(41.7,119.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#8CB7FA").s().p("AmcLeIMx3NIAIAEIs5Xbg");
	this.shape_64.setTransform(41.3,118);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#8DB8FA").s().p("AmYLYIMq3AIAHAFIsxXMg");
	this.shape_65.setTransform(40.9,116.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#8EB9FA").s().p("AmVLQIMj2xIAHAEIsqW/g");
	this.shape_66.setTransform(40.6,115.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#8FB9FA").s().p("AmRLKIMb2kIAIAEIsjWxg");
	this.shape_67.setTransform(40.2,114.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#90BAFA").s().p("AmNLCIMT2WIAIAFIsbWjg");
	this.shape_68.setTransform(39.8,113.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#91BAFA").s().p("AmJK8IMM2JIAHAFIsTWWg");
	this.shape_69.setTransform(39.4,112.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#92BBFA").s().p("AmGK1IMF17IAIAEIsNWJg");
	this.shape_70.setTransform(39.1,111.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#93BCFA").s().p("AmCKuIL91tIAIAEIsFV7g");
	this.shape_71.setTransform(38.7,110.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#94BCFA").s().p("Al+KnIL21fIAHAEIr9Vtg");
	this.shape_72.setTransform(38.3,109.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#95BDFA").s().p("Al6KhILu1SIAHAEIr1Vfg");
	this.shape_73.setTransform(37.9,108.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#96BEFA").s().p("Al3KaILn1FIAHAEIruVTg");
	this.shape_74.setTransform(37.6,107);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#97BEFA").s().p("AlzKTILf03IAIAEIrnVFg");
	this.shape_75.setTransform(37.2,105.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#98BFFA").s().p("AlvKMILX0pIAIAEIrfU3g");
	this.shape_76.setTransform(36.8,104.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#99C0FA").s().p("AlrKGILQ0cIAHAEIrXUpg");
	this.shape_77.setTransform(36.4,103.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#9AC0FA").s().p("AloJ/ILJ0PIAHAFIrQUcg");
	this.shape_78.setTransform(36.1,102.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#9BC1FA").s().p("AlkJ4ILB0AIAIADIrJUPg");
	this.shape_79.setTransform(35.7,101.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#9CC2FA").s().p("AlgJxIK5zzIAIAFIrBUAg");
	this.shape_80.setTransform(35.3,100.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#9DC2FA").s().p("AlcJqIKyzlIAHAEIq5Tzg");
	this.shape_81.setTransform(34.9,99.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#9EC3FA").s().p("AlZJjIKrzXIAIAEIqzTlg");
	this.shape_82.setTransform(34.6,98.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#9FC4FA").s().p("AlVJcIKjzJIAIAEIqrTXg");
	this.shape_83.setTransform(34.2,97.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#A0C4FA").s().p("AlRJWIKcy9IAHAFIqjTJg");
	this.shape_84.setTransform(33.8,96.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#A1C5FA").s().p("AlNJPIKUyvIAHAEIqbS9g");
	this.shape_85.setTransform(33.4,95);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#A2C6FA").s().p("AlKJIIKNyhIAHAEIqUSvg");
	this.shape_86.setTransform(33.1,93.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#A3C6FA").s().p("AlGJBIKFyTIAIAEIqNShg");
	this.shape_87.setTransform(32.7,92.8);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#A4C7FB").s().p("AlCI7IJ9yGIAIAEIqFSTg");
	this.shape_88.setTransform(32.3,91.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#A5C8FB").s().p("Ak+I0IJ2x4IAHADIp9SHg");
	this.shape_89.setTransform(31.9,90.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#A6C8FB").s().p("Ak7ItIJvxrIAHAFIp2R4g");
	this.shape_90.setTransform(31.6,89.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#A7C9FB").s().p("Ak3ImIJnxdIAIAEIpvRrg");
	this.shape_91.setTransform(31.2,88.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#A8CAFB").s().p("AkzIgIJfxQIAIAEIpnRdg");
	this.shape_92.setTransform(30.8,87.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#AACAFB").s().p("AkvIYIJYxBIAHAEIpfRPg");
	this.shape_93.setTransform(30.4,86.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#ABCBFB").s().p("AksISIJRw0IAIAEIpZRBg");
	this.shape_94.setTransform(30.1,85.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#ACCCFB").s().p("AkoILIJJwnIAIAFIpRQ0g");
	this.shape_95.setTransform(29.7,84);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#ADCCFB").s().p("AkkIEIJCwZIAHAEIpJQng");
	this.shape_96.setTransform(29.3,82.9);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#AECDFB").s().p("AkgH9II6wLIAHAEIpBQZg");
	this.shape_97.setTransform(28.9,81.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#AFCEFB").s().p("AkdH3IIzv+IAHAEIo6QLg");
	this.shape_98.setTransform(28.6,80.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#B0CEFB").s().p("AkZHwIIrvxIAIAFIozP+g");
	this.shape_99.setTransform(28.2,79.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#B1CFFB").s().p("AkVHpIIjvjIAIAEIorPxg");
	this.shape_100.setTransform(27.8,78.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#B2D0FB").s().p("AkRHiIIbvVIAIAEIojPjg");
	this.shape_101.setTransform(27.4,77.5);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#B3D0FB").s().p("AkNHbIIUvHIAHAEIobPVg");
	this.shape_102.setTransform(27,76.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#B4D1FB").s().p("AkKHUIINu5IAHAEIoUPHg");
	this.shape_103.setTransform(26.7,75.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#B5D2FB").s().p("AkGHNIIFurIAIAEIoNO5g");
	this.shape_104.setTransform(26.3,74.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#B6D2FB").s().p("AkCHHIH9ueIAIAEIoFOrg");
	this.shape_105.setTransform(25.9,73.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#B8D3FB").s().p("Aj+G/IH2uPIAHADIn9Oeg");
	this.shape_106.setTransform(25.5,72);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#B9D4FB").s().p("Aj7G5IHvuDIAIAFIn3OQg");
	this.shape_107.setTransform(25.2,70.9);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#BAD5FB").s().p("Aj3GyIHnt1IAIAEInvODg");
	this.shape_108.setTransform(24.8,69.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#BBD5FB").s().p("AjzGrIHgtnIAHAEInnN1g");
	this.shape_109.setTransform(24.4,68.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#BCD6FC").s().p("AjvGkIHYtZIAHAEInfNng");
	this.shape_110.setTransform(24,67.6);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#BDD7FC").s().p("AjsGeIHRtNIAIAFInZNZg");
	this.shape_111.setTransform(23.7,66.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#BED7FC").s().p("AjoGXIHJs/IAIAEInRNNg");
	this.shape_112.setTransform(23.3,65.4);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#BFD8FC").s().p("AjkGQIHCsxIAHAEInJM/g");
	this.shape_113.setTransform(22.9,64.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#C0D8FC").s().p("AjgGJIG6sjIAHAEInBMxg");
	this.shape_114.setTransform(22.5,63.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#C1D8FC").s().p("AjdGDIGzsWIAHAEIm6Mjg");
	this.shape_115.setTransform(22.2,62.1);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#C2D9FC").s().p("AjZF8IGrsIIAIADImzMWg");
	this.shape_116.setTransform(21.8,61.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#C4DAFC").s().p("AjVF1IGjr7IAIAFImrMIg");
	this.shape_117.setTransform(21.4,60);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#C5DBFC").s().p("AjRFuIGcrtIAHAEImjL7g");
	this.shape_118.setTransform(21,58.9);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#C6DBFC").s().p("AjOFnIGVrfIAIAEImdLtg");
	this.shape_119.setTransform(20.7,57.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#C7DCFC").s().p("AjKFgIGNrRIAIAEImVLfg");
	this.shape_120.setTransform(20.3,56.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#C8DDFC").s().p("AjGFaIGGrEIAHAEImNLRg");
	this.shape_121.setTransform(19.9,55.6);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#C9DDFC").s().p("AjCFTIF+q3IAHAFImFLEg");
	this.shape_122.setTransform(19.5,54.5);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#CADEFC").s().p("Ai/FMIF3qpIAIAEIl/K3g");
	this.shape_123.setTransform(19.2,53.4);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#CBDFFC").s().p("Ai7FFIFvqbIAIAEIl3Kpg");
	this.shape_124.setTransform(18.8,52.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#CCDFFC").s().p("Ai3E/IFoqOIAHAEIlvKbg");
	this.shape_125.setTransform(18.4,51.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#CEE0FC").s().p("AizE4IFgqAIAHADIlnKPg");
	this.shape_126.setTransform(18,50.1);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#CFE1FC").s().p("AiwExIFZpzIAHAFIlgKAg");
	this.shape_127.setTransform(17.7,49);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#D0E2FD").s().p("AisEqIFRpkIAIADIlZJzg");
	this.shape_128.setTransform(17.3,47.9);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#D1E2FD").s().p("AioEjIFJpXIAIAFIlRJkg");
	this.shape_129.setTransform(16.9,46.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#D2E3FD").s().p("AikEdIFCpKIAHAEIlJJXg");
	this.shape_130.setTransform(16.5,45.7);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#D3E4FD").s().p("AihEVIE7o7IAIAEIlDJJg");
	this.shape_131.setTransform(16.2,44.6);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#D4E5FD").s().p("AidEPIEzouIAIAEIk7I7g");
	this.shape_132.setTransform(15.8,43.5);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#D5E5FD").s().p("AiZEIIEsohIAHAFIkzIug");
	this.shape_133.setTransform(15.4,42.4);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#D8E6FD").s().p("AiVEBIEkoTIAHAEIkrIhg");
	this.shape_134.setTransform(15,41.3);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#D9E7FD").s().p("AiSD6IEdoFIAIAEIklITg");
	this.shape_135.setTransform(14.7,40.3);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#DAE7FD").s().p("AiOD0IEVn4IAIAEIkdIFg");
	this.shape_136.setTransform(14.3,39.2);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#DBE8FD").s().p("AiKDtIEOnrIAHAFIkVH4g");
	this.shape_137.setTransform(13.9,38.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#DCE9FD").s().p("AiGDmIEGncIAHADIkNHrg");
	this.shape_138.setTransform(13.5,37);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#DDEAFD").s().p("AiDDfID/nPIAHAEIkGHdg");
	this.shape_139.setTransform(13.2,35.9);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#DEEAFD").s().p("Ah/DYID3nBIAIAEIj/HPg");
	this.shape_140.setTransform(12.8,34.8);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#E0EBFD").s().p("Ah7DRIDvmzIAIAEIj3HBg");
	this.shape_141.setTransform(12.4,33.7);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#E1ECFD").s().p("Ah3DLIDommIAHAEIjvGzg");
	this.shape_142.setTransform(12,32.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#E2ECFD").s().p("Ah0DDIDhmXIAIADIjpGmg");
	this.shape_143.setTransform(11.7,31.5);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#E3EDFD").s().p("AhwC9IDZmLIAIAFIjhGYg");
	this.shape_144.setTransform(11.3,30.4);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#E4EEFE").s().p("AhsC2IDSl9IAHAEIjZGLg");
	this.shape_145.setTransform(10.9,29.3);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#E5EFFE").s().p("AhoCvIDKlvIAHAEIjRF9g");
	this.shape_146.setTransform(10.5,28.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#E6EFFE").s().p("AhlCoIDDlhIAIAEIjLFvg");
	this.shape_147.setTransform(10.2,27.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#E8F0FE").s().p("AhhCiIC7lVIAIAFIjDFhg");
	this.shape_148.setTransform(9.8,26);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#E9F1FE").s().p("AhdCbIC0lHIAHAEIi7FVg");
	this.shape_149.setTransform(9.4,24.9);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#EAF2FE").s().p("AhZCUICsk5IAHAEIizFHg");
	this.shape_150.setTransform(9,23.8);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#EBF2FE").s().p("AhWCNIClkrIAHAEIisE5g");
	this.shape_151.setTransform(8.7,22.7);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#ECF3FE").s().p("AhSCGICdkdIAIAEIilErg");
	this.shape_152.setTransform(8.3,21.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#EDF4FE").s().p("AhOCAICVkQIAIAEIidEdg");
	this.shape_153.setTransform(7.9,20.5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#EFF5FE").s().p("AhKB5ICOkDIAHAFIiVEPg");
	this.shape_154.setTransform(7.5,19.5);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#F0F5FE").s().p("AhHByICHj0IAIADIiPEDg");
	this.shape_155.setTransform(7.2,18.4);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#F1F6FE").s().p("AhDBrIB/jnIAIAFIiHD0g");
	this.shape_156.setTransform(6.8,17.3);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#F2F7FE").s().p("Ag/BkIB4jZIAHAEIh/Dng");
	this.shape_157.setTransform(6.4,16.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#F3F8FE").s().p("Ag7BdIBwjLIAHAEIh3DZg");
	this.shape_158.setTransform(6,15.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#F4F8FE").s().p("Ag4BXIBpi+IAIAEIhxDLg");
	this.shape_159.setTransform(5.7,14);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#F6F9FE").s().p("Ag0BQIBhixIAIAEIhpC/g");
	this.shape_160.setTransform(5.3,12.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#F7FAFF").s().p("AgwBJIBaijIAHAEIhhCxg");
	this.shape_161.setTransform(4.9,11.8);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#F8FBFF").s().p("AgsBCIBSiVIAHAEIhZCjg");
	this.shape_162.setTransform(4.5,10.7);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#F9FBFF").s().p("AgpA8IBLiIIAHAEIhSCVg");
	this.shape_163.setTransform(4.2,9.6);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FAFCFF").s().p("AglA1IBDh7IAIAFIhLCIg");
	this.shape_164.setTransform(3.8,8.5);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FBFDFF").s().p("AghAuIA7hsIAIADIhDB7g");
	this.shape_165.setTransform(3.4,7.4);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FDFDFF").s().p("AgdAnIA0hfIAHAEIg7Btg");
	this.shape_166.setTransform(3,6.3);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FEFEFF").s().p("AgaAhIAthSIAIAEIg1Bfg");
	this.shape_167.setTransform(2.7,5.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgWAYIAkhBIAFAAIAEACIgtBRg");
	this.shape_168.setTransform(2.3,4.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgSggIAkAAIgkBBg");
	this.shape_169.setTransform(1.9,3.3);

	var maskedShapeInstanceList = [this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149,this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.shape_164,this.shape_165,this.shape_166,this.shape_167,this.shape_168,this.shape_169];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_3, new cjs.Rectangle(0,0,201,239.1), null);


(lib.ClipGroup_1_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	mask_7.graphics.p("Ar+K1IAA1pIX9AAIAAVpg");
	mask_7.setTransform(76.7,69.3);

	// Layer_3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5B79F7").s().p("ALHKTQlmidlThZQlzhjmZgjIAAvLQH6AvExBKQFxBYEpCrIA4AiIAAPLQgkgZgUgJg");
	this.shape_7.setTransform(76.7,69.3);

	var maskedShapeInstanceList = [this.shape_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_7, new cjs.Rectangle(0,0,153.4,138.5), null);


(lib.ClipGroup_4_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AgxBmIAAjLIBjAAIAADLg");
	mask_4.setTransform(5,10.2);

	// Layer_3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxBiIAAiOQAAgFAEgDIAegUQAPgMAQgPIADgCIAeADIABADIAABmQAAAFgCADQgMAWgYAXQgaAageAPIgCABQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAgBgAgZAxQgFADAAAFQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAFgDAAgGQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAIgDABgAAlgIQgQAUgaAWQgFAEAAAFQAAAFAFgEQAbgXAPgUQADgDAAgFQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIgCABgAgaAdQgFADAAAFQABAFAEgDQAFgDAAgFQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAAAIgEABgAAkgbQgRAVgZAUQgFAFAAAEQAAAFAFgEQAagWARgUQADgDAAgGQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAAAIgDACgAgaAJQgGADABAFQAAAFAFgDQAFgDAAgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAIgDABgAAkguQgTAWgYAUQgFADAAAEQAAABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABgBAAAAQAbgWAQgUQADgEAAgFQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAIgCACgAALhaIgEAEIACArQAAAFAFgEQAWgUALgTIAAgFIgBgCQgQgBgPgDg");
	this.shape_7.setTransform(5,10.2);

	var maskedShapeInstanceList = [this.shape_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_4, new cjs.Rectangle(0,0,10,20.3), null);


(lib.ClipGroup_3_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("AhABLIAAiVICBAAIAACVg");
	mask_5.setTransform(6.5,7.5);

	// Layer_3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJgKQAJgGAKgCQgHAUgKARg");
	this.shape_7.setTransform(7.8,11.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMgEIAZgOQAAAOgEAPQgKACgKAGg");
	this.shape_8.setTransform(8,8.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJgBQAKgJAIgEIABAdQgLgEgIgMg");
	this.shape_9.setTransform(5.5,12.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgTgCQAMgKAHgJIABgCQARAKACAWQgRAIgOAHQgBgPgHgLg");
	this.shape_10.setTransform(11,3.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAVQANgSAHgXQALgCAIACIACAAQgRAbgWAPg");
	this.shape_11.setTransform(9.2,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNgEIAagOIABAWQgJAFgLAKQgFgKgCgNg");
	this.shape_12.setTransform(5,9.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgVAJIABgCQAIgJAMgKQAHANAPAEIgCACQgNAGgKAAQgKAAgIgEg");
	this.shape_13.setTransform(4.3,13.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHgLQALgDAIgFIABAYIgZAPQAAgNAFgSg");
	this.shape_14.setTransform(4.9,6.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDgYIADABQAJABAJgCQgFAUABANIgfAQQAAgYAOgZg");
	this.shape_15.setTransform(1.8,8.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgTgHIAggQQABAPAFAJQgKAKgJALIgBACQgQgKgCgVg");
	this.shape_16.setTransform(2,12);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAIgRIABAcQgIAEgJADQAFgRALgSg");
	this.shape_17.setTransform(5.2,3.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSAVIgCgBQASgZAVgPIABAAQgNAUgHAUIgKABIgIAAg");
	this.shape_18.setTransform(3.8,3.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AACAXQgJgCgKABQAEgQAAgOIAfgPQAAAWgOAZg");
	this.shape_19.setTransform(11.2,6.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgJgNQAMAEAHAKQgKAJgHAEg");
	this.shape_20.setTransform(7.4,2.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgUgEIABgBQAXgMARAKIgBABQgKALgIAHQgIgMgOgEg");
	this.shape_21.setTransform(8.6,1.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNgFQALgFAJgJQAGAMABANIgZAOg");
	this.shape_22.setTransform(7.9,5.2);

	var maskedShapeInstanceList = [this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_5, new cjs.Rectangle(0,0,13,15), null);


(lib.ClipGroup_2_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AhJBQIAAifICTAAIAACfg");
	mask_4.setTransform(7.4,8);

	// Layer_3
	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("Ag9BKQgMgJAAgPQAAgPAMgMIAbgdQALgNAQgFQAOgEAMAFQAEACACADIgMAPIgCACQgBgDgEgCQgGgDgHACQgHADgGAFIgbAgQgFAGAAAIQAAAHAGAEQAGAEAIgCQAIgCAGgHIAJgNQALABANgHIgTAbQgLAPgRAFQgFABgGAAQgKAAgIgGgAgTAaIgGgGIAMgPIACgBQACADADACQAGADAHgDQAIgCAFgHIAbgiQAGgHAAgHQAAgHgGgDQgGgCgJADQgIADgGAHIgJAMQgMAAgMAFIATgZQALgPARgGQARgGAMAFQANAFAAAOQAAAOgMAPIgcAjQgLAOgQAGQgHADgGAAQgHAAgGgDg");
	this.shape_170.setTransform(7.4,8);

	var maskedShapeInstanceList = [this.shape_170];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_170).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_4, new cjs.Rectangle(0,0,14.8,16.1), null);


(lib.ClipGroup_1_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	mask_8.graphics.p("Ag9BJIAAiRIB7AAIAACRg");
	mask_8.setTransform(6.2,7.3);

	// Layer_3
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2BHQgHgEAAgJQAAgKAHgJQAGgJAKgFQAMgGAHAEQATgXASgWIgBgGQgBgJAHgMQAGgLAKgHQAJgHAHADQAHACAAAJQAAAKgGALQgGAMgKAGQgKAIgIgEQgWAbgPASQABADAAADIAAAHQARgCAWgFQAGgOALgHQAIgHAGADQAGACAAAKQAAAKgFALQgGALgIAGQgIAHgHgCQgHgCAAgKIAAgHQgVAEgSACQgHANgMAGQgFADgFAAQgDAAgEgCg");
	this.shape_8.setTransform(6.2,7.3);

	var maskedShapeInstanceList = [this.shape_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_8, new cjs.Rectangle(0,0.1,12.4,14.6), null);


(lib.ClipGroup_3_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	mask_6.graphics.p("AgCAkIgBAAIgBAAIgCgBIgCAAQgDgCgBgEIAAhBQABAEADACIACABIABAAIABABIACAAIABAAIAEAAIAAAAIABAAIABgBIABAAIABAAIACgBIAAAAIAAgBIABAAIACgCIAAAAIAAAAIAAgBIABgBIgBBCIgBABIAAABIgCABIAAAAIAAABIgBAAIgBAAIgBAAIAAAAIgBABIgBAAIgBAAg");
	mask_6.setTransform(1.3,3.7);

	// Layer_3
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#B9837B","#FFFFFF"],[0,1],-1.2,0,1.2,0).s().p("AgMAkIAAhIIAZAAIAABIg");
	this.shape_23.setTransform(1.3,3.7);

	var maskedShapeInstanceList = [this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_6, new cjs.Rectangle(0,0,2.5,7.3), null);


(lib.ClipGroup_1_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	mask_9.graphics.p("AhIAqIAAhTICQAAIAABTg");
	mask_9.setTransform(7.3,4.2);

	// Layer_3
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhIAAIBIgpIBIApIhIAqg");
	this.shape_9.setTransform(7.3,4.2);

	var maskedShapeInstanceList = [this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_9;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_9, new cjs.Rectangle(0,0,14.5,8.4), null);


(lib.ClipGroup_3_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	mask_7.graphics.p("AgDA5IgBgBIgCAAIgBAAIgBAAIgCgBIAAAAIgDgCQgFgCgBgFIAAhmQABAFAGADIACACIAAAAIADAAIABABIADAAIAHAAIAEgBIACAAIAFgCIABgCIABgBIAAAAIABgBIAAgBIABAAIAAgCIAAAAIAABmIgBABIAAAAIAAABIAAAAIgBABIAAAAIgBABIgBACIgBAAIAAAAIgEACIAAAAIgBAAIgBABIgCAAIAAAAIgCABg");
	mask_7.setTransform(2,5.7);

	// Layer_3
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#AE685B","#FFFFFF"],[0,1],-1.9,0,2,0).s().p("AgTA5IAAhxIAmAAIAABxg");
	this.shape_24.setTransform(2,5.7);

	var maskedShapeInstanceList = [this.shape_24];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_7, new cjs.Rectangle(0,0.1,3.9,11.3), null);


(lib.ClipGroup_1_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_10 = new cjs.Shape();
	mask_10._off = true;
	mask_10.graphics.p("AhwBBIAAiBIDhAAIAACBg");
	mask_10.setTransform(11.3,6.5);

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhwAAIBwhAIBxBAIhxBBg");
	this.shape_10.setTransform(11.3,6.5);

	var maskedShapeInstanceList = [this.shape_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_10;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_10, new cjs.Rectangle(0,0,22.7,13.1), null);


(lib.ClipGroup_1_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_11 = new cjs.Shape();
	mask_11._off = true;
	mask_11.graphics.p("AkeBoIAAjQII9AAIAADQg");
	mask_11.setTransform(28.7,10.5);

	// Layer_3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ah6BbQhsgWgogpQgngpAyglQAzglBwgMQBvgMBsATQBrAUAoApQAoApgzAnQgzAnhwANQgoAEgnAAQhGAAhFgOg");
	this.shape_11.setTransform(28.7,10.4);

	var maskedShapeInstanceList = [this.shape_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_11;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_11, new cjs.Rectangle(0,0,57.4,20.9), null);


(lib.ClipGroup_5_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AibHeIAAu7IE3AAIAAO7g");
	mask_4.setTransform(15.6,47.8);

	// Layer_3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#142849").s().p("AgeA9QgugHgIgzIACgxIA8gRQAEgCAgACIAgACIASAIQATANABAeQABAZgcAXQgYAVgdAFIgGABQgKAAgSgEg");
	this.shape_4.setTransform(18.3,42);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#142849").s().p("AgGCCQgQgFgFgVQgIghgFhlIgEhfQA6gHAVACQAKAAgCACQAEAkgFC/QgBANgGAIQgJANgTgCIgFABQgDAAgFgCg");
	this.shape_5.setTransform(22.4,53.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#142849").s().p("AgEB2QgYiJgHg+QgBgTANgLQAIgGALAAIASADQATAHABASIACDPg");
	this.shape_6.setTransform(23.2,71.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#142849").s().p("AgNB+QgMAAgKgJQgNgLABgUIAOiwQACgaAZgHQAYgIAQAVQANARABAbQAAANgCAKQgDANgUB8QgCAOgKAJQgKAJgLAAIgDAAg");
	this.shape_7.setTransform(13.1,51.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#142849").s().p("AggB7IgCjdQAEgSASgIQAJgDAHAAQAWAGAHATQADAJgCAIQgSBxgIBkg");
	this.shape_8.setTransform(11.8,71.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFC0BF").s().p("AgIAeQgKgEgEgPQAAgFACgGQAFgQAOgOIAYAJIAAAcQABAEgDADQgEAEgEgHIgCgMIgDAMQgDAOgDAFQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgHgBg");
	this.shape_9.setTransform(2.3,45.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFF9F5").s().p("AgpAvQgCgCABgGQADgKAIgLIANgSQAJgNAEgGQAFgMgBgLQAQACAOgEQAIgBACgDQACACAAAEIACAqQgWAXgMAJQgUAQgVACQgIAAgBgDg");
	this.shape_10.setTransform(23.2,90.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFC0BF").s().p("AgSgkIAdAFIAIA4IghAMg");
	this.shape_11.setTransform(25.1,84.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFF9F5").s().p("AguAoQgCgDADgFQAEgJAJgKIAQgQQAVgXAAgQQAQADAPgBQAIgBADgCQABACgBAEIgDAqQgXATgPAIQgWAMgVAAQgIgBgBgDg");
	this.shape_12.setTransform(8.1,90.2);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_4, new cjs.Rectangle(0,35.6,27.6,60), null);


(lib.ClipGroup_4_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("AgcBYQgIgGgCgJIAAgIIASh7QABgUATgJIAEgCIAHgBQALAAAJAIQAIAJABALIglCHQgDAJgJAGQgFADgFAAQgFAAgEgDg");
	mask_5.setTransform(13.3,13.1);

	// Layer_3
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#F5585E","#9A1578"],[0,1],-10.2,11,-21.5,23).s().p("AiEAGICCiKICHB/IiDCKg");
	this.shape_8.setTransform(13.3,13.3);

	var maskedShapeInstanceList = [this.shape_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_5, new cjs.Rectangle(9.4,4.1,7.9,18.1), null);


(lib.ClipGroup_3_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	mask_8.graphics.p("AgjCfQgkgGgLgdIgDgbIgGjaQgBgJABgJQACgTALgCIAEgBQAWAABFAVQBEAUAIAIIgHDUIAAAYIgCAOQgFAOgvAGQgXAEgRAAQgPAAgMgDg");
	mask_8.setTransform(10.3,16.5);

	// Layer_3
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#F5585E","#9A1578"],[0,1],-0.2,15.8,0.2,-6.5).s().p("AhkCjIAHlJIDCAEIgHFIg");
	this.shape_25.setTransform(10.1,16.7);

	var maskedShapeInstanceList = [this.shape_25];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_8, new cjs.Rectangle(1,0.4,18.5,32.3), null);


(lib.ClipGroup_2_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("AibHeIAAu7IE3AAIAAO7g");
	mask_5.setTransform(15.6,47.8);

	// Layer_3
	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#2B2E31").s().p("AAmAXIhJgEQgHgFgFgJQgKgOAKgQIAFAIQAGAHAGABQAEAAAagKQAcgFAPAYQAPAXgIADg");
	this.shape_171.setTransform(15.3,2.6);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#2B2E31").s().p("AAaAFIAAAAIAAAAQABAHgtgCQgXgFgLgIQAIgOAagIQAXgIATADQARADAHAOQAHAMgEARIgBAAQgHAAgFAEQgFAFgBAGQgFgNgBgNg");
	this.shape_172.setTransform(17,4.8);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFC0BF").s().p("AgDAWQgFgBgCgHQgCgHABgIQACgJAFgGQAEgFAEAAQAFABACAHQACAHgBAIQgCAJgFAGQgDAFgDAAIgCAAg");
	this.shape_173.setTransform(21.6,8.4);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFC0BF").s().p("AAAAjQgKgDgHgIIgKg8IAyAEIAEBBIgGACQgGACgGAAIgJgCg");
	this.shape_174.setTransform(17.2,12.4);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFC0BF").s().p("AgJA4QgXgEgNgTQgOgUAEgWQAEgXATgNQAUgOAWAEQAXAEANATQAOATgEAXQgEAXgTANQgPALgRAAIgKgBg");
	this.shape_175.setTransform(16.5,7.3);

	var maskedShapeInstanceList = [this.shape_171,this.shape_172,this.shape_173,this.shape_174,this.shape_175];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_5, new cjs.Rectangle(10.1,0,12.8,16.1), null);


(lib.ClipGroup_1_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_12 = new cjs.Shape();
	mask_12._off = true;
	mask_12.graphics.p("AglBEIAgiGQAFgQAOAAIAIABQAMAEADAKQABAFgBAEIgtCNg");
	mask_12.setTransform(6.2,9.5);

	// Layer_3
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#F5585E","#9A1578"],[0,1],-8.7,1.4,-18,2.8).s().p("AhAhOIBlgQIAbCsIhlAQg");
	this.shape_12.setTransform(6.5,9.5);

	var maskedShapeInstanceList = [this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_12;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_12, new cjs.Rectangle(2.5,1.2,7.5,16.5), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AibHeIAAu7IE3AAIAAO7g");
	mask_3.setTransform(15.6,47.8);

	// Layer_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF5E63").s().p("AgJBJIgLh/QgBgNAJgGQAFgCAFgBQANgCAHAIQADAFAAAEIABCKg");
	this.shape_6.setTransform(29,39.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFC0BF").s().p("AgDAdQgIAAgBgEQgBgGADgJIADgJQgGAIgDABQgGAEgBgFQgBgEACgDIAMgTIAGgLIAaABQAEAWgEAOQgDAIgDADQgJAJgIAAIgCAAg");
	this.shape_7.setTransform(28.8,49.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF5E63").s().p("AANBbQgJgCgFgIIgEgHIgch5QgHgTAOgPIADgEQALgIANAEQANAEAGAMIAQCLQABAKgHAJQgHAHgHAAIgDgBg");
	this.shape_8.setTransform(27.3,26.4);

	var maskedShapeInstanceList = [this.shape_6,this.shape_7,this.shape_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(23.7,17.2,7.5,35.3), null);


(lib.ClipGroup_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhxgqIDiiDIABDYIjjCDg");
	mask_1.setTransform(11.4,17.4);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#67AFBA","#57A4AF"],[0,1],0,-16.9,0,17).s().p("AhxCuIAAlbIDjAAIAAFbg");
	this.shape_1.setTransform(11.4,17.4);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14_1, new cjs.Rectangle(0,0,22.8,34.8), null);


(lib.ClipGroup_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AheBNIAAiZIC9AAIAACZg");
	mask_1.setTransform(9.5,7.7);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333438").s().p("AheBJIAAgtIC2hoIAHAEIi2BoIAAAtg");
	this.shape_1.setTransform(9.5,7.7);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13_1, new cjs.Rectangle(0,0,19.1,15.5), null);


(lib.ClipGroup_12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AkFCrIAAlWIIKAAIAAFWg");
	mask_1.setTransform(26.2,17.2);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E4045").s().p("AkBh8IgEgvIIKEsIgEAqg");
	this.shape_1.setTransform(26.2,17.2);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12_1, new cjs.Rectangle(0,0,52.3,34.3), null);


(lib.ClipGroup_11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhcBKIAAiTIC5AAIAACTg");
	mask_1.setTransform(9.3,7.4);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#474747").s().p("AhXAfIC0hoIgFArIi0Bog");
	this.shape_1.setTransform(9.3,7.4);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11_1, new cjs.Rectangle(0,0,18.6,14.8), null);


(lib.ClipGroup_10_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AhIBDIkXijIC4hqIIHEsIi1Bpg");
	mask_2.setTransform(52.7,50.9);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#494C51","#55595E","#64676D"],[0,0.533,1],-13,-22.5,13.1,22.7).s().p("AoPhkIK/mXIFgJhIq/GWg");
	this.shape_3.setTransform(52.8,50.8);

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_2, new cjs.Rectangle(17.6,30.5,70.4,40.7), null);


(lib.ClipGroup_8_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AhkAsIADg+IC3hrIAPCQIi3Brg");
	mask_2.setTransform(10.1,12.6);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#34363B","#2F3135"],[0,1],10.1,0,-10,0).s().p("AhkB+IAAj7IDJAAIAAD7g");
	this.shape_2.setTransform(10.1,12.6);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_2, new cjs.Rectangle(0,0,20.2,25.1), null);


(lib.ClipGroup_6_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AkVDlIAAnKIIrAAIAAHKg");
	mask_3.setTransform(27.8,23);

	// Layer_3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E4045").s().p("AkUhdIgBiIIIqFDIABCHg");
	this.shape_4.setTransform(27.8,23);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_3, new cjs.Rectangle(0,0,55.6,45.9), null);


(lib.ClipGroup_5_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("AhcB5IAAjxIC5AAIAADxg");
	mask_5.setTransform(9.3,12.1);

	// Layer_3
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#235F77").s().p("AhcgOIC4hqIABCHIi4Bqg");
	this.shape_13.setTransform(9.3,12.1);

	var maskedShapeInstanceList = [this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_5, new cjs.Rectangle(0,0,18.5,24.3), null);


(lib.ClipGroup_3_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	mask_9.graphics.p("AgGAvQgDgCAAgDIgHhPIABABQgCgEAGgEQAFgDAGAAQAIAAAEADQAGADgBAEIgGBPQAAADgDACQgEABgEAAQgDAAgDgBg");
	mask_9.setTransform(1.7,4.8);

	// Layer_3
	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#D18B59","#D69361","#E6A975","#FAC590"],[0,0.243,0.62,1],1.7,0.1,-1.6,0.1).s().p("AgQAxIAAhhIAhAAIAABhg");
	this.shape_26.setTransform(1.7,4.9);

	var maskedShapeInstanceList = [this.shape_26];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_9;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_9, new cjs.Rectangle(0.1,0,3.4,9.7), null);


(lib.ClipGroup_2_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	mask_6.graphics.p("AgGAuQgBAAgBgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIgHhQIABABQgCgEAGgDQAFgDAGAAQAIAAAEADQAGACgBAEIgGBQQAAABgBAAQAAABAAAAQAAABgBAAQgBABAAAAQgEACgEAAQgDAAgDgCg");
	mask_6.setTransform(1.7,4.8);

	// Layer_3
	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#D18B59","#D69361","#E6A975","#FAC590"],[0,0.243,0.62,1],1.7,0,-1.6,0).s().p("AgQAxIAAhhIAhAAIAABhg");
	this.shape_176.setTransform(1.7,4.9);

	var maskedShapeInstanceList = [this.shape_176];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_176).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_6, new cjs.Rectangle(0.1,0,3.4,9.7), null);


(lib.ClipGroup_1_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_13 = new cjs.Shape();
	mask_13._off = true;
	mask_13.graphics.p("AgHAvQgCgDAAgCIgHhQIAAABQgBgEAGgEQAEgCAHgBQAIABAEACQAFAEAAADIgHBQQAAACgCADQgEACgEAAQgDAAgEgCg");
	mask_13.setTransform(1.8,4.9);

	// Layer_3
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#D18B59","#D69361","#E6A975","#FAC590"],[0,0.243,0.62,1],1.7,0,-1.6,0).s().p("AgQAxIAAhhIAhAAIAABhg");
	this.shape_13.setTransform(1.7,4.9);

	var maskedShapeInstanceList = [this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_13;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_13, new cjs.Rectangle(0.1,0,3.4,9.7), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AiNCnIAAlNIEaAAIAAFNg");
	mask_4.setTransform(14.2,16.7);

	// Layer_3
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFF4E0").s().p("AgJAIQgEgCABgFQAAgDAEgDQAFgDAGAAQAFABACABIABABQACADAAADQgJADgDAFIgCgBIgHABg");
	this.shape_9.setTransform(11.8,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFF4E0").s().p("AgGAJQgGAAgBgEQAAgDAFgDQAFgEAFgCIACgBIAIgBIACABIgBABQgEAEAEADIgIAHIgCABQgDACgEAAIgCgBg");
	this.shape_10.setTransform(10.5,3.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFF4E0").s().p("AgGAKQgEAAgBgDQgBgEADgEIABgCIAIgHQABACAEABIAGgBQgBAEACACIgBACQgDAEgFADQgEAEgEAAIgBgBg");
	this.shape_11.setTransform(11.8,4.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFF4E0").s().p("AgCAJQgEAAgDgDIgBgBQgDgCABgDQAHgCAFgGIAJAAIABAAQAEADgBAEQAAADgFADQgEAEgEAAIgCAAg");
	this.shape_12.setTransform(14.2,3.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFF4E0").s().p("AgMAJQAEgHgFgCIAJgGIADgBIAIgBQAHgBAAAFQAAADgEADQgFAEgGACIgCABIgKABg");
	this.shape_13.setTransform(15.5,2.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FABD54").s().p("AgLAIQgEgEAEgEIABAAQADgGAIgCIAFgBIAFABQAFADgEAGIgBABQgFAFgGACIgFABQgEgBgCgBg");
	this.shape_14.setTransform(13,2.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFF4E0").s().p("AgEAJIgGABQABgEgCgDIABgBQADgEAFgEQAEgDAFAAQAEABABADQABAEgDAEIgBABIgJAGg");
	this.shape_15.setTransform(14.1,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3FA635").s().p("AASAvIgDgEQgLg7gYgfIAAgCQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAAAABQAaAeAOBGIgBAAQAAAAAAAAQgBgBAAAAQAAgBgBAAQAAgBgBgBg");
	this.shape_16.setTransform(13.8,6.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FABD54").s().p("AADAIQgGgBgDgHQgEgHAHAAQAGABAEAHQACADgBACQAAABgBAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgCAAg");
	this.shape_17.setTransform(2.3,13.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFF4E0").s().p("AAAAGQgJgFAAgFQABgGAIAGQAKAEgBAGQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQgDAAgDgCg");
	this.shape_18.setTransform(1,12.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFF4E0").s().p("AgFAEQgFgGAFgDQAFgEAFAGQAGAGgFADIgEACQgDAAgEgEg");
	this.shape_19.setTransform(1.6,13.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFF4E0").s().p("AAEAJQgFgBgFgIQgBgDAAgDQABgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAGABADAIQACAEgBACQAAABAAAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAAg");
	this.shape_20.setTransform(2.9,14.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFF4E0").s().p("AAAAFQgJgFABgFQAAAAAAAAQAAgBAAAAQABAAAAAAQABgBABAAQADAAADACQAJAFAAAFQgBABAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgBABQgCAAgDgDg");
	this.shape_21.setTransform(3.7,14.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFF4E0").s().p("AgFAEQgFgGAFgDQAFgEAGAGQAFAGgFADIgEACQgDAAgEgEg");
	this.shape_22.setTransform(3.1,12.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFF4E0").s().p("AgGAAQgDgIAGAAQAGABADAIQAFAIgHAAQgFgBgFgIg");
	this.shape_23.setTransform(1.7,12);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3FA635").s().p("AApA9QgHglgVgeQgUghgfgTIAAAAIgEgCIABgBQAkASATAiQAOAWAFALQAKAUAAARIgBABIgBgBg");
	this.shape_24.setTransform(6.8,19.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FABD54").s().p("AgFAAQAAgFAFAAQAHABgBAFQgBAFgFAAQgGgBABgFg");
	this.shape_25.setTransform(13.2,20.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFF4E0").s().p("AgFADQgDgEAHgDQAFgDADAFQAAAAAAABQAAAAAAABQAAAAAAAAQAAABgBAAQgBADgDABIgDABQgDAAgBgDg");
	this.shape_26.setTransform(14.1,19.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFF4E0").s().p("AgCAEQgGgDADgEQAEgFAEAFQAGADgDAEQgBABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQgCAAgCgDg");
	this.shape_27.setTransform(14,20.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFF4E0").s().p("AAAAHQgFAAABgHQABgHAEABQAFABAAAFQgBAHgFAAIAAAAg");
	this.shape_28.setTransform(13.1,21.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFF4E0").s().p("AgFADQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQABgCADgBQAFgDADAFQACAEgHADIgDABQgDAAgBgDg");
	this.shape_29.setTransform(12.2,20.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFF4E0").s().p("AgCAEQgGgDADgEQADgFAFAFQAGADgDAEQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQgCAAgCgDg");
	this.shape_30.setTransform(12.4,19.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFF4E0").s().p("AAAAHQgFgBABgGQABgHAEABQAFAAAAAGQgBAHgFAAIAAAAg");
	this.shape_31.setTransform(13.3,19.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FABD54").s().p("AAAAMQgFgBgDgDQgDgEAAgEQABgFAEgDQADgDAEAAQAFABADAEQADADgBAEQAAAFgDADQgEADgEAAIAAAAg");
	this.shape_32.setTransform(14.6,14.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFF4E0").s().p("AgFALQgFgBgCgEQgCgEADgEQACgEAGgDQAEgCAFABQAFABACAEQABAEgCAEQgDAEgFACQgDACgDAAIgDAAg");
	this.shape_33.setTransform(16.4,13.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFF4E0").s().p("AgFAJQgFgEgBgEQgCgEADgEQAGgIAKAIQAFADABAEQACAFgDADQgCAEgFAAQgEAAgFgDg");
	this.shape_34.setTransform(16.2,15.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFF4E0").s().p("AgBAOQgEgBgCgEQgDgEAAgFQABgGADgDQAEgEADAAQAEABADAEQADAFgBAEQAAAGgEAEQgDADgDAAIgBAAg");
	this.shape_35.setTransform(14.4,16.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFF4E0").s().p("AgEALQgGgBgBgEQgCgEACgEQADgEAFgDQAFgCAEABQAFABACAEQABAEgCAEQgCAEgFACQgEACgDAAIgCAAg");
	this.shape_36.setTransform(12.8,15.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFF4E0").s().p("AgFAJQgFgDgBgFQgCgEADgEQAGgIAKAIQAFADABAEQACAFgDAEQgCADgGAAQgEAAgEgDg");
	this.shape_37.setTransform(13,13.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFF4E0").s().p("AAAAOQgEgBgDgEQgDgEABgFQAAgFAEgEQADgEADAAQAFABACAEQADAFAAAEQgBAGgDAEQgEADgDAAIAAAAg");
	this.shape_38.setTransform(14.8,12.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFF4E0").s().p("AgHAIQgEgCAAgEQABgCADgDQAEgEAFgBQAEAAADACIABABQACACAAADQgHACgDAFIgCAAIgGABg");
	this.shape_39.setTransform(2.2,5.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFF4E0").s().p("AgLAGQAAgDAEgDQADgEAFgCIACgBIAGgBIADAAIgBABQgDAFAEACIgHAGIgCABQgDACgFAAIgCAAQgBAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAgBg");
	this.shape_40.setTransform(1.2,6.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFF4E0").s().p("AgJAHQgCgDADgEIABgCIAHgHQABACADAAIAFgBQgBADADADIgBABQgFAKgJABQgEAAgBgDg");
	this.shape_41.setTransform(2.5,7.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFF4E0").s().p("AgIAHIgBgBQgCgCAAgEQAHgBADgFIACAAIAGgCIABABQAEACAAAEQgBACgDAEQgDADgGABQgEAAgDgCg");
	this.shape_42.setTransform(4.5,6.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFF4E0").s().p("AgKAJIAAgBQADgGgEgCIAIgFIACgBQADgCAEAAQAGAAAAADQABADgEADQgEAEgFACIgBABIgHABg");
	this.shape_43.setTransform(5.5,5.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FABD54").s().p("AgJAIQgDgDADgFIAAAAQADgFAGgCIAFgBIAEAAQAFADgDAFIgBABQgDAFgHACIgEABIgBAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_44.setTransform(3.3,6.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFF4E0").s().p("AgKAEIABgCQACgEAFgDQADgDAEgBQAJABgFAJIgBACIgIAGIgDgBIgFABQABgDgDgCg");
	this.shape_45.setTransform(4.2,4.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#41B448").s().p("AATAYQgBgTgJgNQgKgSgRAFQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQATgGALASQALAQgCASIgBABIAAgBg");
	this.shape_46.setTransform(9.4,23.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#41B448").s().p("AgTAYQgCgTALgPQALgSATAGIgBABQgRgFgKASQgJANgBATIAAABIgBgBg");
	this.shape_47.setTransform(17.5,23.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FABD54").s().p("AAEAKQgIgBgEgJQgDgEACgCQACgDADAAQAJABAFAJQABAEgBADQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAIgCAAg");
	this.shape_48.setTransform(9.1,17.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFF4E0").s().p("AAAAHQgFgCgDgFQgEgDABgDQABgHALAHQAMAGgBAHQAAAEgEAAQgDAAgFgEg");
	this.shape_49.setTransform(7.3,16.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFF4E0").s().p("AgGAFQgDgEAAgCQgBgEADgCQADgCAEAAQADABAEAEQADADAAADQAAAEgDACQgCACgDAAQgDAAgFgFg");
	this.shape_50.setTransform(8.1,18);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFF4E0").s().p("AAFAMQgHgBgFgLQgCgFAAgDQABgDAEAAQADABADADQAEAEACAEQADAFgBADQgBABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAIgBAAg");
	this.shape_51.setTransform(9.9,18.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFF4E0").s().p("AAAAHQgMgHABgGQAAgDAEAAQAEAAAEADQAFACADAEQAEAEgBADQAAABAAAAQAAABgBAAQAAAAgBABQgBAAgBAAQgDAAgFgDg");
	this.shape_52.setTransform(10.9,18.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFF4E0").s().p("AAAAJQgDgBgDgDQgDgEAAgCQgBgEADgCQADgCAEABQAEAAADAEQADADAAADQAAAEgCACQgDABgDAAIgCAAg");
	this.shape_53.setTransform(10.1,16.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFF4E0").s().p("AAFAMQgHgBgGgLQgCgFABgDQABgDADAAQAEABADADQAEAEACAEQAFALgHAAIgBAAg");
	this.shape_54.setTransform(8.4,15.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FABD54").s().p("AgGAJQgDgBgBgCQgBgDADgDQAFgJAKABQAEAAAAADQABAEgCACQgGAIgIAAIgCAAg");
	this.shape_55.setTransform(21,16.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFF4E0").s().p("AgJAIQgEgBABgDQABgGAMgEQAFgCAEABQAEABAAADQgBAGgNAEIgGACIgDgBg");
	this.shape_56.setTransform(22.9,15.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFF4E0").s().p("AgIAHQgCgDAAgDQABgDAEgDQAIgHAGAHQADACgCADQAAAEgEACQgEADgDAAQgFAAgCgCg");
	this.shape_57.setTransform(21.9,17);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFF4E0").s().p("AgHAKQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBgEAEgDQAGgKAIAAQAEABAAADQABAEgEADQgGAKgHAAIgCgBg");
	this.shape_58.setTransform(19.9,17.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFF4E0").s().p("AgJAIQgEgBABgDQABgGAMgEQAFgCAEABQAEABgBADQgBAGgMAEIgGACIgDgBg");
	this.shape_59.setTransform(19.1,16.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFF4E0").s().p("AgIAHQgCgDAAgDQABgDAEgDQAJgGAFAGQADACgBADQgBAEgEACQgEADgDAAQgFAAgCgCg");
	this.shape_60.setTransform(20.2,15.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFF4E0").s().p("AgHAKQAAAAgBAAQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBgEADgDQAEgEAEgDQAEgDAEAAQAAABABAAQABAAAAABQABAAAAABQAAAAAAABQAAADgDADQgHALgGAAIgCgBg");
	this.shape_61.setTransform(22.1,14.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FABD54").s().p("AgFADQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQADgEAEAAQAFAAgDAEQgDAFgFAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAgBAAAAg");
	this.shape_62.setTransform(18.2,20.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFF4E0").s().p("AgEAFQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAgDAGgDQAHgCAAAEQAAACgHADIgDABIgBAAg");
	this.shape_63.setTransform(19.3,19.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFF4E0").s().p("AgEAEQgDgDAFgDQAEgEADAEQADACgFADQgDACgBAAIgDgBg");
	this.shape_64.setTransform(18.7,20.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFF4E0").s().p("AgEAAQAEgFAEAAQAFAAgEAFQgEAGgEAAQgEgBADgFg");
	this.shape_65.setTransform(17.6,21);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFF4E0").s().p("AgHACQACgDAFgCQAIgCAAAEQgBADgHACIgDABQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBg");
	this.shape_66.setTransform(17.2,20.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFF4E0").s().p("AgEAEQgDgEAFgCQAEgEADAEQADADgFADQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAg");
	this.shape_67.setTransform(17.7,19.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFF4E0").s().p("AgDAAQADgGAEABQABAAAAAAQAAABABAAQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAAAQgEAGgEAAQgEgBAEgFg");
	this.shape_68.setTransform(18.8,19.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FABD54").s().p("AgEAHQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBAAAAQgBgDACgCQAGgGAFAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQABACgDACQgEAGgFAAIgCAAg");
	this.shape_69.setTransform(25.8,11.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFF4E0").s().p("AgHAGQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQABgFAJgDQAEgCADABQABAAAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAFgKACIgFACIgCgBg");
	this.shape_70.setTransform(27.3,10.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFF4E0").s().p("AgGAFQgEgFAHgEQAGgEAEAEQACACgBACQAAADgDACQgEACgCAAQgDAAgCgCg");
	this.shape_71.setTransform(26.4,12);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFF4E0").s().p("AgFAIQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAgBQgBgCACgDQAGgIAFABQABAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAADgDACQgEAHgGAAIgBAAg");
	this.shape_72.setTransform(25,12.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFF4E0").s().p("AgJADQABgEAJgEQAEgBADABQAAAAABAAQABAAAAABQAAAAAAABQAAAAAAABQAAAEgKAEIgFABQgEAAAAgEg");
	this.shape_73.setTransform(24.3,11.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFF4E0").s().p("AgGAFQgCgCABgDQABgCACgCQAGgFAFAFQACACgBACQgBADgDACQgDACgCAAQgDAAgCgCg");
	this.shape_74.setTransform(25.2,10.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFF4E0").s().p("AgFAIQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAgBQAAgCACgDQAGgHAGAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAACgDADQgFAHgEAAIgCAAg");
	this.shape_75.setTransform(26.6,10.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#3FA635").s().p("AgOAeQgBgQAJgQQAGgQANgLIACAAIAAABQgOAQgEAMQgEAKgFAUIAAAAIgCAAg");
	this.shape_76.setTransform(17.2,22.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#3FA635").s().p("AAKAoQgFgGgBgKIgBgSQgDgbgNgRQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAQANAOAFAUQAIAfgBAPIgCABIgBAAIgBgBg");
	this.shape_77.setTransform(10.7,21.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#3FA635").s().p("AgaAmQACgZANgVQAOgaAWgEIACABIgBACQgrAagGAvIgCABQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAAAg");
	this.shape_78.setTransform(18.1,21.2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#3FA635").s().p("AAtBfQgDgKgDgVQgDgVgDgKQgOgkgJgTQgRglgUgRIgLgIQgHgFgCgEIAAgCIABAAQArAhAUArQASAlAGASQALAjgFAYIgBABIgBgBg");
	this.shape_79.setTransform(8.1,16);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#4EBC3A").s().p("AgfBcQgJgyARgzQARg1AlgfQAAAAABAAQAAgBABAAQAAABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQgBAAAAABQgiAggLA1IgMBgQAAAAAAABQgBAAAAABQgBAAAAAAQgBABgBAAQAAAAgBgBQgBAAAAAAQgBgBAAAAQAAgBgBAAg");
	this.shape_80.setTransform(17.8,16.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFF4E0").s().p("AgNAKIAAgCQgBgFACgEQADgHAHgEQAFgDAFACQAFACABAFIAAACIgFAHIgBADQgIABgGAIQgFgBgCgEg");
	this.shape_81.setTransform(8.3,7.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFF4E0").s().p("AgPAJIgBABIABgDIAFgHIACgCQAGgHAGgDQAHgCAEACQAEACgDAHQgCAFgFAEIgDADQgHACgEADQgCgGgIABg");
	this.shape_82.setTransform(10.9,7.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFF4E0").s().p("AgJAMQgCgEgEgBIAEgGQABgDgBgEQAFgDAHgCIACAAQAIgBADADQAEADgCAFQgCAEgHAEQgHAFgGAAg");
	this.shape_83.setTransform(11.4,9.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFF4E0").s().p("AgHAPQgFgCgBgFIAAgDIAFgGIABgEQAIgBAGgIQAEACADAEIAAABQABAFgCAEQgDAHgHAEQgDACgEAAIgDAAg");
	this.shape_84.setTransform(9.1,11.8);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFF4E0").s().p("AgOAOQgEgCADgIQACgEAFgFIADgCQAFgFAGgCQAAAIAKgCIABAAIgBADIgFAHIgCACQgGAHgGADIgHABIgEgBg");
	this.shape_85.setTransform(6.5,12.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FABD54").s().p("AgPAHIABgFIAEgFQAHgIAIgBIABgBQAIgBACAGQABAEgCAEIgEAEQgGAIgIACIgCAAIgDAAQgHAAAAgHg");
	this.shape_86.setTransform(8.7,9.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFF4E0").s().p("AgNAKQgEgDACgFQADgEAGgEQAGgEAHgBIADAAQABAEAFABIgEAGIgBAEQgGADgFAFIgDAAIgDAAQgFAAgCgCg");
	this.shape_87.setTransform(6,10.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#57AE3A").s().p("AAZA/QgEhLgugwQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABgBAAAAQABAAAAABQAAAAABAAQAXAZAOAhQANAfgBAkIgBABIgBgBg");
	this.shape_88.setTransform(12,16.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#4FAA35").s().p("AAqAyQgPglgNgPQgSgagpgTQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAlAPAXAXQAfAcAAAhQAAABAAAAQgBABAAAAQAAABAAAAQgBAAAAAAIgCABIgCgCg");
	this.shape_89.setTransform(10.7,20.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFF4E0").s().p("AgDAFIgBgCQgCgCgDgBIAAgBQAAgEADgBQACgCAEABQAFABACAEQADACAAADIAAABQgBADgDABQgEgDgFAAg");
	this.shape_90.setTransform(23.5,3.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFF4E0").s().p("AgCAGIgCgBIgGgFQgCgDACgCQAEgEALAHIABABQADABACACIABABIgBAAQgFABAAAEIgIgCg");
	this.shape_91.setTransform(21.9,3.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFF4E0").s().p("AgJABQgCgBACgDQABgCAFgBIACAAIAHACQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABIADACQgBAAAAABQgBAAAAAAQAAABgBABQAAAAAAABIgCABIgDAAQgIAAgEgGg");
	this.shape_92.setTransform(21.9,4.6);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFF4E0").s().p("AAAAIQgDgBgEgEIgCgFIAAgBQABgBAAgBQAAAAABgBQAAAAAAgBQABAAAAAAQAGADAEAAIABACIAFACIAAACQAAADgDACIgEABIgDAAg");
	this.shape_93.setTransform(23.6,5.7);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFF4E0").s().p("AgEAEIgCgBIgEgDIgBgCIABAAQAGgBgBgEIAHACIACABQAFADABABQADAEgCADQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAgBAAQgEAAgGgEg");
	this.shape_94.setTransform(25.3,5.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FABD54").s().p("AgFAEIgDgDQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgEAFgBIABAAQAGAAAEAEQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABIACACQABAEgGABIgBAAIgBABQgEAAgFgEg");
	this.shape_95.setTransform(23.6,4.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFF4E0").s().p("AACAHIgHgDIgCgDQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQACgBABgDIACAAQAJgCAGAHQACABgCADQgCACgEABg");
	this.shape_96.setTransform(25.3,4.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#3FA635").s().p("Ag0BnQgHgjAPg1IAEgPIgBgUIgCgQIAGABIAAAAIACAUQALgfARgMQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQASglAVgKQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQggAWgYA+QgJAVgFAXIgCAUIAUgcQARgZALgLQAWgWATAEIABABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBAAQgWAGgSARQgNALgPAYQgPAUgIAOIgGAUIgBAPQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAgGQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBIAAAEIAAAJQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAAAAAIgCgCgAgoAQQgIAfgBAcIACgGIAGghIABgUgAgigBIABALQAFgRAJgWIALgWQgUAigGAQg");
	this.shape_97.setTransform(19.7,14.7);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#D7F9FE").s().p("AgIAFIAAgBIABgFQADgEAEgCQADgCADACQADABAAAEIAAABIgDADIgBACQgFABgEAEQgDAAgBgEg");
	this.shape_98.setTransform(7.9,4.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D7F9FE").s().p("AgJAFIgBAAIABgCIADgEIACgBQAEgDADgCQAFgBACABQADACgDAEIgFAFIgBABQgEABgDACQgCgDgEAAg");
	this.shape_99.setTransform(9.5,4.6);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#D7F9FE").s().p("AgGAHQgBgCgDgBIADgEIABgDQADgCAEgBIACAAQAEAAACACQADACgCACQgEAHgKAAg");
	this.shape_100.setTransform(9.8,5.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#D7F9FE").s().p("AgFAIQgDgBAAgDIAAgCIADgDIABgCQAFgBAEgEQADABABADIAAABQABADgCACQgCAEgFACIgDABIgDgBg");
	this.shape_101.setTransform(8.2,7.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#D7F9FE").s().p("AgJAIQgDgCADgEIAFgFIABgCIAHgDQAAAEAGAAIABAAIgBACIgDADIgCACQgFAGgFAAIgEgBg");
	this.shape_102.setTransform(6.6,7.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FCA839").s().p("AgEAIQgFAAAAgEIABgEIACgCQAFgEAEgBIABAAQAFAAABADIgBAEIgCADQgFAEgEABg");
	this.shape_103.setTransform(8.1,5.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#D7F9FE").s().p("AgJAAQAFgHAJAAIACAAQABAEADABIgDACIgBADIgHAEIgCABQgKgBADgHg");
	this.shape_104.setTransform(6.3,5.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#C4F6FE").s().p("AgDAFIgBgBIgEgEIgBgBQAAgDADgCQADgCADABQAEACAEADIACAFIAAABQgBABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgFgDgFAAg");
	this.shape_105.setTransform(3.6,9.5);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#C4F6FE").s().p("AgBAHIgCgBIgGgFQgDgDACgDQAFgEAKAHIACABIAEADIABACIgBAAQgEAAgBAEQgEgCgDABg");
	this.shape_106.setTransform(2,9.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#C4F6FE").s().p("AgJABQgCgBACgDQABgCAFgBIABAAQAEAAAEABQAAABAAAAQAAABAAABQABAAAAABQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABABAAQgDABAAADIgCABIgDAAQgIAAgEgGg");
	this.shape_107.setTransform(2,11);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#C4F6FE").s().p("AABAIQgDgBgEgEIgDgFIABgBQAAgDADgBQAEADAFAAIAGAFIAAABQAAAEgDABIgEABIgCAAg");
	this.shape_108.setTransform(3.7,12);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#C4F6FE").s().p("AgEAEIgBgBIgGgFIABAAQAGAAgBgFQAEAAAEACIACABIAGAEQACAFgCACQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgFAAgGgEg");
	this.shape_109.setTransform(5.3,11.8);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FCA839").s().p("AAFAHQgGABgEgEQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBQgBgBAAAAQAAAAAAAAQgBgBAAAAQAAgBAAgBQABgDAEAAIABAAQAGAAAEACIADADIACADQABAFgGAAg");
	this.shape_110.setTransform(3.7,10.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#C4F6FE").s().p("AACAHQgEgDgDAAIgCgDIgDgCQABAAAAgBQAAAAABAAQAAgBAAgBQABAAAAgBIACgBQALgBAEAHQACABgCADQgBACgFABg");
	this.shape_111.setTransform(5.4,10.6);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#C4F6FE").s().p("AgLADIAAgCQABgCADgDQAGgEADAAQAFAAADADQADACgBADIAAACIgGAEIgCABQgGgBgHADQgCgDAAgDg");
	this.shape_112.setTransform(12.3,9.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#C4F6FE").s().p("AgIAHQAAgEgFgCIgBAAIACgBIAGgEIACAAQAOgGAEAGQADADgFADQgDADgFACIgDABQgDgCgGABg");
	this.shape_113.setTransform(14.2,9.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#C4F6FE").s().p("AgIAHIgCgBQAAgEgCgCIAEgCQACgBABgEQAFgBAEACIACAAQAGACABADQACADgEACQgDADgGABIgCAAIgIgBg");
	this.shape_114.setTransform(13.9,11.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#C4F6FE").s().p("AgJAGQgDgDABgDIABgBIAFgEIACgCQAFACAIgDQACACAAAEIAAABQAAADgEACQgEAEgFABQgFAAgDgDg");
	this.shape_115.setTransform(11.6,12.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#C4F6FE").s().p("AgGAIQgFAAgCgDQgDgDAFgDIAIgEIAMgCQgBAGAGABIABAAIgCACIgFADIgDABQgFACgEAAIgCAAg");
	this.shape_116.setTransform(9.7,11.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FCA839").s().p("AgGAIIgBAAQgHgCACgGIACgDIAFgCQAGgDAHABIABABQAFABAAAFQgBACgCACIgFADIgIABIgEAAg");
	this.shape_117.setTransform(12,10.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#C4F6FE").s().p("AgFAHQgFgCgCgDQgBgCADgDQADgDAGAAQAFgBAFACIACAAQAAAEACABIgEADIgDADIgJACg");
	this.shape_118.setTransform(10,10);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#C4F6FE").s().p("AgLADIAAgBQAAgDAEgCQAEgEAFgBQAFAAADADQADADgBADIgBABIgFAEIgCACQgFgCgIADQgDgDABgDg");
	this.shape_119.setTransform(20.4,11);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#C4F6FE").s().p("AgIAHQAAgDgFgDIgBAAIACgBIAFgDIADgBQAFgCAGAAQAFAAACACQACADgEAEIgIAEIgDAAIgJAAg");
	this.shape_120.setTransform(22.3,11.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#C4F6FE").s().p("AgIAHIgCgBQAAgDgCgDIAEgCQADgCAAgDIAJABIACAAQAFACACADQABADgDACQgDADgGABIgDAAIgHgBg");
	this.shape_121.setTransform(22,13.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#C4F6FE").s().p("AgJAGQgDgDABgDIAAgBIAGgEIACgBQAGABAHgDQACADAAADIAAABQgBACgDADQgFAFgFAAIgBAAQgEAAgCgDg");
	this.shape_122.setTransform(19.7,14.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#C4F6FE").s().p("AgGAIQgFAAgCgCQgDgDAFgDQADgDAFgCIADgBQAFgBAEAAQgCAFAHACIABAAIgCACIgGADIgCABQgFACgEAAIgCAAg");
	this.shape_123.setTransform(17.8,13.3);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FCA839").s().p("AgHAIIgBgBQgHgCADgFIACgDIAFgDQAHgDAFACIABAAQAGADAAADQgBACgCACIgFADQgEACgEAAIgFAAg");
	this.shape_124.setTransform(20.1,12.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#C4F6FE").s().p("AgFAHQgGgCgBgDQgCgCAEgDQAHgGAMAEIACABQAAADACABIgEADIgDAEQgEgBgFACg");
	this.shape_125.setTransform(18.1,11.9);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#308028").s().p("AAbBSQgDgIgBgNIgBgWQgEgcgFgMQgRg6gmgWQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAvAdASAtQAaA/gJAdQgCAFgFAAIgBAAQgFAAgCgEg");
	this.shape_126.setTransform(10.4,17.4);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFF4E0").s().p("AgGAIIgCgDQgDgFgDgBIAAgCQgBgFAFgDQAEgDAGACQAHACAFAHQADADAAAEIAAACQAAAFgFACQgJgGgHABg");
	this.shape_127.setTransform(18.4,6.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFF4E0").s().p("AgDAKIgDgCQgGgEgEgEQgEgGADgDQAEgDAHACQAGABAIAFIACABQAEACADAEIACADIgCAAQgHABgBAFQgFgCgHAAg");
	this.shape_128.setTransform(15.8,6.3);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFF4E0").s().p("AgEAJQgHgCgEgFQgDgDADgEQADgEAHgBIADAAQAHAAAFADQAAAEACADIAFAEQgEACgBAEIgCABIgEAAQgGAAgEgCg");
	this.shape_129.setTransform(15.7,8.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFF4E0").s().p("AAAANQgGgCgFgHQgDgDAAgFIAAgCQAAgEAFgCQAJAGAHgBIACADIAGAGIAAACQABAFgFADQgCABgEAAIgFAAg");
	this.shape_130.setTransform(18.5,10);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFF4E0").s().p("AAHANQgHgCgHgFIgDgBIgGgGIgCgCIABAAQAKgBgBgIQAGABAGADIADACIAJAHQAFAIgEACQgCACgEAAIgEAAg");
	this.shape_131.setTransform(21.1,9.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FABD54").s().p("AgJAGIgFgFQgCgCAAgEQABgFAHgBIACAAQAHgBAJAGIAFAFIACAEQABAIgJABIgCAAIgCAAQgGAAgIgGg");
	this.shape_132.setTransform(18.4,8.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFF4E0").s().p("AAEALQgHgEgGgBIgCgFIgFgEQAEgCABgFIACAAQAIgBAGADQAHACAEAFQADADgDAEQgDAEgHABg");
	this.shape_133.setTransform(21.1,7.8);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#3FA635").s().p("AgTBDQgJgjALgjQALgjAbgcQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQglA1gDAnQgCAVAFASg");
	this.shape_134.setTransform(16.2,13.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#308028").s().p("AgfBBQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAgBQgEghAWglQATgjAdgVQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQgfAkgLAaQgFALgGAUQgGAXgDAJQAAABgBAAQAAABAAAAQAAAAgBAAQAAABgBAAIgBgBg");
	this.shape_135.setTransform(16.9,19.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#D7F9FE").s().p("AgDAFIgBgCIgEgDIgBgBQAAgDADgCQADgCADABQAEABAEAEIACAFIAAABQAAADgDABQgGgDgEAAg");
	this.shape_136.setTransform(18.2,2.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#D7F9FE").s().p("AgBAGIgCgBIgGgFQgDgCACgDQAFgEAKAHIACABIAEADIABACIgBAAQgEAAgBAEQgDgCgEAAg");
	this.shape_137.setTransform(16.5,2.8);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#D7F9FE").s().p("AgJACQAAgBgBgBQAAAAAAAAQAAgBAAAAQABgBAAAAQACgDAEAAIABgBQAEAAAEACQAAAAAAABQAAAAAAABQABABAAAAQAAABAAAAIAEACQgDACAAADIgCAAIgDAAQgIAAgEgFg");
	this.shape_138.setTransform(16.6,4.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#D7F9FE").s().p("AAAAIQgEgBgDgEQgCgCAAgDIAAgBQAAgCADgCQAEADAGAAIABACIAEADIABABQAAAGgHAAIgDAAg");
	this.shape_139.setTransform(18.3,5.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#D7F9FE").s().p("AAEAIQgEgBgEgDIgCgBIgEgDIgBgBIABAAQAGgBgBgFQAEAAADADIACABIAGAEQAEAEgDACQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAIgDAAg");
	this.shape_140.setTransform(19.9,4.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FCA839").s().p("AAFAIQgGAAgEgEIgEgDQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQABgEAEAAIABAAQAEgBAGAEIADADIACACQABAFgHABg");
	this.shape_141.setTransform(18.3,3.9);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#D7F9FE").s().p("AACAHQgDgDgEAAIgCgDIgDgCQADgBAAgDIACgBQAEAAAEABQAFACACACQACACgCADQgBACgFABg");
	this.shape_142.setTransform(19.9,3.7);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#2D8234").s().p("AAKBcIgCgGQgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAABAAIAAgEQgEgQAAgXQgDgPgFgQQgNgrgZggIAAgCIACAAQAPAKALAWQAGANAIAaIAFASQACgbAIgiQAFgYADgIQAIgUANgCQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQgOAHgIAaQgDAKgFAeQgFAbAAAYIAAAKQAEARgCANIACASIgCACIgBAAIAAgBg");
	this.shape_143.setTransform(13.5,13.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#2D8234").s().p("AAfBFQAFghgagnQgggsgOgUIABgCIABAAQAiAhAXAvIALAdQAGATgHALIgBAAIgBgBg");
	this.shape_144.setTransform(8.1,17.9);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#2D8234").s().p("Ag0A9QACgVAMgVQALgUAPgPIAcgcQATgPARgCQABAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQgdAGgjAtQgLAMgKAVIgRAkIgBABIgBgBg");
	this.shape_145.setTransform(20.6,17.6);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FAFBFD").s().p("AAAAPQgbAAgSgLIgDgCIgEgPQAEADADACQASAKAbAAQAZABATgKIAJgHIgEAPIgFAEQgSAKgZAAIgBAAg");
	this.shape_146.setTransform(13.7,29.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#F5963F").s().p("AggAjQgKgGgCgIIgRg/QADALAOAIQASALAaAAQAZAAATgLQAPgHADgMIgQA/QgDAJgLAGQgOAHgSAAQgTAAgNgIg");
	this.shape_147.setTransform(13.6,29);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#4B2306").s().p("AgpAUQgPgKABgKQAAgLAQgJQAQgJAXAAQAZAAARAKQAPAJAAAKQAAALgQAKQgSAJgXAAQgYAAgRgKg");
	this.shape_148.setTransform(13.6,24.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#F3C65B").s().p("AgtAaQgRgLAAgPQABgPASgKQATgLAZABQAaAAASALQATALgBAOQgBAPgSAKQgTALgaAAQgaAAgSgLg");
	this.shape_149.setTransform(13.7,24);

	var maskedShapeInstanceList = [this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0,0,28.3,33.4), null);


(lib.walk = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Left Hand-2
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(6,-41.1,1,1,29.3,0,0,0.1,-19.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({rotation:19.1,x:14.6,y:-39.9},0).wait(3).to({regY:-19.8,rotation:14.3,x:18.6,y:-40.1},0).wait(3).to({regY:-19.7,rotation:2.1,x:28.7,y:-41.4},0).wait(3).to({rotation:-4.4,x:34,y:-43},0).wait(3).to({regY:-19.8,rotation:14.3,x:18.6,y:-40.1},0).wait(3).to({regY:-19.7,rotation:22.8,x:11.4,y:-40.2},0).wait(3).to({regY:-19.8,y:-40.3},0).wait(3));

	// Left Hand-Palm
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.2,-0.3,1,1,22.2,0,0,3,-7.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({regY:-7.3,rotation:12,x:2,y:3.8},0).wait(3).to({regY:-7.4,rotation:7.2,x:9.7,y:4.7},0).wait(3).to({regY:-7.3,rotation:-5,x:29.5,y:4.3},0).wait(3).to({rotation:-11.5,x:39.9,y:2.2},0).wait(3).to({regY:-7.4,rotation:7.2,x:9.7,y:4.7},0).wait(3).to({regX:2.9,regY:-7.3,rotation:15.8,x:-4.1,y:2.7},0).wait(3).to({x:-4.2},0).wait(3));

	// Left Hand-1
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.9,-88.4,1,1,22.2,0,0,-2,-21.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({rotation:12},0).wait(3).to({rotation:7.2},0).wait(3).to({rotation:-5,x:16.8},0).wait(3).to({rotation:-11.5,x:16.9},0).wait(3).to({rotation:7.2},0).wait(3).to({rotation:15.8,x:17},0).wait(3).to({x:16.9},0).wait(3));

	// head
	this.instance_3 = new lib.ClipGroup_2_5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-18.5,15.1,3.598,3.598,0,0,0,15.7,47.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24));

	// Body
	this.instance_4 = new lib.ClipGroup_3_8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-10.1,-52.7,3.598,3.598,0,0,0,10.1,16.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24));

	// main'
	this.instance_5 = new lib.Tween5("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-9.2,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3).to({startPosition:0},0).wait(3));

	// left leg-1
	this.instance_6 = new lib.Tween6("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-1.2,-2.8,1.017,0.846,0,-10.9,-14,-3.6,-37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({scaleY:0.92,skewX:4.1,skewY:1,x:-0.8,y:-2.5},0).wait(3).to({regX:-3.8,regY:-37.1,scaleY:0.89,skewX:23.4,skewY:20.2,x:-1.1,y:-2.8},0).wait(3).to({regX:-3.7,regY:-37.2,skewX:14.2,skewY:11,x:-1,y:-2.6},0).wait(3).to({regX:-3.6,regY:-37.1,scaleY:0.97,skewX:14.5,skewY:11.2,x:-1.6,y:-2.7},0).wait(3).to({scaleX:1.01,scaleY:0.91,skewX:3.4,skewY:-1.4,y:-2.9},0).wait(3).to({regX:-3.5,regY:-37,scaleX:1.03,scaleY:0.88,skewX:-3.7,skewY:-18.1,y:-3},0).wait(3).to({regY:-36.8,scaleX:1.03,scaleY:0.81,skewX:-7.2,skewY:-20.1,x:-0.3,y:0.9},0).wait(3));

	// left leg-2
	this.instance_7 = new lib.Tween7("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(16.7,52.6,1.081,0.8,0,-29.8,-28.1,0.1,-35.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(3).to({regX:0.2,regY:-34.9,scaleX:0.96,scaleY:0.82,skewX:-25.8,skewY:-34.2,x:0.4,y:64.6},0).wait(3).to({regX:0.1,regY:-34.5,scaleX:1.06,scaleY:0.83,rotation:-48.1,skewX:0,skewY:0,x:-23.4,y:54.3},0).wait(3).to({regY:-34.4,scaleY:1.15,rotation:3.9,x:-9,y:57.2},0).wait(3).to({rotation:9.6,x:-13.1,y:71.9},0).wait(3).to({regY:-34.3,scaleX:1.06,scaleY:1.08,rotation:0,skewX:-1.7,skewY:-2.9,x:0.5,y:61.3},0).wait(3).to({regY:-34.2,scaleX:1.08,scaleY:1.02,skewX:-9,skewY:-19.5,x:8.1,y:56.9},0).wait(3).to({scaleX:1.07,scaleY:0.95,skewX:-23.7,skewY:-32.1,x:10.9,y:51.6},0).wait(3));

	// right leg-1
	this.instance_8 = new lib.Tween8("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-25.3,2.1,1,0.949,0,9.1,9.5,-0.3,-32.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(3).to({regX:-0.2,regY:-32.3,scaleX:1,scaleY:0.94,skewX:-4.7,skewY:-10.1,x:-28.3,y:-14.3},0).wait(3).to({regY:-32.4,scaleY:0.98,skewX:-11.9,skewY:-17.3,x:-28.4,y:-19},0).wait(3).to({regY:-32.3,scaleX:0.86,scaleY:0.86,skewX:-20.1,skewY:-25.5,x:-25.7,y:0.3},0).wait(3).to({regX:-0.3,skewX:-31.3,skewY:-36.8,x:-25.8},0).wait(3).to({regX:-0.2,skewX:-9.6,skewY:-15.1,x:-25.7},0).wait(3).to({regX:-0.4,regY:-32,scaleX:1.05,scaleY:0.9,skewX:5.4,skewY:16.2,x:-25.9,y:0.4},0).wait(3).to({startPosition:0},0).wait(3));

	// right leg-2
	this.instance_9 = new lib.Tween9("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-41.8,65.5,1,0.948,0,5.7,6.5,-1.9,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(3).to({regX:-2,regY:-35.1,scaleX:1.05,scaleY:0.92,skewX:-5.1,skewY:-17,x:-29.8,y:50.2},0).wait(3).to({skewX:-12.3,skewY:-24.2,x:-21,y:38.5},0).wait(3).to({regX:-2.1,skewX:-20.5,skewY:-32.4,x:-15},0).wait(3).to({regY:-35,skewX:-31.8,skewY:-43.7,x:-14.5,y:23.8},0).wait(3).to({regY:-34.9,scaleX:1.18,scaleY:0.74,skewX:-40.6,skewY:-50,x:-21.8,y:50.5},0).wait(3).to({regX:-2.2,regY:-35,scaleX:1.18,scaleY:0.84,skewX:-77.2,skewY:-84.3,x:-38.5,y:55.3},0).wait(3).to({regY:-34.8,scaleX:1.21,scaleY:0.87,skewX:-16.9,skewY:-37.9,x:-36.6,y:53.7},0).wait(3));

	// left shoe
	this.instance_10 = new lib.Tween11("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(58.7,111.9,1.08,0.801,0,-32.5,-29.6,6.7,-8.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(3).to({regY:-7.5,scaleX:1.03,scaleY:0.7,skewX:-28.2,skewY:-28.6,x:37.9,y:125.4},0).wait(3).to({regY:-7.7,scaleX:1.13,scaleY:0.83,skewX:-37.7,skewY:-34.3,x:35.4,y:98.4},0).wait(3).to({regY:-7.4,scaleX:1.14,skewX:2.6,skewY:9.3,x:-9.2,y:157.8},0).wait(3).to({scaleX:1.14,skewX:8.3,skewY:15,x:-23.3,y:171.9},0).wait(3).to({regY:-7.1,scaleY:0.78,skewX:-3.2,skewY:-10.6,x:11.3,y:156},0).wait(3).to({regX:6.8,scaleX:1.14,scaleY:0.73,skewX:-10.6,skewY:-14.8,x:28.5,y:143.1},0).wait(3).to({regY:-7,scaleX:1.14,scaleY:0.68,skewX:-25.3,skewY:-27.7,x:49.9,y:123.9},0).wait(3));

	// Right hand-2
	this.instance_11 = new lib.ClipGroup_1_12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-4.6,-66.4,3.598,3.598,-46.5,0,0,7.9,3.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(3).to({rotation:-27.2,x:-18.3,y:-57.8},0).wait(3).to({rotation:-8,x:-33.6,y:-55.4},0).wait(3).to({rotation:1.5,x:-41.9,y:-54.6},0).wait(3).to({rotation:8.3,x:-46.8,y:-56.9},0).wait(3).to({rotation:1.7,x:-39.9,y:-55.5},0).wait(3).to({rotation:-42.5,x:-6.9,y:-64.4},0).wait(3).to({rotation:-43.8,x:-6.3,y:-64.8},0).wait(3));

	// Right Hand-1
	this.instance_12 = new lib.ClipGroup_4_5();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-42.5,-101.4,3.598,3.598,-54.2,0,0,13.2,6.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(3).to({rotation:-35,y:-103.5},0).wait(3).to({rotation:-15.7,x:-41.5,y:-106.4},0).wait(3).to({rotation:-6.2,x:-41.3},0).wait(3).to({rotation:0.6,x:-40.2,y:-108.2},0).wait(3).to({rotation:-6,x:-39.1,y:-107.2},0).wait(3).to({rotation:-50.2,x:-42.4,y:-102},0).wait(3).to({rotation:-51.5,x:-42.5,y:-101.7},0).wait(3));

	// Right hand-palm
	this.instance_13 = new lib.Tween10("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(21.5,-21.4,1,1,-43.4,0,0,3.3,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(3).to({regX:3.2,rotation:-24.2,x:-8.5,y:-6.9},0).wait(3).to({regX:3.3,rotation:-5,x:-41.2,y:-4},0).wait(3).to({rotation:4.5,x:-57.9,y:-5.3},0).wait(3).to({regX:3.2,rotation:11.3,x:-68.6,y:-9.7},0).wait(3).to({regX:3.4,rotation:4.8,x:-56,y:-6.2},0).wait(3).to({rotation:-39.5,x:16,y:-17.8},0).wait(3).to({rotation:-40.7,x:17.7,y:-18.8},0).wait(3));

	// left leg
	this.instance_14 = new lib.Tween12("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(49.9,99.4,1.075,0.808,0,-38.9,-33.1,0,-7.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(3).to({regX:0.1,regY:-7.6,scaleX:1.04,scaleY:0.81,skewX:-34.4,skewY:-39.4,x:30.1,y:112},0).wait(3).to({regY:-7.4,scaleX:1.13,scaleY:0.83,skewX:-57.1,skewY:-52.8,x:23.5,y:87.4},0).wait(3).to({regY:-7.5,skewX:-1.8,skewY:2.5,x:-7.8,y:141.2},0).wait(3).to({skewX:3.9,skewY:8.2,x:-20.3,y:155.5},0).wait(3).to({regX:0,regY:-7.3,scaleX:1.13,scaleY:0.78,skewX:-7.8,skewY:-4.3,x:9.7,y:139.7},0).wait(3).to({regX:0.1,regY:-7.1,scaleX:1.16,scaleY:0.73,skewX:-15.6,skewY:-20.8,x:26.5,y:128.3},0).wait(3).to({regY:-7,scaleX:1.15,scaleY:0.68,skewX:-30.8,skewY:-33.2,x:44.8,y:111.2},0).wait(3));

	// right shoe
	this.instance_15 = new lib.Tween13("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-54.7,153.1,0.999,0.948,0,4.1,5,8.8,-8.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(3).to({scaleX:1.06,scaleY:0.79,skewX:-9.4,skewY:-10.1,x:-26.9,y:131.7},0).wait(3).to({skewX:-16.7,skewY:-17.3,x:-7.9,y:119.1},0).wait(3).to({regX:8.9,regY:-8.1,skewX:-24.9,skewY:-25.6,x:9.6,y:116.4},0).wait(3).to({regX:8.7,regY:-8,scaleX:1.06,scaleY:0.8,skewX:-30.4,skewY:-25.4,x:25.9,y:96.1},0).wait(3).to({regY:-7.9,scaleX:1.19,scaleY:0.65,skewX:-38.6,skewY:-36.9,x:18.6,y:104.2},0).wait(3).to({regX:8.6,regY:-7.8,scaleX:1.21,scaleY:0.73,skewX:-75.4,skewY:-69.6,x:34.1,y:76.1},0).wait(3).to({regY:-7.4,scaleX:1.17,scaleY:0.76,skewX:-15.2,skewY:-23,x:-17.5,y:130.8},0).wait(3));

	// right leg
	this.instance_16 = new lib.Tween14("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(-51.9,132.5,1,0.947,0,10.5,10.7,-0.2,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(3).to({regY:-7.9,scaleX:1.02,scaleY:0.84,skewX:-6.5,skewY:-19,x:-27.2,y:113.1},0).wait(3).to({regX:-0.3,skewX:-13.7,skewY:-26.2,x:-10.6,y:100.7},0).wait(3).to({regY:-7.8,skewX:-21.9,skewY:-34.4,x:4.2,y:98.6},0).wait(3).to({regX:-0.4,skewX:-33.1,skewY:-45.6,x:16.5,y:80.5},0).wait(3).to({regY:-7.7,scaleX:1.15,scaleY:0.68,skewX:-42.4,skewY:-51.4,x:9.2,y:92.8},0).wait(3).to({regY:-7.5,scaleY:0.77,skewX:-78.9,skewY:-85.9,x:18,y:72.1},0).wait(3).to({regX:-0.5,regY:-7.4,scaleX:1.19,scaleY:0.79,skewX:-18.5,skewY:-39.4,x:-22.4,y:114.1},0).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.1,-156.9,160.7,343.8);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_22();
	this.instance.parent = this;
	this.instance.setTransform(-4.5,0.1,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_1 = new lib.ClipGroup_2_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-4.5,0.1,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_2 = new lib.ClipGroup_3_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(3.9,-67.7,3.598,3.598,0,0,0,10.1,16.7);

	this.instance_3 = new lib.ClipGroup_1_12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-32.7,-42.8,3.597,3.597,-7.4,0,0,6.5,9.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgIAeQgKgEgEgPQAAgFACgGQAFgQAOgOIAYAJIAAAcQABAEgDADQgEAEgEgHIgCgMIgDAMQgDAOgDAFQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgHgBg");
	this.shape.setTransform(-40.1,-6.4,3.597,3.597,-14.1);

	this.instance_4 = new lib.ClipGroup_4_5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-27.3,-91.2,3.598,3.598,-6.6,0,0,13.3,13.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#142849").s().p("AgeA9QgugHgIgzIACgxIA8gRQAEgCAgACIAgACIASAIQATANABAeQABAZgcAXQgYAVgdAFIgGABQgKAAgSgEg");
	this.shape_1.setTransform(4.8,-20.7,3.598,3.598);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#142849").s().p("AgGCCQgQgFgFgVQgIghgFhlIgEhfQA6gHAVACQAKAAgCACQAEAkgFC/QgBANgGAIQgJANgTgCIgFABQgDAAgFgCg");
	this.shape_2.setTransform(19.6,19.5,3.598,3.598);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#142849").s().p("AgEB2QgYiJgHg+QgBgTANgLQAIgGALAAIASADQATAHABASIACDPg");
	this.shape_3.setTransform(22.3,86.7,3.598,3.598);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#142849").s().p("AgNB+QgMAAgKgJQgNgLABgUIAOiwQACgaAZgHQAYgIAQAVQANARABAbQAAANgCAKQgDANgUB8QgCAOgKAJQgKAJgLAAIgDAAg");
	this.shape_4.setTransform(-13.9,13.5,3.598,3.598);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#142849").s().p("AggB7IgCjdQAEgSASgIQAJgDAHAAQAWAGAHATQADAJgCAIQgSBxgIBkg");
	this.shape_5.setTransform(-18.7,83.8,3.598,3.598);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFF9F5").s().p("AgpAvQgCgCABgGQADgKAIgLIANgSQAJgNAEgGQAFgMgBgLQAQACAOgEQAIgBACgDQACACAAAEIACAqQgWAXgMAJQgUAQgVACQgIAAgBgDg");
	this.shape_6.setTransform(22.5,154.1,3.598,3.598);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFC0BF").s().p("AgSgkIAdAFIAIA4IghAMg");
	this.shape_7.setTransform(29.3,132.5,3.598,3.598);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFF9F5").s().p("AguAoQgCgDADgFQAEgJAJgKIAQgQQAVgXAAgQQAQADAPgBQAIgBADgCQABACgBAEIgDAqQgXATgPAIQgWAMgVAAQgIgBgBgDg");
	this.shape_8.setTransform(-32.1,152.7,3.598,3.598);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFC0BF").s().p("AgKgjIAcAIIAAA5IgjAGg");
	this.shape_9.setTransform(-23,131.2,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_4},{t:this.shape},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.4,-171.9,131.6,343.8);


(lib.Tween40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_21();
	this.instance.parent = this;
	this.instance.setTransform(7.3,-145.7,2.367,2.367,0,0,0,79,78.2);

	this.instance_1 = new lib.ClipGroup_1_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-93.6,-97.9,2.367,2.367,0,0,0,24.2,25);

	this.instance_2 = new lib.ClipGroup_3_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-37.4,-182.6,2.367,2.367,0,0,0,41.4,41.6);

	this.instance_3 = new lib.ClipGroup_5_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(39.5,-230.6,2.367,2.367,0,0,0,17.7,17);

	this.instance_4 = new lib.ClipGroup_6_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(84.5,-223.8,2.367,2.367,0,0,0,12.5,11.9);

	this.instance_5 = new lib.ClipGroup_2_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(72.2,242.2,1,1,0,0,0,1.8,1.8);

	this.instance_6 = new lib.ClipGroup_4_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(72.2,242.2,1,1,0,0,0,1.8,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179.7,-330.8,374.4,574.7);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_12();
	this.instance.parent = this;
	this.instance.setTransform(-1,8,3.598,3.598,154.2,0,0,6.5,9.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC0BF").s().p("AgIAeQgKgEgEgPQAAgFACgGQAFgQAOgOIAYAJIAAAcQABAEgDADQgEAEgEgHIgCgMIgDAMQgDAOgDAFQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgHgBg");
	this.shape.setTransform(-4.1,-29.3,3.598,3.598,0,-154.2,25.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.4,-40.2,71.4,89.1);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(8.1,-51,1,1,29.3,0,0,0.1,-19.7);

	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-12.1,-10.1,1,1,22.2,0,0,3,-7.4);

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(19,-98.2,1,1,22.2,0,0,-2,-21.9);

	this.instance_3 = new lib.ClipGroup_2_5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-16.4,5.3,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_4 = new lib.ClipGroup_3_8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-8,-62.6,3.598,3.598,0,0,0,10.1,16.7);

	this.instance_5 = new lib.Tween5("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-7.1,-15.5);

	this.instance_6 = new lib.Tween6("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(0.9,-12.6,1.017,0.846,0,-10.9,-14,-3.6,-37.3);

	this.instance_7 = new lib.Tween7("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(18.8,42.7,1.081,0.8,0,-29.8,-28.1,0.1,-35.2);

	this.instance_8 = new lib.Tween8("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-23.2,-7.8,1,0.949,0,9.1,9.5,-0.3,-32.2);

	this.instance_9 = new lib.Tween9("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-39.7,55.7,1,0.948,0,5.7,6.5,-1.9,-35);

	this.instance_10 = new lib.Tween11("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(60.8,102,1.08,0.801,0,-32.5,-29.6,6.7,-8.1);

	this.instance_11 = new lib.ClipGroup_1_12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-2.5,-76.2,3.598,3.598,-46.5,0,0,7.9,3.4);

	this.instance_12 = new lib.ClipGroup_4_5();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-40.4,-111.3,3.598,3.598,-54.2,0,0,13.2,6.8);

	this.instance_13 = new lib.Tween10("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(23.6,-31.3,1,1,-43.4,0,0,3.3,-7);

	this.instance_14 = new lib.Tween12("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(52,89.6,1.075,0.808,0,-38.9,-33.1,0,-7.9);

	this.instance_15 = new lib.Tween13("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-52.6,143.2,0.999,0.948,0,4.1,5,8.8,-8.2);

	this.instance_16 = new lib.Tween14("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(-49.8,122.7,1,0.947,0,10.5,10.7,-0.2,-8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88,-166.7,160.6,343.8);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#004579").s().p("AgdgKIAJgFIAyAaIgJAFg");
	this.shape.setTransform(-32.7,-67.5,4.819,4.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002845").s().p("AgGAFQgIgEgDgEQgEgEADgCQAHgFATAKQAHAEAEAEQADAEgDACQgDACgDAAQgHAAgMgHg");
	this.shape_1.setTransform(-53.8,-54.8,4.819,4.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00345C").s().p("AgbAiIAnhAQACgFADAAQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABIAJAgIg5Akg");
	this.shape_2.setTransform(-6.5,-92.7,4.819,4.819);

	this.instance = new lib.ClipGroup_1_6();
	this.instance.parent = this;
	this.instance.setTransform(-21.4,-77,4.819,4.819,0,0,0,0.4,0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002845").s().p("AgWAfIAnhAIAGADIgnBAg");
	this.shape_3.setTransform(-11.7,-92.7,4.819,4.819);

	this.instance_1 = new lib.ClipGroup_2_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-109.4,4.819,4.819,0,0,0,0.6,0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DD343A").s().p("AgFgHIALgDIAAASIgLADg");
	this.shape_4.setTransform(30.2,-83.5,4.819,4.819);

	this.instance_2 = new lib.ClipGroup_3_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,-0.1,4.819,4.819,0,0,0,15,23.1);

	this.instance_3 = new lib.ClipGroup_4_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-54.2,-41.8,4.819,4.819,0,0,0,3.4,1.7);

	this.instance_4 = new lib.ClipGroup_5_3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-71.3,-41.1,4.819,4.819,0,0,0,0.2,1.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#969696").s().p("AgSACIAkgWIABATIgkAWg");
	this.shape_5.setTransform(-28.8,-51,4.819,4.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#969696").s().p("AghAMIBDgqIAAATIhDAqg");
	this.shape_6.setTransform(-3.5,-67.1,4.819,4.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9D9D9D").s().p("AgUgBIApgPIAAASIgpAPg");
	this.shape_7.setTransform(23,-80.9,4.819,4.819);

	this.instance_5 = new lib.ClipGroup_6_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-35.2,-47.8,4.819,4.819,0,0,0,1.3,0.7);

	this.instance_6 = new lib.ClipGroup_7_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,-0.1,4.819,4.819,0,0,0,15,23.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002847").s().p("AgfAGIA+gVIABAKIg/AVg");
	this.shape_8.setTransform(-13.8,-53.5,4.819,4.819);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00203A").s().p("AgEACIAAgIIAJAFIAAAIg");
	this.shape_9.setTransform(-43.7,-50.1,4.819,4.819);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00203A").s().p("AgEACIAAgJIAJAGIAAAJg");
	this.shape_10.setTransform(-48.6,-52.6,4.819,4.819);

	this.instance_7 = new lib.ClipGroup_8_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-52.2,-55.8,4.819,4.819,0,0,0,0.4,1);

	this.instance_8 = new lib.ClipGroup_9_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(8.5,-60.3,4.819,4.819,0,0,0,1.5,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002847").s().p("AgbgBIA3gFIAAAIIg3AFg");
	this.shape_11.setTransform(29.3,-63.2,4.819,4.819);

	this.instance_9 = new lib.ClipGroup_10_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(45,-65.6,4.819,4.819,0,0,0,0.5,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(0,0,0,0.098)").s().p("AiCBOQgGgDADgMQAEgPAQgKIAsgcIAcggQAIgJABgJIAEghQABgEAEgBQAFgCAGACIBLAXQAGACAHADIAKAHIAvAqQADACgCADQgCADgHABIg4AFQgQACgOAFIg9AWIgEAAIgkAXQgQAKgYAEIgRABQgHAAgEgCg");
	this.shape_12.setTransform(7.3,72.8,4.819,4.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.instance_9},{t:this.shape_11},{t:this.instance_8},{t:this.instance_7},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.instance_6},{t:this.instance_5},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.shape_4},{t:this.instance_1},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.3,-111.4,144.6,222.8);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AguG/IAAt9IBdAAIAAN9g");
	var mask_graphics_1 = new cjs.Graphics().p("AhYG/IAAt9ICpAAIAAN9g");
	var mask_graphics_2 = new cjs.Graphics().p("Ah6G/IAAt9ID1AAIAAN9g");
	var mask_graphics_3 = new cjs.Graphics().p("AigG/IAAt9IFBAAIAAN9g");
	var mask_graphics_4 = new cjs.Graphics().p("AjHG/IAAt9IGPAAIAAN9g");
	var mask_graphics_5 = new cjs.Graphics().p("AjtG/IAAt9IHbAAIAAN9g");
	var mask_graphics_6 = new cjs.Graphics().p("AkTG/IAAt9IInAAIAAN9g");
	var mask_graphics_7 = new cjs.Graphics().p("Ak5G/IAAt9IJzAAIAAN9g");
	var mask_graphics_8 = new cjs.Graphics().p("AlgG/IAAt9ILBAAIAAN9g");
	var mask_graphics_9 = new cjs.Graphics().p("AmGG/IAAt9IMNAAIAAN9g");
	var mask_graphics_10 = new cjs.Graphics().p("AmsG/IAAt9INZAAIAAN9g");
	var mask_graphics_11 = new cjs.Graphics().p("AnSG/IAAt9IOlAAIAAN9g");
	var mask_graphics_12 = new cjs.Graphics().p("An4G/IAAt9IPxAAIAAN9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-13,y:24.1}).wait(1).to({graphics:mask_graphics_1,x:-8.9,y:24.1}).wait(1).to({graphics:mask_graphics_2,x:-5.4,y:24.1}).wait(1).to({graphics:mask_graphics_3,x:-1.6,y:24.1}).wait(1).to({graphics:mask_graphics_4,x:2.3,y:24.1}).wait(1).to({graphics:mask_graphics_5,x:6.1,y:24.1}).wait(1).to({graphics:mask_graphics_6,x:9.9,y:24.1}).wait(1).to({graphics:mask_graphics_7,x:13.7,y:24.1}).wait(1).to({graphics:mask_graphics_8,x:17.5,y:24.1}).wait(1).to({graphics:mask_graphics_9,x:21.4,y:24.1}).wait(1).to({graphics:mask_graphics_10,x:25.2,y:24.1}).wait(1).to({graphics:mask_graphics_11,x:29,y:24.1}).wait(1).to({graphics:mask_graphics_12,x:32.8,y:24.1}).wait(111));

	// Tracker
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BF8FE").s().p("ADTE5IAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAJIAAAAIgBABIAAABIgBgBgADHEpIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBgBgAC7EZIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgACvEKIAAgBIgGgIIgBgBIABgBIABAAIABABIAGAHIAAACIgBAAIAAABIgBAAgACjD5IAAAAIgGgIIgBgBIABgBIABAAIABABIAGAIIAAABIgBAAIAAABIgBgBgACXDpIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgACLDZIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBgBgAB/DKIAAgBIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBAAgABzC6IAAgBIgGgIIgBgBIABgBIABAAIABABIAGAIIAAABIAAAAIgBABIgBAAgABnCpIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAJIAAAAIgBABIAAABIgBgBgABbCZIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBgBgABPCJIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgABDB6IAAgBIgGgIIgBgBIABgBIABAAIABABIAGAHIAAACIgBAAIAAABIgBAAgAA3BpIAAAAIgGgIIgBgBIABgBIABAAIABABIAGAIIAAABIgBAAIAAABIgBgBgAArBZIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgAAfBJIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBgBgAATA6IAAgBIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIgBABIAAABIgBAAgAAHAqIAAgBIgGgIIgBgBIABgBIABAAIABABIAGAIIAAABIAAAAIgBABIgBAAgAgEAZIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAJIAAAAIgBABIAAABIgBgBgAgQAJIAAAAIgGgIIgBgBIABAAIABAAIABAAIAGAHIAAABIgBABIAAABIgBgBgAgcgGIAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgAgogVIAAgBIgGgIIgBgBIABgBIABAAIABABIAGAHIAAACIgBAAIAAABIgBAAgAg0gmIAAAAIgGgIIgBgBIABgBIABAAIABABIAGAIIAAABIgBAAIAAABIgBgBgAhAg2IAAAAIgGgIIgBgBIABgBIABAAIABAAIAGAIIAAABIAAABIgBABIgBgBgAhMhGIAAAAIgGgIIAAgBIAAgBIACAAIAAAAIAGAIIAAABIgBABIAAABIgBgBgAhWhVIgBgBIgGgIIAAgBIAAgBIABAAIABAAIAGAIIAAABIAAABIgBABIAAAAgAhhhlIgBgBIgFgIIAAgBIAAgBIABAAIABABIAFAIIAAABIAAAAIgBABIAAAAgAhsh2IgBAAIgFgIIAAgBIAAgBIABAAIABAAIAFAJIAAAAIAAABIgBABIAAgBgAh2iGIgBAAIgFgIIAAgBIAAgBIABAAIABAAIAFAIIABABIgBABIgBABIAAgBgAiAiWIgBAAIgGgIIAAgBIABgBIAAAAIABAAIAGAIIAAABIAAABIgBABIAAgBgAiLilIgBgBIgFgIIAAgBIAAgBIACAAIAAABIAFAHIAAACIAAAAIgBABIAAAAgAiWi2IgBAAIgFgIIAAgBIAAgBIABAAIABABIAFAIIAAABIAAAAIgBABIAAgBgAigjGIgBAAIgFgIIAAgBIAAgBIABAAIABAAIAFAIIAAABIAAABIgBABIAAgBgAirjWIgBAAIgFgIIAAgBIAAgBIABAAIABAAIAFAIIAAABIAAABIgBABIAAgBgAi1jlIgBgBIgGgIIAAgBIAAgBIABAAIABAAIAGAIIABABIgBABIgBABIAAAAgAjAj2IgBAAIgGgIIAAgBIAAgBIACAAIAAAAIAGAIIAAABIAAABIgBAAIAAAAgAjLkHIgBAAIgIgNIAAgBIAAAAIABgBIAEAAIABABIAAABIAAABIgBAAIgCAAIAHAKIAAABIAAABIgBAAIAAAAgAjFkUIgBgBIAAgBIABgBIAKgBIABABIAAABIAAAAIgBABIgKABIAAAAIAAAAgAiykWIAAgBIAAgBIABgBIAKAAIABAAIAAABIAAAAIgBABIgKABIAAAAIgBAAgAiekYIAAgBIAAgBIABAAIAKgBIABAAIAAABIAAABIgBAAIgKABIAAAAIgBAAgAiKkaIAAgBIAAgBIABgBIAKgBIABABIABABIgBABIgBAAIgKABIAAAAIgBAAgAh2kcIAAgBIAAgBIABgBIAKgBIABABIAAABIAAAAIgBABIgJABIgBAAIgBAAgAhikeIAAgBIAAgBIABgBIAKgBIABABIAAABIAAAAIgBABIgKABIAAAAIgBAAgAhOkgIAAgBIAAgBIABAAIAKgBIABAAIAAABIAAAAIgBABIgKABIAAAAIgBAAgAg6kiIAAgBIAAgBIABAAIAKgCIABABIAAABIAAABIgBAAIgKABIAAAAIgBAAgAgmkkIAAgBIAAgBIABgBIAKgBIABABIAAABIAAAAIAAABIgLABIAAAAIgBAAgAgRkmIgBgBIAAgBIABgBIAKgBIABABIAAABIAAAAIgBABIgKABIAAAAIAAAAgAABkoIAAgBIAAgBIABgBIAKAAIABAAIAAABIAAAAIgBABIgKABIAAAAIgBAAgAAVkqIAAgBIAAgBIABAAIAKgBIABAAIAAABIAAABIgBAAIgKABIAAAAIgBAAgAApksIAAgBIAAgBIABgBIAKgBIABABIABABIgBABIgBAAIgKABIAAAAIgBAAgAA9kuIAAgBIAAgBIABgBIAKgBIABABIAAABIAAAAIgBABIgJABIgBAAIgBAAgABckwIgKAAIgBAAIAAgBIAAgBIABgBIAKAAIABABIAAABIAAABIgBAAIAAAAgABwkxIgKAAIgBAAIAAgBIAAgBIABgBIAKAAIABABIAAABIAAABIgBAAIAAAAgACEkyIgKAAIgBAAIAAgBIAAgBIABAAIAKAAIABAAIAAABIAAABIgBAAIAAAAgACYkzIgKAAIgBAAIAAgBIAAgBIABAAIAKAAIABAAIAAABIAAABIgBAAIAAAAgACsk0IgKAAIgBAAIAAgBIAAgBIABAAIAKAAIABAAIAAABIAAABIgBAAIAAAAgADAk1IgKAAIgBAAIAAgBIAAgBIABgBIAKAAIABABIAAABIAAABIgBAAIAAAAgADLk2IgBAAIgBAAIAAgBIAAgBIABgBIABAAIABABIAAABIAAABIgBAAIAAAAg");
	this.shape.setTransform(18.3,30.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1BF8FE").s().p("ADWCAIgJgFIgBAAIAAgBIABgBIABAAIAJAFIABABIgBABIAAABIgBAAIAAgBgADEB2IgJgFIgBAAIAAgBIABgBIABAAIAJAFIABABIgBABIAAAAIgBABIAAgBgACyBsIgJgFIgBAAIAAgBIABgBIABAAIAJAFIABABIgBABIAAAAIgBABIAAgBgACgBiIgJgFIgBAAIAAgBIABgBIABAAIAJAFIABABIgBABIAAAAIgBABIAAgBgACOBYIgJgFIgBgBIAAAAIABgBIABAAIAJAFIABABIgBABIAAAAIgBABIAAgBgAB8BOIgJgFIgBgBIAAAAIABgBIABAAIAJAFIABABIgBABIAAAAIgBABIAAgBgABqBEIgJgFIgBgBIAAAAIABgBIABAAIAJAFIABABIgBABIAAABIgBAAIAAgBgABYA6IgJgFIgBgBIAAAAIABgBIABAAIAJAFIABABIgBABIAAABIgBAAIAAgBgABGAwIgJgFIgBgBIAAAAIABgBIABAAIAJAFIABABIgBABIAAABIgBAAIAAgBgAA0AmIgJgFIgBAAIAAgBIABgBIABAAIAJAFIABABIgBABIAAABIgBAAIAAgBgAAiAcIgJgFIAAAAIAAgBIABgBIAAAAIAJAFIABABIAAABIgBAAIAAABIgBgBgAAQASIgIgFIAAAAIAAgBIABgBIABAAIAIAFIAAABIAAABIgBAAIAAABIgBgBgAAAAIIgHgFIAAAAIAAgCIAAAAIABAAIAHAFIABABIAAABIgBAAIAAABIgBgBgAgPgBIgIgFIgBgBIABgBIAAAAIABAAIAIAFIABABIAAABIgBAAIAAABIgBgBgAgfgLIgIgFIgBgBIABgBIAAAAIACAAIAHAFIABABIAAABIgBAAIAAABIgBgBgAgvgVIgIgFIAAgBIAAgBIABAAIABAAIAIAFIAAABIAAABIgBABIAAAAIgBgBgAg/gfIgIgFIAAgBIAAgBIABAAIAAAAIAJAFIAAABIAAABIgBABIAAAAIgBgBgAhPgpIgIgFIgBgBIABAAIAAgBIABAAIAIAFIABABIAAABIgBABIAAAAIgBgBgACtgrIgIgCIgBAAIAAgBIAAgBIABAAIAIACIABAAIAAABIAAABIgBABIAAgBgACbgvIgKgCIgBgBIAAgBIABgBIAAAAIAKACIABABIAAABIAAAAIgBABIAAAAgAhggzIgIgFIgBAAIABgBIAAgBIABAAIAIAFIABABIAAABIgBABIAAAAIgBgBgACIg1IgKgCIgBAAIAAgBIAAgBIABAAIAKACIABAAIAAABIgBABIAAABIAAgBgAB0g5IgKgCIgBgBIgBgBIABgBIABAAIAKACIABABIAAABIAAAAIgBABIAAAAgAhwg9IgIgFIgBAAIABgBIAAgBIACAAIAHAFIABABIAAABIgBAAIAAABIgBgBgABfg/IgKgCIAAAAIgBgBIABgBIABAAIAKACIABAAIAAABIAAABIgBABIgBgBgABLhDIgKgCIAAgBIgBgBIABAAIABgBIAKACIABABIAAABIgBABIAAAAIgBAAgAiAhHIgIgFIAAAAIAAgBIABgBIABAAIAIAFIAAABIAAABIgBAAIAAABIgBgBgAA3hHIgJgCIgBgBIAAAAIAAgBIABAAIAKABIABABIAAABIgBABIAAAAIgBAAgAAkhLIgKgCIgBAAIAAgCIAAAAIABgBIAKADIABAAIAAABIAAABIgBAAIAAAAgAAQhPIgLgCIAAgBIgBgBIABAAIABAAIAKABIABABIAAABIAAABIgBAAIAAAAgAiQhRIgIgFIAAAAIAAgCIABAAIAAAAIAJAFIAAABIAAABIgBAAIAAABIgBgBgAgEhTIgKgCIAAAAIgBgBIABgBIABgBIAKADIABAAIAAABIgBABIAAAAIgBAAgAgYhXIgKgCIAAgBIAAgBIAAAAIABgBIAKACIABABIAAABIgBABIAAAAIgBAAgAighbIgIgFIgBgBIABgBIAAAAIABAAIAIAFIABABIAAABIgBAAIAAABIgBgBgAgrhbIgKgCIgBAAIAAgBIAAgBIABAAIAKACIABAAIAAABIgBABIAAAAIAAAAgAg/hfIgKgCIgBgBIgBgBIABAAIABgBIAKACIABABIAAABIAAABIgBAAIAAAAgAhUhjIgKgCIAAAAIgBgBIABgBIABAAIAKACIABAAIAAABIAAABIgBAAIgBAAgAiwhlIgIgFIgBgBIABgBIAAAAIABAAIAIAFIABABIAAABIgBAAIAAABIgBgBgAhohnIgKgCIAAgBIgBgBIABAAIABgBIAKACIABABIAAABIgBABIAAAAIgBAAgAh8hrIgJgCIgBgBIAAAAIAAgBIABAAIAKABIABABIAAABIgBABIAAAAIgBAAgAjAhvIgJgFIgBgBIABgBIAAgBIACABIAJAFIAAABIAAABIgBABIAAAAIgBgBgAiPhvIgKgCIgBAAIAAgCIAAAAIABgBIAKADIABAAIAAABIAAABIgBAAIAAAAgAijhzIgLgCIAAgBIgBgBIABAAIABAAIAKABIABABIAAABIAAABIgBAAIAAAAgAi4h3IgKgCIAAAAIgBgBIABgBIABgBIAKADIABAAIAAABIgBABIAAAAIgBAAgAjMh7IgKgCIAAgBIAAgBIAAAAIABgBIAKACIABABIAAABIgBABIAAAAIgBAAg");
	this.shape_1.setTransform(18.7,15.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1BF8FE").s().p("AC4DSIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgACqDEIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgACcC2IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgACOCoIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgACACaIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAByCMIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgABkB+IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgABWBwIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgABIBiIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAA6BUIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAAsBGIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAAeA4IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAAQAqIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAACAcIgBAAIgGgHIAAgBIAAgBIABAAIABAAIAGAHIAAABIAAABIgBAAIAAAAgAgLAOIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAgZAAIgBAAIgHgGIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAAAIgBAAIAAAAgAgngNIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgADlgRIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgADTgYIgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgAg1gbIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgADBgfIgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgACvglIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgAhDgpIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgACdgsIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgACLgzIgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgAhRg3IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAB5g6IgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgABnhAIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgAhfhFIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgABVhHIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgABDhOIgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgAhthTIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAAxhVIgJgDIAAgBIgBgBIABAAIABgBIAJADIAAABIABABIgBABIgBAAIAAAAgAAfhbIgJgEIgBgBIAAgBIABgBIABAAIAJAEIABABIAAABIgBABIgBAAIAAAAgAh7hhIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAANhjIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAgEhrIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAiJhvIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAgWhzIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAgoh7IgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAiXh9IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAg6iDIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAhMiLIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAiliLIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAheiTIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAiziZIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAhwibIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAiCijIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAjBinIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAiUirIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAimizIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAjPi1IgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAi4i7IgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAjKjDIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAgAjdjDIgBAAIgHgHIAAgBIAAgBIABAAIABAAIAHAHIAAABIAAABIgBAAIAAAAgAjcjLIgJgEIgBAAIAAgBIABgBIABAAIAJAEIABABIAAABIgBAAIgBAAIAAAAg");
	this.shape_2.setTransform(20.7,23.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1BF8FE").s().p("AjrA3IAAgBIAAgBIABAAIAKgDIABABIABABIgBABIAAAAIgKACIgBAAIgBAAgAjWAzIgBgBIAAgBIABgBIAKgBIABAAIAAAAIAAABIAAABIgKACIgBAAIAAAAgAjCAvIgBgBIAAgBIABAAIAKgCIABAAIAAABIAAABIgBAAIgKACIAAAAIAAAAgAivArIAAgBIAAgBIABgBIAKgCIABABIAAAAIAAABIgBABIgKACIAAAAIgBAAgAibAnIAAgBIAAgBIABAAIAKgCIABAAIABABIgBABIAAAAIgLACIAAAAIgBAAgAiGAjIgBgBIAAgBIABgBIAKgCIABABIABAAIgBABIAAABIgKACIgBAAIAAAAgAhyAfIgBgBIAAgBIABAAIAKgCIABAAIAAABIAAABIgBAAIgJACIgBAAIAAAAgAhfAbIAAgBIAAgBIABAAIAKgDIABABIAAAAIAAACIgBAAIgKACIAAAAIgBAAgAhLAXIAAgBIAAgBIABgBIAKgBIABAAIABABIgBAAIgBABIgKACIAAAAIgBAAgAg3ATIAAgBIAAgBIABAAIAKgDIABABIABABIgBABIAAAAIgKACIgBAAIgBAAgAgiAPIgBgBIAAgBIABgBIAKgBIABAAIAAAAIAAABIAAABIgKACIgBAAIAAAAgAgOALIgBgBIAAgBIABAAIAKgCIABAAIAAABIAAABIgBAAIgKACIAAAAIAAAAgAAEAGIAAgBIAAgBIABAAIAKgCIABAAIAAABIAAABIgBAAIgKADIAAAAIgBgBgAAYABIAAAAIAAgBIABAAIAKgCIABAAIABABIgBABIAAAAIgLACIAAAAIgBgBgAAtgDIgBgBIAAAAIABgBIAKgDIABAAIABABIgBABIAAAAIgKADIgBABIAAgBgABBgIIgBAAIAAgBIABgBIAKgDIABAAIAAABIAAABIgBABIgJADIgBAAIAAgBgABVgNIgBgBIAAAAIABgBIAKgDIABAAIAAABIAAABIgBABIgKACIAAABIAAgBgABpgSIgBAAIAAgBIABgBIAKgDIABAAIABABIgBABIgBAAIgKAEIAAAAIAAgBgAB8gYIAAAAIAAgBIABgBIAKgCIABAAIABABIgBABIAAABIgKABIgBABIgBgBgACRgdIgBgBIAAgBIABAAIAKgCIABAAIAAABIAAABIAAAAIgKADIgBAAIAAgBgAClgiIgBAAIAAgBIABgBIAKgCIABAAIAAABIAAABIgBABIgKACIAAAAIAAgBgAC5gnIgBgBIAAAAIABgBIAKgDIABAAIAAABIAAABIgBAAIgKADIAAABIAAgBgADNgsIgBAAIAAgBIABgBIAKgDIABAAIABABIgBABIAAABIgLADIAAAAIAAgBgADhgxIgBAAIAAgBIABgBIAJgDIABAAIABABIAAABIgBABIgJACIAAABIgBgBg");
	this.shape_3.setTransform(22.1,-3.3);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(123));

	// Kinet
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,7.5,5.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#57565C").s().p("AhKAZIB3g5IAeAFIh8A8g");
	this.shape_4.setTransform(0,-1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2E2E30").s().p("Ag+ALIB8g8IABAnIh8A8g");
	this.shape_5.setTransform(1.3,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.instance}]}).wait(123));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-5.2,15.2,10.5);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-243.6,-243.6,487.2,487.2), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4AEIAAgHIBxAAIAAAHg");
	this.shape.setTransform(207.8,156,2.957,2.957);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AguBnIAAjNIBdAAIAADNgAgmAKIBNAAIAAhoIhNAAg");
	this.shape_1.setTransform(207.8,122.8,2.957,2.957);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(5));

	// headset
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(-236.3,55.9,3.101,3.101,0,0,0,6.8,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#293149").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape_2.setTransform(-236.4,57.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(5));

	// Layer_9
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#293149").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape_3.setTransform(207.6,124.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(5));

	// mobile
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EFF2F9").s().p("AhxEFQghAAAAghIAAnGQAAgiAhAAIDjAAQAOAAAJAKQAKALAAANIAAHGQAAAhghAAgAghDkQAAAXAWAAIAWAAQAXAAAAgXQAAgXgXAAIgWAAQgWAAAAAXgAh9izIAAFpQAAALAMAAIDjAAQAMAAAAgLIAAlpQAAgMgMAAIjjAAQgMAAAAAMgAghjiQAAAMAMAAIArAAQAMAAAAgMQAAgLgMAAIgrAAQgMAAAAALgAhPjiQAAAMAMAAQALAAAAgMQAAgLgLAAQgMAAAAALg");
	this.shape_4.setTransform(4.7,-241.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(5));

	// Layer_8
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#293149").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape_5.setTransform(5.4,-240.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5));

	// Layer_1
	this.instance_1 = new lib.Symbol6();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({rotation:-360},4).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-278.4,-282.5,528,525.7);


(lib.glow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol4();
	this.instance.parent = this;
	this.instance.setTransform(0.6,-2.1,0.781,0.901,0,0,0,0.2,0.3);
	this.instance.alpha = 0.102;
	this.instance.compositeOperation = "lighter";

	this.instance_1 = new lib.Symbol4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,6.7,0.813,0.882);
	this.instance_1.alpha = 0.301;
	this.instance_1.compositeOperation = "lighter";

	this.instance_2 = new lib.Symbol4();
	this.instance_2.parent = this;
	this.instance_2.alpha = 0.602;
	this.instance_2.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.glow, new cjs.Rectangle(-125.7,-256.5,251.4,513.2), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1();
	this.instance.parent = this;
	this.instance.setTransform(13.8,13.8,1,1,0,0,0,13.8,13.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,27.7,27.7), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_1();
	this.instance.parent = this;
	this.instance.setTransform(8.8,5,1,1,0,0,0,8.8,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(0,0,17.5,10.1), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_2();
	this.instance.parent = this;
	this.instance.setTransform(6.4,3.7,1,1,0,0,0,6.4,3.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,12.9,7.5), null);


(lib.Group_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1.6,0.9,1,1,0,0,0,1.6,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(0,0,3.1,1.9), null);


(lib.ClipGroup_4_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	mask_6.graphics.p("AgPBeIAAi8IAeAAIAAC8g");
	mask_6.setTransform(1.6,9.5);

	// Layer_3
	this.instance = new lib.ClipGroup_5();
	this.instance.parent = this;
	this.instance.setTransform(1.6,9.5,1,1,0,0,0,1.6,9.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_6, new cjs.Rectangle(0,0,3.1,18.9), null);


(lib.Group_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_0();
	this.instance.parent = this;
	this.instance.setTransform(0.8,0.8,1,1,0,0,0,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.Group_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_2();
	this.instance.parent = this;
	this.instance.setTransform(0.6,0.5,1,1,0,0,0,0.6,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(0,0,1.1,1.1), null);


(lib.Group_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3_1();
	this.instance.parent = this;
	this.instance.setTransform(0.8,0.8,1,1,0,0,0,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15, new cjs.Rectangle(0,0,1.5,1.5), null);


(lib.Group_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_4();
	this.instance.parent = this;
	this.instance.setTransform(0.7,0.7,1,1,0,0,0,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14, new cjs.Rectangle(0,0,1.5,1.4), null);


(lib.Group_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_5_1();
	this.instance.parent = this;
	this.instance.setTransform(0.4,0.4,1,1,0,0,0,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13, new cjs.Rectangle(0,0,0.8,0.8), null);


(lib.Group_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_6();
	this.instance.parent = this;
	this.instance.setTransform(0.5,0.5,1,1,0,0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(0,0,1,1), null);


(lib.Group_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_7();
	this.instance.parent = this;
	this.instance.setTransform(0.7,0.7,1,1,0,0,0,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(0,0,1.4,1.4), null);


(lib.Group_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(0.4,0.4,1,1,0,0,0,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.Group_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(0.2,0.2,1,1,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(0,0,0.5,0.4), null);


(lib.Group_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(0.7,0.7,1,1,0,0,0,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(0,-0.1,1.5,1.5), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(0.5,0.5,1,1,0,0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(0.6,0.6,1,1,0,0,0,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,1.3,1.3), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(0.6,0.6,1,1,0,0,0,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,1.2,1.2), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(0.4,0.3,1,1,0,0,0,0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,0.7,0.7), null);


(lib.Group_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_15();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.4,0.4,1,1,0,0,0,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_1, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.Group_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_16();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.6,0.5,1,1,0,0,0,0.6,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(0,-0.1,1.2,1.3), null);


(lib.Group_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.ClipGroup_17();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.4,0.3,1,1,0,0,0,0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_2, new cjs.Rectangle(0,0,0.8,0.8), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_20();
	this.instance.parent = this;
	this.instance.setTransform(3.1,3.4,1,1,0,0,0,3.1,3.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(-2,-2.7,10.2,12.3), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(0.1,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,0.4,0.4), null);


(lib.ClipGroup_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ao3KAIAAz/IRuAAIAAT/g");
	mask.setTransform(56.8,64);

	// Layer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(64.9,123.9,1,1,0,0,0,3.1,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19_1, new cjs.Rectangle(59.8,117.8,10.2,10.3), null);


(lib.ClipGroup_2_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	mask_7.graphics.p("Ao3KAIAAz/IRuAAIAAT/g");
	mask_7.setTransform(56.8,64);

	// Layer_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(102.8,62.5,1,1,0,0,0,0.1,0.1);

	this.instance_1 = new lib.Group_1_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(99.1,68.6,1,1,0,0,0,0.4,0.3);

	this.instance_2 = new lib.Group_2_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(106.7,67.5,1,1,0,0,0,0.6,0.5);

	this.instance_3 = new lib.Group_3_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(37.6,16,1,1,0,0,0,0.4,0.4);

	this.instance_4 = new lib.Group_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(24.2,89.3,1,1,0,0,0,0.4,0.3);

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(54.1,90.3,1,1,0,0,0,0.6,0.6);

	this.instance_6 = new lib.Group_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(33.4,90.2,1,1,0,0,0,0.6,0.6);

	this.instance_7 = new lib.Group_7();
	this.instance_7.parent = this;
	this.instance_7.setTransform(81.4,17.3,1,1,0,0,0,0.5,0.5);

	this.instance_8 = new lib.Group_8();
	this.instance_8.parent = this;
	this.instance_8.setTransform(9.2,57.5,1,1,0,0,0,0.7,0.7);
	this.instance_8.alpha = 0.801;

	this.instance_9 = new lib.Group_9();
	this.instance_9.parent = this;
	this.instance_9.setTransform(92.2,102.1,1,1,0,0,0,0.2,0.2);

	this.instance_10 = new lib.Group_10();
	this.instance_10.parent = this;
	this.instance_10.setTransform(83.7,104,1,1,0,0,0,0.4,0.4);

	this.instance_11 = new lib.Group_11();
	this.instance_11.parent = this;
	this.instance_11.setTransform(91.3,109.6,1,1,0,0,0,0.7,0.7);

	this.instance_12 = new lib.Group_12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(76,4.7,1,1,0,0,0,0.5,0.5);

	this.instance_13 = new lib.Group_13();
	this.instance_13.parent = this;
	this.instance_13.setTransform(0.4,56.8,1,1,0,0,0,0.4,0.4);

	this.instance_14 = new lib.Group_14();
	this.instance_14.parent = this;
	this.instance_14.setTransform(25.6,83.7,1,1,0,0,0,0.7,0.7);

	this.instance_15 = new lib.Group_15();
	this.instance_15.parent = this;
	this.instance_15.setTransform(7.8,65.7,1,1,0,0,0,0.8,0.8);

	this.instance_16 = new lib.Group_16();
	this.instance_16.parent = this;
	this.instance_16.setTransform(113,43.8,1,1,0,0,0,0.6,0.5);

	this.instance_17 = new lib.Group_17();
	this.instance_17.parent = this;
	this.instance_17.setTransform(15.2,15.9,1,1,0,0,0,0.8,0.8);
	this.instance_17.alpha = 0.801;

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9,this.instance_10,this.instance_11,this.instance_12,this.instance_13,this.instance_14,this.instance_15,this.instance_16,this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_7, new cjs.Rectangle(0,4.2,113.5,106.1), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("Ao3KAIAAz/IRuAAIAAT/g");
	mask_5.setTransform(56.8,64);

	// Layer_3
	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#DA0588").s().p("AgJAtQgFgCgDgDQgDgDgBgFQgCgFAAgHIAAgnQAAgIACgEQABgFADgDQADgDAFgCQAEgBAFAAQAFAAAFABQAFACADADQADADACAFQABAEAAAIIAAAnQAAAHgBAFQgCAFgDADQgDADgFACQgFABgFAAQgFAAgEgBgAgCgfIgCACIgCAEIgBAGIAAAnIABAGIACAEIACACIACABIADgBIADgCIABgEIAAgGIAAgnIAAgGIgBgEIgDgCIgDgBg");
	this.shape_150.setTransform(97,114.7);

	this.instance = new lib.ClipGroup_19_1();
	this.instance.parent = this;
	this.instance.setTransform(56.8,65,1,1,0,0,0,56.8,65);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#2181DE").s().p("AgEAZIgFgCIgCgFIgBgHIAAgVIABgHIACgEIAFgDIAEgBIAGABIAEADIADAEIABAHIAAAVIgBAHIgDAFIgEACIgGABIgEgBgAgBgRIgBABIgBACIAAAEIAAAVIAAAEIABACIABABIABAAIACAAIABgBIABgCIABgEIAAgVIgBgEIgBgCIgBgBIgCAAg");
	this.shape_151.setTransform(41.7,65.8);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#2181DE").s().p("AgJAtQgFgCgDgDQgDgDgBgFQgCgFAAgHIAAgnQAAgIACgEQABgFADgDQADgDAFgCQAEgBAFAAQAFAAAGABQAEACADADQADADACAFQABAEAAAIIAAAnQAAAHgBAFQgCAFgDADQgDADgEACQgGABgFAAQgFAAgEgBgAgCgfIgCACIgCAEIAAAGIAAAnIAAAGIACAEIACACIACABIADgBIACgCIACgEIAAgGIAAgnIAAgGIgCgEIgCgCIgDgBg");
	this.shape_152.setTransform(20.6,94.5);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#2181DE").s().p("AgJAtQgFgCgDgDQgDgDgBgFQgCgFAAgHIAAgnQAAgIACgEQABgFADgDQADgDAFgCQAEgBAFAAQAFAAAFABQAFACADADQADADACAFQABAEAAAIIAAAnQAAAHgBAFQgCAFgDADQgDADgFACQgFABgFAAQgFAAgEgBgAgCgfIgCACIgCAEIgBAGIAAAnIABAGIACAEIACACIACABIADgBIADgCIABgEIAAgGIAAgnIAAgGIgBgEIgDgCIgDgBg");
	this.shape_153.setTransform(55.6,35.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgEAVIgEgCIgCgEIgBgFIAAgTIABgGIACgEIAEgCIAEAAIAFAAIADACIADAEIABAGIAAATIgBAFIgDAEIgDACIgFABIgEgBgAgBgPIgBABIgBACIAAADIAAATIAAADIABACIABAAIABABIABgBIABAAIABgCIAAgDIAAgTIAAgDIgBgCIgBgBIgBAAg");
	this.shape_154.setTransform(94.1,58.7);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#DA0588").s().p("AgHAjQgDgBgDgDQgCgCgBgEQgCgEAAgFIAAgfQAAgFACgEQABgEACgCQADgDADgBIAHgBIAIABQADABADADQACACACAEIABAJIAAAfIgBAJQgCAEgCACQgDADgDABIgIABIgHgBgAgBgYIgCABIgCADIAAAFIAAAfIAAAEIACADQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIABAAIACAAIACgCIACgDIAAgEIAAgfIAAgFIgCgDIgCgBIgCgBg");
	this.shape_155.setTransform(86.5,33.8);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#DA0588").s().p("AgJAtQgFgCgDgDQgDgDgBgFQgCgFgBgHIAAgnQABgIACgEQABgFADgDQADgDAFgCQAEgBAFAAQAFAAAFABQAFACADADQADADACAFQACAEAAAIIAAAnQAAAHgCAFQgCAFgDADQgDADgFACQgFABgFAAQgFAAgEgBgAgCgfIgCACIgCAEIgBAGIAAAnIABAGIACAEIACACIACABIADgBIADgCIABgEIABgGIAAgnIgBgGIgBgEIgDgCIgDgBg");
	this.shape_156.setTransform(67.7,72.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#63E2F6").s().p("AABAZIAAgiIgKAAIAAgHIAEAAIAEgBIACgDIACgEIAHAAIAAAxg");
	this.shape_157.setTransform(50.5,84.7);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AABAZIAAgiIgKAAIAAgHIAEAAIAEgBIACgDIACgEIAHAAIAAAxg");
	this.shape_158.setTransform(67.6,50.9);

	this.instance_1 = new lib.ClipGroup_1_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.8,62.4,1,1,0,0,0,56.8,62.4);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AABAhIAAgtIgOAAIAAgJIAGAAIAGgCIACgDQACgCABgEIAJAAIAABBg");
	this.shape_159.setTransform(15.3,72.3);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#2181DE").s().p("AABAgIAAgsIgNAAIAAgIIAGgBIAFgBQABgCACgCIACgFIAJAAIAAA/g");
	this.shape_160.setTransform(107.8,86.4);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AACAtIAAg+IgTAAIAAgMIAIAAIAGgCIAGgGIADgHIANAAIAABZg");
	this.shape_161.setTransform(74.9,94.4);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#63E2F6").s().p("AABAtIAAg9IgSAAIAAgNIAIAAIAHgDIAEgFIAEgHIAMAAIAABZg");
	this.shape_162.setTransform(39.6,111.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#63E2F6").s().p("AABAtIAAg+IgTAAIAAgMIAJAAIAHgCIAEgGIAEgHIAMAAIAABZg");
	this.shape_163.setTransform(23.9,47.2);

	this.instance_2 = new lib.ClipGroup_2_7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(56.8,64,1,1,0,0,0,56.8,64);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#63E2F6").s().p("AgFAXIAAgsIALAAIAAAsg");
	this.shape_164.setTransform(48.5,7.4);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#63E2F6").s().p("AgVAGIAAgLIAsAAIAAALg");
	this.shape_165.setTransform(48.5,7.4);

	var maskedShapeInstanceList = [this.shape_150,this.instance,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.instance_1,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.instance_2,this.shape_164,this.shape_165];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_165},{t:this.shape_164},{t:this.instance_2},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.instance_1},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.instance},{t:this.shape_150}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(0,0,113.5,128), null);


(lib.Group_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_1_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(22.1,46.6,1,1,0,0,0,22.1,46.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_18, new cjs.Rectangle(0,0,44.1,93.2), null);


(lib.ClipGroup_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AjcHRIAAuhIG4AAIAAOhg");
	mask_1.setTransform(22.1,46.5);

	// Layer_3
	this.instance = new lib.Group_18();
	this.instance.parent = this;
	this.instance.setTransform(22.1,46.6,1,1,0,0,0,22.1,46.6);
	this.instance.alpha = 0.73;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_1, new cjs.Rectangle(0,0,44.1,93.1), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	mask_6.graphics.p("AjcHRIAAuhIG4AAIAAOhg");
	mask_6.setTransform(22.1,46.5);

	// Layer_3
	this.instance_3 = new lib.ClipGroup_0_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(22.1,46.6,1,1,0,0,0,22.1,46.6);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0,0,44.1,93.1), null);


(lib.Group_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.ClipGroup_1_4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(22.1,46.1,1,1,0,0,0,22.1,46.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_19, new cjs.Rectangle(0,-0.1,44.1,92.5), null);


(lib.ClipGroup_0_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AjcHOIAAubIG4AAIAAObg");
	mask_2.setTransform(22.1,46.2);

	// Layer_3
	this.instance_1 = new lib.Group_19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(22.1,46.1,1,1,0,0,0,22.1,46.1);
	this.instance_1.alpha = 0.73;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_2, new cjs.Rectangle(0,0,44.1,92.4), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	mask_7.graphics.p("AjcHOIAAubIG4AAIAAObg");
	mask_7.setTransform(22.1,46.2);

	// Layer_3
	this.instance_4 = new lib.ClipGroup_0_2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(22.1,46.1,1,1,0,0,0,22.1,46.1);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0,0,44.1,92.4), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	mask_8.graphics.p("Ao3ITIAAwlIRuAAIAAQlg");
	mask_8.setTransform(56.8,53.1);

	// Layer_3
	this.instance_5 = new lib.ClipGroup_24();
	this.instance_5.parent = this;
	this.instance_5.setTransform(56.9,61,1,1,0,0,0,57.1,63.4);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(0,0,113.5,106.1), null);


(lib.Group_1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_3 = new lib.ClipGroup_3_4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(100.5,117.4,1,1,0,0,0,100.5,117.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_3, new cjs.Rectangle(0,0,200.9,234.8), null);


(lib.Group_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_3 = new lib.ClipGroup_4_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(57.6,52.8,1,1,0,0,0,57.6,52.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_20, new cjs.Rectangle(0,0,115.1,105.6), null);


(lib.ClipGroup_1_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_14 = new cjs.Shape();
	mask_14._off = true;
	mask_14.graphics.p("AvsUNMAAAgoZIfZAAMAAAAoZg");
	mask_14.setTransform(100.5,129.3);

	// Layer_3
	this.instance = new lib.ClipGroup_2_3();
	this.instance.parent = this;
	this.instance.setTransform(100.5,129.3,1,1,0,0,0,100.5,129.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_14;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_14, new cjs.Rectangle(0,0,201,258.6), null);


(lib.ClipGroup_0_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("Ar+K1IAA1pIX9AAIAAVpg");
	mask_3.setTransform(76.7,69.3);

	// Layer_3
	this.instance_2 = new lib.ClipGroup_1_7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(76.7,69.2,1,1,0,0,0,76.7,69.2);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_3, new cjs.Rectangle(0,0,153.4,138.5), null);


(lib.Group_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.ClipGroup_1_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6.2,7.3,1,1,0,0,0,6.2,7.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_2, new cjs.Rectangle(0,0,12.4,14.6), null);


(lib.Group_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.ClipGroup_2_4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.4,8,1,1,0,0,0,7.4,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_2, new cjs.Rectangle(0,0,14.8,16.1), null);


(lib.Group_1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_4 = new lib.ClipGroup_3_5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(6.5,7.5,1,1,0,0,0,6.5,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_4, new cjs.Rectangle(0,0,13,15.1), null);


(lib.Group_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_4 = new lib.ClipGroup_4_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(5,10.2,1,1,0,0,0,5,10.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_21, new cjs.Rectangle(0,0,10,20.3), null);


(lib.Group_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_1_9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(7.2,4.2,1,1,0,0,0,7.2,4.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_1, new cjs.Rectangle(0,0,14.5,8.4), null);


(lib.ClipGroup_2_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	mask_8.graphics.p("AgMAkIAAhIIAZAAIAABIg");
	mask_8.setTransform(1.3,3.7);

	// Layer_3
	this.instance_18 = new lib.ClipGroup_3_6();
	this.instance_18.parent = this;
	this.instance_18.setTransform(1.2,3.6,1,1,0,0,0,1.2,3.6);

	var maskedShapeInstanceList = [this.instance_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_8, new cjs.Rectangle(0,0,2.5,7.3), null);


(lib.Group_1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_5 = new lib.ClipGroup_1_10();
	this.instance_5.parent = this;
	this.instance_5.setTransform(11.3,6.5,1,1,0,0,0,11.3,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_5, new cjs.Rectangle(0,0,22.7,13.1), null);


(lib.ClipGroup_2_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	mask_9.graphics.p("AgTA5IAAhxIAmAAIAABxg");
	mask_9.setTransform(2,5.7);

	// Layer_3
	this.instance_19 = new lib.ClipGroup_3_7();
	this.instance_19.parent = this;
	this.instance_19.setTransform(1.9,5.7,1,1,0,0,0,1.9,5.7);

	var maskedShapeInstanceList = [this.instance_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_9;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_9, new cjs.Rectangle(0,0,3.9,11.4), null);


(lib.Group_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_5 = new lib.ClipGroup_1_11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(28.7,10.5,1,1,0,0,0,28.7,10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_22, new cjs.Rectangle(-0.1,0,57.6,21), null);


(lib.ClipGroup_0_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AkeBoIAAjQII9AAIAADQg");
	mask_4.setTransform(28.7,10.5);

	// Layer_3
	this.instance_3 = new lib.Group_22();
	this.instance_3.parent = this;
	this.instance_3.setTransform(28.7,10.5,1,1,0,0,0,28.7,10.5);
	this.instance_3.alpha = 0.051;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_4, new cjs.Rectangle(0,0,57.4,20.9), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	mask_9.graphics.p("AkeBoIAAjQII9AAIAADQg");
	mask_9.setTransform(28.7,10.5);

	// Layer_3
	this.instance_6 = new lib.ClipGroup_0_4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(28.7,10.5,1,1,0,0,0,28.7,10.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_9;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(0,0,57.4,20.9), null);


(lib.ClipGroup_9_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AlfDLIAAmVIK/AAIAAGVg");
	mask_2.setTransform(52.7,50.9);

	// Layer_3
	this.instance = new lib.ClipGroup_10_2();
	this.instance.parent = this;
	this.instance.setTransform(52.8,50.8,1,1,0,0,0,52.8,50.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_2, new cjs.Rectangle(17.6,30.5,70.4,40.7), null);


(lib.ClipGroup_7_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AhkB+IAAj7IDJAAIAAD7g");
	mask_2.setTransform(10.1,12.6);

	// Layer_3
	this.instance = new lib.ClipGroup_8_2();
	this.instance.parent = this;
	this.instance.setTransform(10.1,12.6,1,1,0,0,0,10.1,12.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_2, new cjs.Rectangle(0,0,20.2,25.1), null);


(lib.ClipGroup_4_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	mask_7.graphics.p("AmWFNIAAqZIMtAAIAAKZg");
	mask_7.setTransform(56.5,53.2);

	// Layer_3
	this.instance_1 = new lib.ClipGroup_14_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(85.8,69.1,1,1,0,0,0,11.3,17.4);

	this.instance_2 = new lib.ClipGroup_13_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(52.3,52.8,1,1,0,0,0,9.5,7.7);

	this.instance_3 = new lib.ClipGroup_12_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(43.8,58.4,1,1,0,0,0,26.2,17.2);

	this.instance_4 = new lib.ClipGroup_11_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(78.6,68.1,1,1,0,0,0,9.2,7.4);

	this.instance_5 = new lib.ClipGroup_9_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(52.8,50.8,1,1,0,0,0,52.8,50.8);

	this.instance_6 = new lib.ClipGroup_7_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(26.3,33,1,1,0,0,0,10.1,12.6);

	this.instance_7 = new lib.ClipGroup_6_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(62,42.8,1,1,0,0,0,27.8,22.9);

	this.instance_8 = new lib.ClipGroup_5_5();
	this.instance_8.parent = this;
	this.instance_8.setTransform(25,32.1,1,1,0,0,0,9.2,12.1);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_7, new cjs.Rectangle(15.8,19.9,81.5,66.7), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A1IG3MAmggWOIB4DPMgmgAWOg");
	var mask_graphics_1 = new cjs.Graphics().p("A1nGmMAmggWOIEvIMMgmgAWPg");
	var mask_graphics_2 = new cjs.Graphics().p("A3DEiMAmggWOIHnNLMgmgAWOg");
	var mask_graphics_3 = new cjs.Graphics().p("A4fCDMAmhgWOIKeSJMgmhAWOg");
	var mask_graphics_4 = new cjs.Graphics().p("A56gbMAmggWPINVXGMgmgAWPg");
	var mask_graphics_5 = new cjs.Graphics().p("A7Wi6MAmggWPIQNcEMgmgAWPg");
	var mask_graphics_6 = new cjs.Graphics().p("A8ylYMAmggWQMATFAhCMgmgAWPg");
	var mask_graphics_7 = new cjs.Graphics().p("A+On3MAmhgWQMAV8Al/MgmhAWQg");
	var mask_graphics_8 = new cjs.Graphics().p("A/pqWMAmggWQMAYzAq9MgmgAWQg");
	var mask_graphics_9 = new cjs.Graphics().p("EghFgM1MAmggWPMAbrAv6MgmgAWPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-135.3,y:-98.4}).wait(1).to({graphics:mask_graphics_1,x:-129.4,y:-100.1}).wait(1).to({graphics:mask_graphics_2,x:-117.5,y:-90.5}).wait(1).to({graphics:mask_graphics_3,x:-105.7,y:-78.2}).wait(1).to({graphics:mask_graphics_4,x:-93.8,y:-65.9}).wait(1).to({graphics:mask_graphics_5,x:-81.9,y:-53.5}).wait(1).to({graphics:mask_graphics_6,x:-70,y:-41.2}).wait(1).to({graphics:mask_graphics_7,x:-58.1,y:-28.8}).wait(1).to({graphics:mask_graphics_8,x:-46.2,y:-16.5}).wait(1).to({graphics:mask_graphics_9,x:-28.7,y:5.5}).wait(109));

	// Layer_3
	this.instance = new lib.Group_1();
	this.instance.parent = this;
	this.instance.setTransform(90.3,81.3,2.969,2.969,0,0,0,13.8,13.8);
	this.instance.alpha = 0.199;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(118));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.149)").s().p("ACNGJIosr0IAJgdIM1H9IAAEUg");
	this.shape.setTransform(7.4,5.7,2.969,2.969);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(118));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1F").s().p("AgJAYIAAg4IATAHIAAA6g");
	this.shape_1.setTransform(-127.8,-105.6,2.969,2.969);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#57565C").s().p("AgkAIIAxgWIAYAGIg1AXg");
	this.shape_2.setTransform(-119.8,-117.7,2.969,2.969);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E0E0E2").s().p("AgHAOQgDgCAAgGQAAgFADgFQADgFAEgDQAFgDADACQADACAAAFQAAAGgDAFQgDAFgFADIgEABIgDAAg");
	this.shape_3.setTransform(-114.9,-106.7,2.969,2.969);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E3D43").s().p("AgKATQgEgDAAgHQAAgHAEgHQAEgIAGgDQAGgEAFACQAEADAAAIQAAAHgEAGQgFAIgGADQgDADgDAAIgEgBg");
	this.shape_4.setTransform(-114.9,-106.8,2.969,2.969);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#57565C").s().p("AgMARQgEgDAAgHQAAgHAEgHQAFgHAHgEQAFgEAEADIAIAEQgEgCgHADQgGAEgEAIQgEAHAAAHQAAAHAEADg");
	this.shape_5.setTransform(-116.8,-107.5,2.969,2.969);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2E2E30").s().p("AgagQIA1gYIAAA5Ig1AYg");
	this.shape_6.setTransform(-116.8,-108,2.969,2.969);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(118));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.7,-122.3,118.7,88.6);


(lib.Group_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_6 = new lib.ClipGroup_4_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1.6,9.5,1,1,0,0,0,1.6,9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_23, new cjs.Rectangle(0,0,3.1,19), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_10 = new cjs.Shape();
	mask_10._off = true;
	mask_10.graphics.p("AhXCEIAAkHICuAAIAAEHg");
	mask_10.setTransform(8.8,13.2);

	// Layer_3
	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#29BA39").s().p("Ag9AkQgagPAAgVIAAAAQAAgUAagPQAagPAjAAQAkAAAaAPQAZAPAAAUIAAAAQAAAVgZAPQgaAPgkAAQgjgBgagOg");
	this.shape_166.setTransform(8.8,5.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#005E17").s().p("Ag9ASQgagYAAglICuAAQAAAlgZAYQgaAagkAAQgjAAgagag");
	this.shape_167.setTransform(8.8,9.5);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#005E17").s().p("Ag9AkQgagPAAgVIAAAAQAAgUAagPQAagPAjAAQAkAAAaAPQAZAPAAAUIAAAAQAAAVgZAPQgaAPgkAAQgjgBgagOg");
	this.shape_168.setTransform(8.8,5.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#00A13C").s().p("AgsAaQgTgLAAgPIAAAAQAAgPATgKQASgLAaAAQAbAAASALQATALAAAOIAAAAQAAAQgSAKQgTALgbAAQgaAAgSgLg");
	this.shape_169.setTransform(8.8,11.3);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#005E17").s().p("AgsANQgTgSAAgaIB/AAQAAAagSASQgTATgbAAQgZAAgTgTg");
	this.shape_170.setTransform(8.7,14.5);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#00A13C").s().p("AgsANQgTgSAAgaIB/AAQAAAagSASQgTATgbAAQgZAAgTgTg");
	this.shape_171.setTransform(8.7,14.5);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#00A13C").s().p("AgsAaQgTgLAAgPIAAAAQAAgPATgKQASgLAaAAQAbAAASALQATALAAAOIAAAAQAAAQgSAKQgTALgbAAQgaAAgSgLg");
	this.shape_172.setTransform(8.8,11.3);

	this.instance_7 = new lib.Group_23();
	this.instance_7.parent = this;
	this.instance_7.setTransform(8.8,12.9,1,1,0,0,0,1.6,9.5);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#7C5241").s().p("AgKBcQgEgDgBgEIAAizQABAEAEADQAKAGALgGQAEgDAAgDIAACyQABAEgFADQgFADgGAAQgEAAgGgDg");
	this.shape_173.setTransform(8.8,12.9);

	this.instance_8 = new lib.Group_1_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(8.8,21.4,1,1,0,0,0,1.6,0.9);

	this.instance_9 = new lib.Group_2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(8.7,21.4,1,1,0,0,0,6.4,3.7);
	this.instance_9.alpha = 0.102;

	this.instance_10 = new lib.Group_3();
	this.instance_10.parent = this;
	this.instance_10.setTransform(8.8,21.4,1,1,0,0,0,8.8,5);
	this.instance_10.alpha = 0.102;

	var maskedShapeInstanceList = [this.shape_166,this.shape_167,this.shape_168,this.shape_169,this.shape_170,this.shape_171,this.shape_172,this.instance_7,this.shape_173,this.instance_8,this.instance_9,this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_10;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.shape_173},{t:this.instance_7},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(0,0,17.5,26.5), null);


(lib.Group_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_3 = new lib.ClipGroup_1_14();
	this.instance_3.parent = this;
	this.instance_3.setTransform(100.5,129.3,1,1,0,0,0,100.5,129.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_3, new cjs.Rectangle(0,0,201,258.6), null);


(lib.Group_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ClipGroup_2_8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1.2,3.6,1,1,0,0,0,1.2,3.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_1, new cjs.Rectangle(0,0,2.5,7.3), null);


(lib.Group_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_7 = new lib.ClipGroup_2_9();
	this.instance_7.parent = this;
	this.instance_7.setTransform(1.9,5.7,1,1,0,0,0,1.9,5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_24, new cjs.Rectangle(0,0,3.9,11.4), null);


(lib.Group_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_8 = new lib.ClipGroup_4_7();
	this.instance_8.parent = this;
	this.instance_8.setTransform(52.8,50.8,1,1,0,0,0,52.8,50.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_25, new cjs.Rectangle(0,0,105.6,101.6), null);


(lib.ClipGroup_0_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	mask_5.graphics.p("AmWFNIAAqZIMtAAIAAKZg");
	mask_5.setTransform(56.5,53.2);

	// Layer_3
	this.instance_4 = new lib.Group_25();
	this.instance_4.parent = this;
	this.instance_4.setTransform(52.8,50.8,1,1,0,0,0,52.8,50.8);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_5, new cjs.Rectangle(15.8,19.9,81.5,66.7), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_11 = new cjs.Shape();
	mask_11._off = true;
	mask_11.graphics.p("AmmF9IAAr5INNAAIAAL5g");
	mask_11.setTransform(55,53.7);

	// Layer_3
	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#9BDCE1").s().p("ACdDfIC3hqIock7Ii3BrIgngWIDjiEIJqFoIjjCDg");
	this.shape_174.setTransform(54.9,40.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#87C7D0").s().p("Ak0hHIAAjZIAmAWIAPCRIH9EoIARh+IAmAWIAADZg");
	this.shape_175.setTransform(43.6,57.7);

	this.instance_11 = new lib.ClipGroup_0_5();
	this.instance_11.parent = this;
	this.instance_11.setTransform(52.8,50.8,1,1,0,0,0,52.8,50.8);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#8A8A8A").s().p("AkpgRIhxhSIDWiSIJeFrIjYCAg");
	this.shape_176.setTransform(55.1,53.8);

	var maskedShapeInstanceList = [this.shape_174,this.shape_175,this.instance_11,this.shape_176];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_11;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_176},{t:this.instance_11},{t:this.shape_175},{t:this.shape_174}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(12.7,15.7,84.6,76.1), null);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#398226").s().p("Ag5BTIBzjoIAAErg");
	this.shape.setTransform(-22.3,-15.1,3.821,3.821);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#29BA39").s().p("Ag5iVIB0DoIh0BDg");
	this.shape_1.setTransform(22.2,-15.1,3.821,3.821);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#29BA39").s().p("Ag5BTIBzjoIAAErg");
	this.shape_2.setTransform(-22.3,-15.1,3.821,3.821);

	this.instance = new lib.Group_24();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,30.4,3.821,3.821,0,0,0,1.9,5.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#AE685B").s().p("AgDA5IgBgBIgDAAIAAAAIgBAAIgBgBIgBAAIgDgCQgGgCABgFIAAhmQAAAFAFADIADACIABAAIACABIABAAIADAAIAHAAIAGgBIAFgCIACgCIABgBIAAAAIABgBIAAgBIAAAAIAAgCIAAAAIAABmIAAABIAAAAIgBABIAAAAIAAABIgBAAIAAABIgCACIgBAAIgBAAIgDACIAAAAIgBAAIgBABIgCAAIAAAAIgCABg");
	this.shape_3.setTransform(0,30.4,3.821,3.821);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#575757").s().p("AgMAIQgGgEAAgEQAAgEAFgDQAGgEAHAAQAIAAAGAEQAFADAAAEQAAAEgFAEQgGADgIABQgHgBgFgDg");
	this.shape_4.setTransform(-0.1,8.6,3.821,3.821);

	this.instance_1 = new lib.Group_1_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.2,47.6,3.821,3.821,0,0,0,11.3,6.5);
	this.instance_1.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_4},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.5,-72.5,89.1,145.1);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00893E").s().p("AgjAVIAAhTIBHApIAABUg");
	this.shape.setTransform(-14.8,-10.9,4.083,4.083);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00893E").s().p("AgjAVIAAhTIBHApIAABUg");
	this.shape_1.setTransform(-14.8,-10.9,4.083,4.083);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#005E17").s().p("AgjgVIBHgpIAABTIhHAqg");
	this.shape_2.setTransform(14.8,-10.9,4.083,4.083);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00893E").s().p("AgjgVIBHgpIAABTIhHAqg");
	this.shape_3.setTransform(14.8,-10.9,4.083,4.083);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#29BA39").s().p("AhIAAIBIgpIBIApIhIAqg");
	this.shape_4.setTransform(0,-36.7,4.083,4.083);

	this.instance = new lib.Group_4_1();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,24.6,4.083,4.083,0,0,0,1.2,3.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#B9837B").s().p("AgCAlIgBgBIgCAAIgBAAIgCgBQgEgDABgDIAAhAQAAADADACIACAAIAAABIACAAIADAAIAAABIADAAIAAgBIACAAIACAAIABAAIAAgBIACAAIAAgBIAAAAIABAAIABgCIAAAAIABAAIAAgBIAAAAIAABBIgBAAIAAABIAAAAIAAAAIgBABIAAAAIAAAAIgBABIAAAAIAAABIgBAAIgBAAIAAABIgBAAIgBAAIgCAAIgBABg");
	this.shape_5.setTransform(0,24.8,4.083,4.083);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#575757").s().p("AgIAFQgEgCABgDQgBgCAEgCQAEgCAEAAQAFAAADACQAEACAAACQAAADgDACQgEACgFAAQgEAAgEgCg");
	this.shape_6.setTransform(0,10.1,4.083,4.083);

	this.instance_1 = new lib.Group_5_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.2,36.9,4.083,4.083,0,0,0,7.2,4.2);
	this.instance_1.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.instance},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.6,-53.8,59.2,107.6);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_30();
	this.instance.parent = this;
	this.instance.setTransform(-8.7,-11.4,4.062,4.062,0,0,0,52.8,50.9);

	this.instance_1 = new lib.ClipGroup_1_13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(157.4,86.9,4.062,4.062,0,0,0,1.8,4.9);

	this.instance_2 = new lib.ClipGroup_2_6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-155.6,2.8,4.062,4.062,0,0,0,1.8,4.9);

	this.instance_3 = new lib.ClipGroup_3_9();
	this.instance_3.parent = this;
	this.instance_3.setTransform(73.1,135.4,4.062,4.062,0,0,0,1.8,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-223.2,-218.2,428.8,412.7);


// stage content:
(lib.V4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_258 = new cjs.Graphics().p("EgKUA7oQlXgVmVgoQwJhmhhhNQhYhHoxwpQlzrCjWmuMAIVgk1MBOcgrZIK+DgINKFSIHAfkMgCoA86QmdCpnPCoQueFQj2AAQjoAArjDyIoECtQj3BSg8AIQgXADg0AAQhtAAjvgPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(258).to({graphics:mask_graphics_258,x:455.9,y:498.1}).wait(63));

	// data
	this.instance = new lib.ClipGroup_27();
	this.instance.parent = this;
	this.instance.setTransform(454.8,504.2,4.216,4.216,0,0,0,56.9,53.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(258).to({_off:false},0).to({y:324.2},20).to({y:44.2,alpha:0},18).wait(25));

	// cloud
	this.instance_1 = new lib.Tween40("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(488.9,324,1.312,1.312);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:448.9,y:344,alpha:1},6).to({startPosition:0},32).to({x:356.7,y:390.3,alpha:0},6).wait(19));

	// space shuttle
	this.instance_2 = new lib.Tween20("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(803.3,320.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(190).to({_off:false},0).to({x:549.8,y:513.8},80).to({startPosition:0},1).to({x:490.6,y:552,alpha:0},5).wait(45));

	// Layer_23 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_178 = new cjs.Graphics().p("EgA+AoQMAAAhQfIB9AAMAAABQfg");
	var mask_1_graphics_179 = new cjs.Graphics().p("EgASBDxMAAAhQgIMhAAMAAABQgg");
	var mask_1_graphics_180 = new cjs.Graphics().p("EgFjBDxMAAAhQgIXEAAMAAABQgg");
	var mask_1_graphics_181 = new cjs.Graphics().p("EgK1BDxMAAAhQgMAhnAAAMAAABQgg");
	var mask_1_graphics_182 = new cjs.Graphics().p("EgQGBDxMAAAhQgMAsKAAAMAAABQgg");
	var mask_1_graphics_183 = new cjs.Graphics().p("EgVYBDxMAAAhQgMA2tAAAMAAABQgg");
	var mask_1_graphics_184 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_185 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_186 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_187 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_188 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_189 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_190 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_191 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_192 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_193 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_194 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_195 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_196 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_197 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_198 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_199 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_200 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_201 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_202 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_203 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_204 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_205 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_206 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_207 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_208 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_209 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_210 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_211 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_212 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_213 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_214 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_215 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_216 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_217 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_218 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_219 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_220 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_221 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_222 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_223 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_224 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_225 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_226 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_227 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_228 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_229 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_230 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_231 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_232 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_233 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_234 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_235 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_236 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_237 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_238 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_239 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_240 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_241 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_242 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_243 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_244 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_245 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_246 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_247 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_248 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_249 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_250 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_251 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_252 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_253 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_254 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_255 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_256 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_257 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_258 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_259 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_260 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_261 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_262 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_263 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_264 = new cjs.Graphics().p("EgapBDxMAAAhQgMBBQAAAMAAABQgg");
	var mask_1_graphics_265 = new cjs.Graphics().p("EgVYBDxMAAAhQgMA2rAAAMAAABQgg");
	var mask_1_graphics_266 = new cjs.Graphics().p("EgQGBDxMAAAhQgMAsGAAAMAAABQgg");
	var mask_1_graphics_267 = new cjs.Graphics().p("EgK0BDxMAAAhQgMAhhAAAMAAABQgg");
	var mask_1_graphics_268 = new cjs.Graphics().p("EgFiBDxMAAAhQgIW8AAMAAABQgg");
	var mask_1_graphics_269 = new cjs.Graphics().p("EgARBDxMAAAhQgIMYAAMAAABQgg");
	var mask_1_graphics_270 = new cjs.Graphics().p("EAFABDxMAAAhQgIB0AAMAAABQgg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(178).to({graphics:mask_1_graphics_178,x:82.8,y:609.7}).wait(1).to({graphics:mask_1_graphics_179,x:78.3,y:433.7}).wait(1).to({graphics:mask_1_graphics_180,x:112.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_181,x:145.8,y:433.7}).wait(1).to({graphics:mask_1_graphics_182,x:179.6,y:433.7}).wait(1).to({graphics:mask_1_graphics_183,x:213.3,y:433.7}).wait(1).to({graphics:mask_1_graphics_184,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_185,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_186,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_187,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_188,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_189,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_190,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_191,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_192,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_193,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_194,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_195,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_196,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_197,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_198,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_199,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_200,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_201,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_202,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_203,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_204,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_205,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_206,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_207,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_208,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_209,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_210,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_211,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_212,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_213,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_214,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_215,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_216,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_217,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_218,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_219,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_220,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_221,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_222,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_223,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_224,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_225,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_226,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_227,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_228,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_229,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_230,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_231,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_232,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_233,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_234,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_235,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_236,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_237,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_238,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_239,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_240,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_241,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_242,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_243,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_244,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_245,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_246,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_247,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_248,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_249,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_250,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_251,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_252,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_253,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_254,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_255,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_256,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_257,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_258,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_259,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_260,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_261,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_262,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_263,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_264,x:247.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_265,x:213.1,y:433.7}).wait(1).to({graphics:mask_1_graphics_266,x:179.2,y:433.7}).wait(1).to({graphics:mask_1_graphics_267,x:145.3,y:433.7}).wait(1).to({graphics:mask_1_graphics_268,x:111.4,y:433.7}).wait(1).to({graphics:mask_1_graphics_269,x:77.5,y:433.7}).wait(1).to({graphics:mask_1_graphics_270,x:43.6,y:433.7}).wait(51));

	// car
	this.instance_3 = new lib.Group_20();
	this.instance_3.parent = this;
	this.instance_3.setTransform(255.9,664.7,1.95,1.95,0,0,0,57.6,52.8);
	this.instance_3.alpha = 0.801;

	this.instance_4 = new lib.Group_1_3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(298.4,611.6,1.95,1.95,0,0,0,100.5,117.4);
	this.instance_4.alpha = 0.16;

	this.instance_5 = new lib.Group_2_3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(298.4,625.5,1.95,1.95,0,0,0,100.5,129.3);
	this.instance_5.alpha = 0.449;
	this.instance_5.compositeOperation = "lighter";

	var maskedShapeInstanceList = [this.instance_3,this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},178).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},86).wait(57));

	// Layer_25 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_184 = new cjs.Graphics().p("AhfZPMAAAgyeIC/AAMAAAAyeg");
	var mask_2_graphics_185 = new cjs.Graphics().p("EAERAhxMAAAgyeIJyAAMAAAAyeg");
	var mask_2_graphics_186 = new cjs.Graphics().p("EAA5AhxMAAAgyeIQjAAMAAAAyeg");
	var mask_2_graphics_187 = new cjs.Graphics().p("EgCfAhxMAAAgyeIXTAAMAAAAyeg");
	var mask_2_graphics_188 = new cjs.Graphics().p("EgF3AhxMAAAgyeIeDAAMAAAAyeg");
	var mask_2_graphics_189 = new cjs.Graphics().p("EgJQAhxMAAAgyeMAk1AAAMAAAAyeg");
	var mask_2_graphics_190 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_191 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_192 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_193 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_194 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_195 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_196 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_197 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_198 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_199 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_200 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_201 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_202 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_203 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_204 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_205 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_206 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_207 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_208 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_209 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_210 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_211 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_212 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_213 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_214 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_215 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_216 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_217 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_218 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_219 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_220 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_221 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_222 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_223 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_224 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_225 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_226 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_227 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_228 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_229 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_230 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_231 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_232 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_233 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_234 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_235 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_236 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_237 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_238 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_239 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_240 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_241 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_242 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_243 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_244 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_245 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_246 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_247 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_248 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_249 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_250 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_251 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_252 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_253 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_254 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_255 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_256 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_257 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_258 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_259 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_260 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_261 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_262 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_263 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_264 = new cjs.Graphics().p("EgMoAhxMAAAgyeMArlAAAMAAAAyeg");
	var mask_2_graphics_265 = new cjs.Graphics().p("EgJJAhxMAAAgyeMAknAAAMAAAAyeg");
	var mask_2_graphics_266 = new cjs.Graphics().p("EgFqAhxMAAAgyeIdoAAMAAAAyeg");
	var mask_2_graphics_267 = new cjs.Graphics().p("EgCLAhxMAAAgyeIWpAAMAAAAyeg");
	var mask_2_graphics_268 = new cjs.Graphics().p("EABUAhxMAAAgyeIPqAAMAAAAyeg");
	var mask_2_graphics_269 = new cjs.Graphics().p("EAEzAhxMAAAgyeIIrAAMAAAAyeg");
	var mask_2_graphics_270 = new cjs.Graphics().p("EAISAhxMAAAgyeIBsAAMAAAAyeg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(184).to({graphics:mask_2_graphics_184,x:126.9,y:270.7}).wait(1).to({graphics:mask_2_graphics_185,x:89.9,y:216.1}).wait(1).to({graphics:mask_2_graphics_186,x:111.6,y:216.1}).wait(1).to({graphics:mask_2_graphics_187,x:133.2,y:216.1}).wait(1).to({graphics:mask_2_graphics_188,x:154.8,y:216.1}).wait(1).to({graphics:mask_2_graphics_189,x:176.5,y:216.1}).wait(1).to({graphics:mask_2_graphics_190,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_191,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_192,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_193,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_194,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_195,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_196,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_197,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_198,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_199,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_200,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_201,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_202,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_203,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_204,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_205,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_206,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_207,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_208,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_209,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_210,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_211,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_212,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_213,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_214,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_215,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_216,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_217,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_218,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_219,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_220,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_221,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_222,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_223,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_224,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_225,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_226,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_227,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_228,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_229,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_230,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_231,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_232,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_233,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_234,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_235,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_236,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_237,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_238,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_239,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_240,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_241,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_242,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_243,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_244,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_245,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_246,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_247,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_248,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_249,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_250,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_251,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_252,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_253,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_254,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_255,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_256,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_257,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_258,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_259,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_260,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_261,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_262,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_263,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_264,x:198.1,y:216.1}).wait(1).to({graphics:mask_2_graphics_265,x:175.8,y:216.1}).wait(1).to({graphics:mask_2_graphics_266,x:153.4,y:216.1}).wait(1).to({graphics:mask_2_graphics_267,x:131,y:216.1}).wait(1).to({graphics:mask_2_graphics_268,x:108.6,y:216.1}).wait(1).to({graphics:mask_2_graphics_269,x:86.2,y:216.1}).wait(1).to({graphics:mask_2_graphics_270,x:63.8,y:216.1}).wait(51));

	// analytics
	this.instance_6 = new lib.Symbol10();
	this.instance_6.parent = this;
	this.instance_6.setTransform(271.1,265);
	this.instance_6.alpha = 0.551;
	this.instance_6.compositeOperation = "lighter";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTAfQgJgIAAgPQABgNAIgNQAIgNALgEQALgEAJAIQAJAIAAAPQAAAOgJANQgJANgLAEIgGABQgIAAgFgGgAAAgXQgHACgGAJQgGAJAAAJQAAAKAGAFQAGAGAHgDQAIgCAFgJQAGgJAAgJQAAgKgGgGQgDgDgFAAIgFABg");
	this.shape.setTransform(362.5,173.2,1.869,1.869);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRAgQgHgIAAgQQAAgOAHgNQAIgNAJgEQALgDAHAIQAHAIAAAQQAAAOgIANQgHANgKAEIgGABQgGAAgFgGgAAAgYQgGACgFAJQgFAJAAAKQAAAKAEAGQAFAFAHgCQAGgDAGgIQAFgJAAgKQAAgKgFgGQgDgEgFAAIgEABg");
	this.shape_1.setTransform(331.2,219.8,1.869,1.869);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEAKQgCgDAAgEQAAgKAGgDQADgBACACQACADAAAEQgBALgGACIgBABQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBgBAAAAg");
	this.shape_2.setTransform(306.8,174.4,1.869,1.869);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPAfQgGgJAAgOQABgNAGgNQAHgNAIgDQAIgEAHAIQAGAIAAAPQgBANgGANQgHAMgIAFIgFABQgGAAgEgGgAAAgXQgFADgEAIQgFAIAAAJQAAALAEAFQAEAFAGgCQAFgCAFgJQAEgJABgJQAAgJgEgGQgDgEgEAAIgEABg");
	this.shape_3.setTransform(306.9,174.4,1.869,1.869);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAKQgCgCAAgFQABgLAFgDQAHgCAAALQgBALgGADIgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_4.setTransform(291.4,232.2,1.869,1.869);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPAgQgFgJAAgPQABgOAGgNQAGgNAIgEQAIgDAGAIQAGAIgBAPQAAAPgHANQgGANgIAEIgEABQgGAAgEgGgAAAgYQgFACgEAJQgEAKAAAJQgBAKAEAGQAEAFAGgCQAFgCAEgKQAEgIABgKQAAgKgEgGQgCgEgEAAIgEABg");
	this.shape_5.setTransform(291.4,232.2,1.869,1.869);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgDAKQgCgCAAgFQAAgLAGgDQAFgCAAALQAAAKgGAEIgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBg");
	this.shape_6.setTransform(269.8,270.9,1.869,1.869);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAhQgFgIABgPQAAgPAGgNQAGgNAHgEQAIgEAFAIQAGAIgBAPQgBAOgGAOQgGANgHAEIgEABQgFAAgEgFgAABgXQgFACgEAJQgEAJAAAKQgBAKAEAFQAEAGAFgDQAEgCAEgJQAEgKABgJQAAgKgDgFQgCgEgEAAIgDABg");
	this.shape_7.setTransform(269.8,270.8,1.869,1.869);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgFADQABgKAEgEQABAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQACADgBAEQAAAMgFACIgCABQgDAAAAgJg");
	this.shape_8.setTransform(241.9,238.2,1.869,1.869);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMAhQgFgHABgPQAAgOAGgOQAFgOAGgEQAHgFAFAIQAFAHgBAPQAAAOgGAOQgFAOgGAEIgGACQgDAAgDgFgAABgYQgEADgEAKQgDAJgBAJQAAAKADAGQADAFAFgDQAEgDAEgKQADgJABgJQAAgLgDgFQgCgDgDAAIgDABg");
	this.shape_9.setTransform(241.9,238.2,1.869,1.869);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgDALQgBgCAAgFQABgKADgEQAGgEAAALQAAAKgGAFIgBAAIgCgBg");
	this.shape_10.setTransform(216.2,320.3,1.869,1.869);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMAiQgFgHABgPQABgOAFgOQAFgOAGgFQAHgFAFAHQAFAHgBAPQgBANgFAOQgFAOgGAFQgDADgDAAQgDAAgDgEgAABgXQgEADgEAKQgDAJgBAJQAAAKADAFQADAFAFgEQAEgEADgJQAEgKAAgIQABgKgDgFQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgEACg");
	this.shape_11.setTransform(216.2,320.3,1.869,1.869);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgDALQgCgCAAgEQAAgLAFgEQABgBABAAQAAAAABAAQAAAAABAAQAAAAAAAAQACACgBAFQAAAKgFAFIgBABIgCgBg");
	this.shape_12.setTransform(194.3,302.6,1.869,1.869);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMAjQgFgFAAgPQAAgOAGgOQAFgPAHgHQAHgFAGAFQAEAHAAAOQAAAOgGAPQgGAOgGAGQgEAEgDAAQgDAAgCgEgAAAgXQgEAEgDAKQgEAKgBAJQABAKADAEQADAEAFgEQAEgEAEgKQAEgKAAgJQAAgKgDgEQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQgCAAgDACg");
	this.shape_13.setTransform(194.3,302.5,1.869,1.869);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDALQgCgBAAgEQAAgLAFgFQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQACABAAAEQAAALgGAFIgCABIgBgBg");
	this.shape_14.setTransform(169.5,370.3,1.869,1.869);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgNAkQgFgFAAgOQAAgOAFgOQAGgPAHgHQAIgHAFAFQAGAFAAAOQAAAOgGAOQgFAPgIAHQgEAEgDAAQgDAAgDgCgAAAgWQgEAFgEAKQgEAJAAAKQAAAJAEAEQAEADAEgFQAFgEAEgLQAEgJAAgJQAAgKgDgEIgEgBQgDAAgDADg");
	this.shape_15.setTransform(169.5,370.2,1.869,1.869);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AoGIPICHlxIADACIBEA9QAoAjAGABICImyIADgGIBIBUIBLBZQA2hiA7hjQA3jXAehrQBHCKA9BoQBLh5BYh4IAGAHQhWB1hVCHQg5hihJiNQgkCGgtCtQg2BchABxIhKhXIhIhUIhCDeQgnCGggBOQgBACgOgMIhohUIiDFlg");
	this.shape_16.setTransform(266.1,271.5,1.869,1.869);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgFAKQgDgCAAgFQAAgEADgEQADgEACgCQAEAAACACQADADAAAEQAAAEgDAEQgCAFgEABIgBAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_17.setTransform(362.6,173.2,1.869,1.869);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgFAKQgCgCAAgFQAAgEACgEQADgFACgBQADgBACADQADACAAAFQAAALgIADIgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBg");
	this.shape_18.setTransform(331.2,219.7,1.869,1.869);

	var maskedShapeInstanceList = [this.instance_6,this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_6}]},184).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_6}]},80).wait(57));

	// Layer_24 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_178 = new cjs.Graphics().p("AhQQAIAA//IChAAIAAf/g");
	var mask_3_graphics_179 = new cjs.Graphics().p("EA0IAZ9IAA/+II9AAIAAf+g");
	var mask_3_graphics_180 = new cjs.Graphics().p("EAt5AZ9IAA/+IPYAAIAAf+g");
	var mask_3_graphics_181 = new cjs.Graphics().p("EAnqAZ9IAA/+IVyAAIAAf+g");
	var mask_3_graphics_182 = new cjs.Graphics().p("EAhbAZ9IAA/+IcNAAIAAf+g");
	var mask_3_graphics_183 = new cjs.Graphics().p("AbMZ9IAA/+MAinAAAIAAf+g");
	var mask_3_graphics_184 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_185 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_186 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_187 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_188 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_189 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_190 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_191 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_192 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_193 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_194 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_195 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_196 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_197 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_198 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_199 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_200 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_201 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_202 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_203 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_204 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_205 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_206 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_207 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_208 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_209 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_210 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_211 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_212 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_213 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_214 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_215 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_216 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_217 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_218 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_219 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_220 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_221 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_222 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_223 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_224 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_225 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_226 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_227 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_228 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_229 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_230 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_231 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_232 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_233 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_234 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_235 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_236 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_237 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_238 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_239 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_240 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_241 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_242 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_243 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_244 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_245 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_246 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_247 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_248 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_249 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_250 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_251 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_252 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_253 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_254 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_255 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_256 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_257 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_258 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_259 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_260 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_261 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_262 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_263 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_264 = new cjs.Graphics().p("AT4Z9IAA/+MApCAAAIAAf+g");
	var mask_3_graphics_265 = new cjs.Graphics().p("AahZ9IAA/+MAilAAAIAAf+g");
	var mask_3_graphics_266 = new cjs.Graphics().p("EAhLAZ9IAA/+IcHAAIAAf+g");
	var mask_3_graphics_267 = new cjs.Graphics().p("EAn1AZ9IAA/+IVqAAIAAf+g");
	var mask_3_graphics_268 = new cjs.Graphics().p("EAueAZ9IAA/+IPNAAIAAf+g");
	var mask_3_graphics_269 = new cjs.Graphics().p("EA1IAZ9IAA/+IIvAAIAAf+g");
	var mask_3_graphics_270 = new cjs.Graphics().p("EA7yAZ9IAA/+ICRAAIAAf+g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(178).to({graphics:mask_3_graphics_178,x:771.5,y:229.9}).wait(1).to({graphics:mask_3_graphics_179,x:390.9,y:166.2}).wait(1).to({graphics:mask_3_graphics_180,x:392.1,y:166.2}).wait(1).to({graphics:mask_3_graphics_181,x:393.2,y:166.2}).wait(1).to({graphics:mask_3_graphics_182,x:394.4,y:166.2}).wait(1).to({graphics:mask_3_graphics_183,x:395.5,y:166.2}).wait(1).to({graphics:mask_3_graphics_184,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_185,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_186,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_187,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_188,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_189,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_190,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_191,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_192,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_193,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_194,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_195,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_196,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_197,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_198,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_199,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_200,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_201,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_202,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_203,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_204,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_205,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_206,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_207,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_208,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_209,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_210,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_211,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_212,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_213,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_214,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_215,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_216,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_217,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_218,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_219,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_220,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_221,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_222,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_223,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_224,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_225,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_226,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_227,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_228,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_229,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_230,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_231,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_232,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_233,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_234,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_235,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_236,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_237,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_238,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_239,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_240,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_241,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_242,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_243,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_244,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_245,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_246,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_247,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_248,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_249,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_250,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_251,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_252,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_253,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_254,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_255,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_256,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_257,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_258,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_259,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_260,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_261,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_262,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_263,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_264,x:389.8,y:166.2}).wait(1).to({graphics:mask_3_graphics_265,x:391,y:166.2}).wait(1).to({graphics:mask_3_graphics_266,x:392.2,y:166.2}).wait(1).to({graphics:mask_3_graphics_267,x:393.5,y:166.2}).wait(1).to({graphics:mask_3_graphics_268,x:394.7,y:166.2}).wait(1).to({graphics:mask_3_graphics_269,x:395.9,y:166.2}).wait(1).to({graphics:mask_3_graphics_270,x:397.1,y:166.2}).wait(51));

	// video
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ah5iNIDzDwIjzArg");
	this.shape_19.setTransform(640.9,211.7,1.395,1.395);

	this.instance_7 = new lib.ClipGroup_0_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(637.8,224.7,1.395,1.395,0,0,0,76.7,69.2);
	this.instance_7.alpha = 0.422;
	this.instance_7.compositeOperation = "lighter";

	var maskedShapeInstanceList = [this.shape_19,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7},{t:this.shape_19}]},178).to({state:[{t:this.instance_7},{t:this.shape_19}]},86).wait(57));

	// Layer_22 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_184 = new cjs.Graphics().p("EBB5A7+MAAAg6SIDaAAMAAAA6Sg");
	var mask_4_graphics_185 = new cjs.Graphics().p("EA6SA7+MAAAg6SILBAAMAAAA6Sg");
	var mask_4_graphics_186 = new cjs.Graphics().p("EAyrA7+MAAAg6SISpAAMAAAA6Sg");
	var mask_4_graphics_187 = new cjs.Graphics().p("EArEA7+MAAAg6SIaRAAMAAAA6Sg");
	var mask_4_graphics_188 = new cjs.Graphics().p("EAjdA7+MAAAg6SMAh4AAAMAAAA6Sg");
	var mask_4_graphics_189 = new cjs.Graphics().p("EAb2A7+MAAAg6SMApgAAAMAAAA6Sg");
	var mask_4_graphics_190 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_191 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_192 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_193 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_194 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_195 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_196 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_197 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_198 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_199 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_200 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_201 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_202 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_203 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_204 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_205 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_206 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_207 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_208 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_209 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_210 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_211 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_212 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_213 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_214 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_215 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_216 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_217 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_218 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_219 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_220 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_221 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_222 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_223 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_224 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_225 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_226 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_227 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_228 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_229 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_230 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_231 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_232 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_233 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_234 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_235 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_236 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_237 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_238 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_239 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_240 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_241 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_242 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_243 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_244 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_245 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_246 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_247 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_248 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_249 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_250 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_251 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_252 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_253 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_254 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_255 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_256 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_257 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_258 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_259 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_260 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_261 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_262 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_263 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_264 = new cjs.Graphics().p("EAULA7+MAAAg6SMAxHAAAMAAAA6Sg");
	var mask_4_graphics_265 = new cjs.Graphics().p("EAb/A7+MAAAg6SMApUAAAMAAAA6Sg");
	var mask_4_graphics_266 = new cjs.Graphics().p("EAjzA7+MAAAg6SMAhhAAAMAAAA6Sg");
	var mask_4_graphics_267 = new cjs.Graphics().p("EArnA7+MAAAg6SIZtAAMAAAA6Sg");
	var mask_4_graphics_268 = new cjs.Graphics().p("EAzbA7+MAAAg6SIR6AAMAAAA6Sg");
	var mask_4_graphics_269 = new cjs.Graphics().p("EA7PA7+MAAAg6SIKHAAMAAAA6Sg");
	var mask_4_graphics_270 = new cjs.Graphics().p("EBDDA7+MAAAg6SICUAAMAAAA6Sg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(184).to({graphics:mask_4_graphics_184,x:443.5,y:383.8}).wait(1).to({graphics:mask_4_graphics_185,x:443.5,y:383.8}).wait(1).to({graphics:mask_4_graphics_186,x:443.6,y:383.8}).wait(1).to({graphics:mask_4_graphics_187,x:443.7,y:383.8}).wait(1).to({graphics:mask_4_graphics_188,x:443.7,y:383.8}).wait(1).to({graphics:mask_4_graphics_189,x:443.8,y:383.8}).wait(1).to({graphics:mask_4_graphics_190,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_191,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_192,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_193,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_194,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_195,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_196,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_197,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_198,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_199,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_200,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_201,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_202,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_203,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_204,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_205,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_206,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_207,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_208,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_209,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_210,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_211,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_212,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_213,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_214,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_215,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_216,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_217,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_218,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_219,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_220,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_221,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_222,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_223,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_224,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_225,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_226,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_227,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_228,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_229,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_230,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_231,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_232,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_233,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_234,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_235,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_236,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_237,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_238,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_239,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_240,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_241,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_242,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_243,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_244,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_245,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_246,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_247,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_248,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_249,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_250,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_251,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_252,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_253,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_254,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_255,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_256,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_257,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_258,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_259,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_260,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_261,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_262,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_263,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_264,x:443.4,y:383.8}).wait(1).to({graphics:mask_4_graphics_265,x:443.5,y:383.8}).wait(1).to({graphics:mask_4_graphics_266,x:443.6,y:383.8}).wait(1).to({graphics:mask_4_graphics_267,x:443.6,y:383.8}).wait(1).to({graphics:mask_4_graphics_268,x:443.7,y:383.8}).wait(1).to({graphics:mask_4_graphics_269,x:443.8,y:383.8}).wait(1).to({graphics:mask_4_graphics_270,x:443.9,y:383.8}).wait(51));

	// CTA
	this.instance_8 = new lib.Symbol7();
	this.instance_8.parent = this;
	this.instance_8.setTransform(710.3,578.9,1.143,1.143);
	this.instance_8.compositeOperation = "lighter";

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgOA3IgBAAIgngKQgGgCgDgDQgFgFAAgFQAAgGAEgGQACgFAHgDQAjgOAUgMQAQgKAngbQAFgEAEABQAFACAAAFQAAAGgEAJQgEAJgGAIIggAxIgBACIgJANIgFAFIgDADIgEABIgEABg");
	this.shape_20.setTransform(729.2,549.9,2.556,2.556);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgPASIAfgxIAAA/QgJgFgWgJg");
	this.shape_21.setTransform(742.8,551.4,2.556,2.556);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgRgfQADADAFABIAcAHIgkA0g");
	this.shape_22.setTransform(716.4,571.6,2.556,2.556);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhAAtQAZgiARgaIADABIAIABIAIAAQAEAAAEgDIAAAAQAFgDADgEIAQgWQAdALAHAFQgCAGgEADQgYAUgbAPQgYANgnAQIgFACIgEgBg");
	this.shape_23.setTransform(729.4,570.8,2.556,2.556);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgWAxQgtgTgGgiQgCgPAQgXQARgXAIAOIALAVQADAHgGAKQgHALAAACQAAADAGAGIAJAIQAGADAKAEQALADAHgBQADgBADgEIAFgHIAJgOQADgCAFABIAaADQAHACgGAOQgGAMgIAJQgUASgZAAQgPAAgTgIg");
	this.shape_24.setTransform(642.3,601.4,2.556,2.556);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAmAeIABgDIAAgDQAAgdgUgMQgUgNgcANIgJAFIgDACQAAAAgBAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgCADgEIANgHQAegPAXAPQAWAOAAAfIAAAHQgBADgDABIgCAAQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAgBAAAAg");
	this.shape_25.setTransform(650,587.1,2.556,2.556);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAbAVIAAgDIAAgBQAAgKgDgHQgDgHgIgFQgIgFgLACQgHAAgHAEIgEACIgCABIgDACQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgDAEgDIAOgHQAUgHAOAJQANAIACAPIABAJIAAAFQgBAEgDABIgBAAQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAgBAAgBg");
	this.shape_26.setTransform(647.9,590.7,2.556,2.556);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAPAOIABgCIAAgCQAAgLgJgFQgHgFgMAGIgDABIAAAAIgCACQgBAAgBABQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAgEADgCIACgCIAEgBIAJgDQAIgCAHAEQAGAFACAFQACAGABAFIAAACIgBABQAAAEgEABIgBABQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBg");
	this.shape_27.setTransform(645.8,594.2,2.556,2.556);

	this.instance_9 = new lib.Group_21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(803.2,592.6,2.556,2.556,0,0,0,5,10.2);
	this.instance_9.alpha = 0.898;

	this.instance_10 = new lib.Group_1_4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(735.1,643.9,2.556,2.556,0,0,0,6.5,7.5);
	this.instance_10.alpha = 0.898;

	this.instance_11 = new lib.Group_2_2();
	this.instance_11.parent = this;
	this.instance_11.setTransform(647.6,685.6,2.556,2.556,0,0,0,7.4,8);
	this.instance_11.alpha = 0.898;

	this.instance_12 = new lib.Group_3_2();
	this.instance_12.parent = this;
	this.instance_12.setTransform(800.1,502,2.556,2.556,0,0,0,6.2,7.4);
	this.instance_12.alpha = 0.898;

	var maskedShapeInstanceList = [this.instance_8,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.instance_9,this.instance_10,this.instance_11,this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.instance_8}]},184).wait(137));

	// tree-3
	this.instance_13 = new lib.ClipGroup_29();
	this.instance_13.parent = this;
	this.instance_13.setTransform(214.4,431.6,4.485,4.485,0,0,0,8.8,13.2);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(172).to({_off:false},0).to({y:461.3,alpha:1},5).wait(87).to({y:396.8,alpha:0},6).wait(51));

	// tree-2
	this.instance_14 = new lib.Tween25("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(547.2,712.2);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(169).to({_off:false},0).to({y:760.2,alpha:1},5).to({startPosition:0},90).to({y:700.2,alpha:0},6).wait(51));

	// tree-1
	this.instance_15 = new lib.Tween26("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(671.6,338.3);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(166).to({_off:false},0).to({y:386.3,alpha:1},5).to({startPosition:0},93).to({y:326.3,alpha:0},6).wait(51));

	// Layer_35 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_253 = new cjs.Graphics().p("Egw3AEdIAAo5MBhvAAAIAAI5g");
	var mask_5_graphics_254 = new cjs.Graphics().p("EgmUBBmIAAzYMBhvAAAIAATYg");
	var mask_5_graphics_255 = new cjs.Graphics().p("EgmUBBqIAA91MBhvAAAIAAd1g");
	var mask_5_graphics_256 = new cjs.Graphics().p("EgmUBBvMAAAgoTMBhvAAAMAAAAoTg");
	var mask_5_graphics_257 = new cjs.Graphics().p("EgmUBBzMAAAgywMBhvAAAMAAAAywg");
	var mask_5_graphics_258 = new cjs.Graphics().p("EgmUBB4MAAAg9PMBhvAAAMAAAA9Pg");
	var mask_5_graphics_259 = new cjs.Graphics().p("EgmUBB8MAAAhHrMBhvAAAMAAABHrg");
	var mask_5_graphics_260 = new cjs.Graphics().p("EgmUBCBMAAAhSJMBhvAAAMAAABSJg");
	var mask_5_graphics_261 = new cjs.Graphics().p("EgmUBCFMAAAhcmMBhvAAAMAAABcmg");
	var mask_5_graphics_262 = new cjs.Graphics().p("EgmUBCJMAAAhnEMBhvAAAMAAABnEg");
	var mask_5_graphics_263 = new cjs.Graphics().p("EgmUBCOMAAAhxiMBhvAAAMAAABxig");
	var mask_5_graphics_264 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_265 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_266 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_267 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_268 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_269 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_270 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_271 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_272 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_273 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_274 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_275 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_276 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_277 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_278 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_279 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_280 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_281 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_282 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_283 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_284 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_285 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_286 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_287 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_288 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_289 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_290 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_291 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_292 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_293 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_294 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_295 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_296 = new cjs.Graphics().p("EgmUBBiMAAAh8AMBhvAAAMAAAB8Ag");
	var mask_5_graphics_297 = new cjs.Graphics().p("EgmUBBoMAAAhuwMBhvAAAMAAABuwg");
	var mask_5_graphics_298 = new cjs.Graphics().p("EgmUBBuMAAAhhgMBhvAAAMAAABhgg");
	var mask_5_graphics_299 = new cjs.Graphics().p("EgmUBB0MAAAhURMBhvAAAMAAABURg");
	var mask_5_graphics_300 = new cjs.Graphics().p("EgmUBB7MAAAhHCMBhvAAAMAAABHCg");
	var mask_5_graphics_301 = new cjs.Graphics().p("EgmUBCBMAAAg5zMBhvAAAMAAAA5zg");
	var mask_5_graphics_302 = new cjs.Graphics().p("EgmUBCHMAAAgskMBhvAAAMAAAAskg");
	var mask_5_graphics_303 = new cjs.Graphics().p("EgmUBCNIAA/UMBhvAAAIAAfUg");
	var mask_5_graphics_304 = new cjs.Graphics().p("EgmUBCUIAAyFMBhvAAAIAASFg");
	var mask_5_graphics_305 = new cjs.Graphics().p("EgmUBCaIAAk1MBhvAAAIAAE1g");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(253).to({graphics:mask_5_graphics_253,x:447.8,y:810.2}).wait(1).to({graphics:mask_5_graphics_254,x:380.3,y:419.8}).wait(1).to({graphics:mask_5_graphics_255,x:380.3,y:420.2}).wait(1).to({graphics:mask_5_graphics_256,x:380.3,y:420.7}).wait(1).to({graphics:mask_5_graphics_257,x:380.3,y:421.1}).wait(1).to({graphics:mask_5_graphics_258,x:380.3,y:421.6}).wait(1).to({graphics:mask_5_graphics_259,x:380.3,y:422}).wait(1).to({graphics:mask_5_graphics_260,x:380.3,y:422.5}).wait(1).to({graphics:mask_5_graphics_261,x:380.3,y:422.9}).wait(1).to({graphics:mask_5_graphics_262,x:380.3,y:423.3}).wait(1).to({graphics:mask_5_graphics_263,x:380.3,y:423.8}).wait(1).to({graphics:mask_5_graphics_264,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_265,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_266,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_267,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_268,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_269,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_270,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_271,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_272,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_273,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_274,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_275,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_276,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_277,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_278,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_279,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_280,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_281,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_282,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_283,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_284,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_285,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_286,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_287,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_288,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_289,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_290,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_291,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_292,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_293,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_294,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_295,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_296,x:380.3,y:419.4}).wait(1).to({graphics:mask_5_graphics_297,x:380.3,y:420}).wait(1).to({graphics:mask_5_graphics_298,x:380.3,y:420.6}).wait(1).to({graphics:mask_5_graphics_299,x:380.3,y:421.2}).wait(1).to({graphics:mask_5_graphics_300,x:380.3,y:421.9}).wait(1).to({graphics:mask_5_graphics_301,x:380.3,y:422.5}).wait(1).to({graphics:mask_5_graphics_302,x:380.3,y:423.1}).wait(1).to({graphics:mask_5_graphics_303,x:380.3,y:423.7}).wait(1).to({graphics:mask_5_graphics_304,x:380.3,y:424.4}).wait(1).to({graphics:mask_5_graphics_305,x:380.3,y:425}).wait(16));

	// data colletion glow
	this.instance_16 = new lib.Symbol9();
	this.instance_16.parent = this;
	this.instance_16.setTransform(452.7,357,1.021,0.994,0,0,0,0.1,0.1);
	this.instance_16.alpha = 0.441;
	this.instance_16.compositeOperation = "lighter";
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(253).to({_off:false},0).wait(68));

	// skelital
	this.instance_17 = new lib.Tween42("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(455,457.4);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween43("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(455,457.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AgCAAIAFAA");
	this.shape_28.setTransform(451.8,319.9,4.004,4.084);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AABACIgBgD");
	this.shape_29.setTransform(429.4,594.4,4.004,4.084);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAEiiIgHFF");
	this.shape_30.setTransform(434.5,528.7,4.004,4.084);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgFijIALFH");
	this.shape_31.setTransform(483,528.2,4.004,4.084);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgbgUIA3Ap");
	this.shape_32.setTransform(469.4,449.6,4.004,4.084);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("Ag1iDIBZAgIAPB1IAAB2");
	this.shape_33.setTransform(481.2,407.8,4.004,4.084);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("ABAhmIhGgKIg1Dm");
	this.shape_34.setTransform(432.3,396,4.004,4.084);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAXiuIAEBUIAADUIg2Ay");
	this.shape_35.setTransform(447.4,391.2,4.004,4.084);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_36.setTransform(408.3,444.2,4.004,4.084);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_37.setTransform(408.3,444.2,4.004,4.084);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDADQgCACgDAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_38.setTransform(429.7,349.6,4.004,4.084);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_39.setTransform(429.7,349.6,4.004,4.084);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_40.setTransform(419.9,396.3,4.004,4.084);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHAAQAIAAAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_41.setTransform(419.9,396.3,4.004,4.084);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_42.setTransform(436,462.4,4.004,4.084);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.498)").s().p("AgGAAQgBgHAHAAQAHAAAAAHQAAAIgHAAQgHAAABgIg");
	this.shape_43.setTransform(436,462.4,4.004,4.084);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_44.setTransform(485.4,595.2,4.004,4.084);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgCACgBQAIABAAAGQAAAIgIAAQgHAAAAgIg");
	this.shape_45.setTransform(485.4,595.2,4.004,4.084);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_46.setTransform(432.9,595.2,4.004,4.084);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgGAHgBQADABADACQACACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_47.setTransform(432.9,595.2,4.004,4.084);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_48.setTransform(435.1,529.8,4.004,4.084);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_49.setTransform(435.1,529.8,4.004,4.084);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCACQgDADgDAAQgHAAAAgIQAAgHAHAAQADAAADADQACACAAACg");
	this.shape_50.setTransform(482.6,526.7,4.004,4.084);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQADAAADADQACACAAACQAAADgCACQgDADgDAAQgHAAAAgIg");
	this.shape_51.setTransform(482.6,526.7,4.004,4.084);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAADgCADQgDACgDAAQgHAAAAgIQAAgHAHAAQAIAAAAAHg");
	this.shape_52.setTransform(480.6,458.1,4.004,4.084);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgHAHAAQAIAAAAAHQAAADgCADQgDACgDAAQgHAAAAgIg");
	this.shape_53.setTransform(480.6,458.1,4.004,4.084);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_54.setTransform(458.2,441,4.004,4.084);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgHAHABQAIgBAAAHQAAAHgIAAQgCAAgCgCg");
	this.shape_55.setTransform(458.2,441,4.004,4.084);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_56.setTransform(501.6,463.6,4.004,4.084);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_57.setTransform(501.6,463.6,4.004,4.084);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgDQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_58.setTransform(501.6,415.4,4.004,4.084);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_59.setTransform(501.6,415.4,4.004,4.084);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgHAAAAgIQAAgCADgCQACgDACAAQADAAACADQADACAAACg");
	this.shape_60.setTransform(496,367.2,4.004,4.084);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.498)").s().p("AgHAAQAAgCADgCQACgDACAAQADAAACADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_61.setTransform(496,367.2,4.004,4.084);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgHAHAAQAIAAAAAHg");
	this.shape_62.setTransform(458.2,353.9,4.004,4.084);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgHAHAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_63.setTransform(458.2,353.9,4.004,4.084);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("rgba(255,255,255,0.498)").ss(0.1).p("AAIAAQAAAIgIAAQgCAAgCgCQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHg");
	this.shape_64.setTransform(456.6,319.6,4.004,4.084);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_65.setTransform(456.6,319.6,4.004,4.084);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AFsmAIkdgqIhpHSIlOGF");
	this.shape_66.setTransform(421.7,392.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AgEinIAKFP");
	this.shape_67.setTransform(483.1,526.8,4.004,4.084);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGwjhIkcgqIhqHSInZBG");
	this.shape_68.setTransform(414.8,376.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AAWivIAEBUIAADUIg1A0");
	this.shape_69.setTransform(447.4,391.8,4.004,4.084);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AIahvIkdgrImBE0ImTkL");
	this.shape_70.setTransform(404.3,365.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGjEeIkcgrInJg3Ihcnd");
	this.shape_71.setTransform(416.1,325.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGzEfIkcgqInJg4Ih8nf");
	this.shape_72.setTransform(414.5,325.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AG/EcIkcgqInJg4IiUnZ");
	this.shape_73.setTransform(413.3,325.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHNEZIkcgrInJg3IiwnS");
	this.shape_74.setTransform(411.9,325.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHaEUIkcgrInJg3IjKnH");
	this.shape_75.setTransform(410.6,326.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHkEOIkcgqInJg4Ijem8");
	this.shape_76.setTransform(409.6,327);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHwELIkcgrInJg3Ij3m1");
	this.shape_77.setTransform(408.4,327.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AH9EFIkcgrInJg3IkRmp");
	this.shape_78.setTransform(407.1,327.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHlEOIkcgqInJg4Ijhm8");
	this.shape_79.setTransform(409.5,327);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AHLEZIkcgqInJg4IisnS");
	this.shape_80.setTransform(412.1,325.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGtEhIkcgqInJg4Ihwnj");
	this.shape_81.setTransform(415.1,325.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGSEmIkdgrInJg3Ig5nt");
	this.shape_82.setTransform(417.9,324.6);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF1ElIkcgqInJg4IAFns");
	this.shape_83.setTransform(420.3,324.7);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF2EmIkdgrInJg3IA9nt");
	this.shape_84.setTransform(420.3,324.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF2EiIkdgrInJg3IB6nl");
	this.shape_85.setTransform(420.3,325);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF2ElIkdgrInJg3IBgnr");
	this.shape_86.setTransform(420.3,324.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF2EnIkdgqInJg4IBGnw");
	this.shape_87.setTransform(420.3,324.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF2EqIkdgrInJg3IAqn2");
	this.shape_88.setTransform(420.3,324.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF1EpIkcgrInJg3IATn0");
	this.shape_89.setTransform(420.3,324.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AF6EpIkcgrInJg3IgKn0");
	this.shape_90.setTransform(419.8,324.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGlEfIkdgqInJg4Ihfnf");
	this.shape_91.setTransform(415.6,325.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AH6BuIkdgrIm6CTIkZmu");
	this.shape_92.setTransform(407.1,343);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AIahuIkcgrIlzEyImikX");
	this.shape_93.setTransform(403.8,365.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AJHhuIkcgqIlzEyIn+gj");
	this.shape_94.setTransform(399.3,365.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AIYkEIkcgrIlzEyImeEu");
	this.shape_95.setTransform(404,380.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AGQmJIkdgqIj3HBIkHGp");
	this.shape_96.setTransform(417.7,393.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("AEbm+IkbgqIh8HvIiaHn");
	this.shape_97.setTransform(429.3,398.7);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("rgba(255,255,255,0.498)").ss(0.5).p("ADHnIIkcgrIgvHzIg+H5");
	this.shape_98.setTransform(437.8,399.7);

	this.instance_19 = new lib.Tween46("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(459.8,457.4);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},124).to({state:[{t:this.instance_17}]},9).to({state:[{t:this.instance_18}]},33).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:419.9,y:396.3}},{t:this.shape_40,p:{x:419.9,y:396.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:408.3,y:444.2}},{t:this.shape_36,p:{x:408.3,y:444.2}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{y:528.7}},{t:this.shape_29},{t:this.shape_28}]},28).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:419.9,y:396.3}},{t:this.shape_40,p:{x:419.9,y:396.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:408.3,y:444.2}},{t:this.shape_36,p:{x:408.3,y:444.2}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{y:528.7}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:419.9,y:396.3}},{t:this.shape_40,p:{x:419.9,y:396.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:384.6,y:436.3}},{t:this.shape_36,p:{x:384.6,y:436.3}},{t:this.shape_35},{t:this.shape_66},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{y:528.7}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:419.9,y:396.3}},{t:this.shape_40,p:{x:419.9,y:396.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:371.1,y:403.5}},{t:this.shape_36,p:{x:371.1,y:403.5}},{t:this.shape_69},{t:this.shape_68},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:391.1,y:380.4}},{t:this.shape_40,p:{x:391.1,y:380.4}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:349.3,y:352.9}},{t:this.shape_36,p:{x:349.3,y:352.9}},{t:this.shape_69},{t:this.shape_70},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:374.2,y:295.6}},{t:this.shape_36,p:{x:374.2,y:295.6}},{t:this.shape_69},{t:this.shape_71},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:374.2,y:295.6}},{t:this.shape_36,p:{x:374.2,y:295.6}},{t:this.shape_69},{t:this.shape_71},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:374.2,y:295.6}},{t:this.shape_36,p:{x:374.2,y:295.6}},{t:this.shape_69},{t:this.shape_71},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},4).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:371.6,y:295.6}},{t:this.shape_36,p:{x:371.6,y:295.6}},{t:this.shape_69},{t:this.shape_72},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:368.8,y:296.2}},{t:this.shape_36,p:{x:368.8,y:296.2}},{t:this.shape_69},{t:this.shape_73},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:366.1,y:297.1}},{t:this.shape_36,p:{x:366.1,y:297.1}},{t:this.shape_69},{t:this.shape_74},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:363.6,y:298.2}},{t:this.shape_36,p:{x:363.6,y:298.2}},{t:this.shape_69},{t:this.shape_75},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:361.2,y:299.1}},{t:this.shape_36,p:{x:361.2,y:299.1}},{t:this.shape_69},{t:this.shape_76},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:358.7,y:299.9}},{t:this.shape_36,p:{x:358.7,y:299.9}},{t:this.shape_69},{t:this.shape_77},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:356.3,y:301.7}},{t:this.shape_36,p:{x:356.3,y:301.7}},{t:this.shape_69},{t:this.shape_78},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:361.1,y:299.3}},{t:this.shape_36,p:{x:361.1,y:299.3}},{t:this.shape_69},{t:this.shape_79},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:366.5,y:297.1}},{t:this.shape_36,p:{x:366.5,y:297.1}},{t:this.shape_69},{t:this.shape_80},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:372.5,y:295.6}},{t:this.shape_36,p:{x:372.5,y:295.6}},{t:this.shape_69},{t:this.shape_81},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:378.1,y:294.6}},{t:this.shape_36,p:{x:378.1,y:294.6}},{t:this.shape_69},{t:this.shape_82},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:383.9,y:294.6}},{t:this.shape_36,p:{x:383.9,y:294.6}},{t:this.shape_69},{t:this.shape_83},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:389.6,y:294.4}},{t:this.shape_36,p:{x:389.6,y:294.4}},{t:this.shape_69},{t:this.shape_84},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:395.4,y:295.2}},{t:this.shape_36,p:{x:395.4,y:295.2}},{t:this.shape_69},{t:this.shape_85},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:395.4,y:295.2}},{t:this.shape_36,p:{x:395.4,y:295.2}},{t:this.shape_69},{t:this.shape_85},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:392.8,y:295.2}},{t:this.shape_36,p:{x:392.8,y:295.2}},{t:this.shape_69},{t:this.shape_86},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},10).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:390.6,y:294.6}},{t:this.shape_36,p:{x:390.6,y:294.6}},{t:this.shape_69},{t:this.shape_87},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:387.9,y:294}},{t:this.shape_36,p:{x:387.9,y:294}},{t:this.shape_69},{t:this.shape_88},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:385.2,y:294}},{t:this.shape_36,p:{x:385.2,y:294}},{t:this.shape_69},{t:this.shape_89},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:382.3,y:294}},{t:this.shape_36,p:{x:382.3,y:294}},{t:this.shape_69},{t:this.shape_90},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:382.3,y:294}},{t:this.shape_36,p:{x:382.3,y:294}},{t:this.shape_69},{t:this.shape_90},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:383.8,y:344.6}},{t:this.shape_40,p:{x:383.8,y:344.6}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:373.9,y:295.2}},{t:this.shape_36,p:{x:373.9,y:295.2}},{t:this.shape_69},{t:this.shape_91},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:385,y:363.9}},{t:this.shape_40,p:{x:385,y:363.9}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:356.5,y:321.2}},{t:this.shape_36,p:{x:356.5,y:321.2}},{t:this.shape_69},{t:this.shape_92},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:391.9,y:380}},{t:this.shape_40,p:{x:391.9,y:380}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:349.7,y:351.9}},{t:this.shape_36,p:{x:349.7,y:351.9}},{t:this.shape_69},{t:this.shape_93},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:391.9,y:380}},{t:this.shape_40,p:{x:391.9,y:380}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:340.7,y:376.5}},{t:this.shape_36,p:{x:340.7,y:376.5}},{t:this.shape_69},{t:this.shape_94},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:391.9,y:380}},{t:this.shape_40,p:{x:391.9,y:380}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:350.3,y:410.5}},{t:this.shape_36,p:{x:350.3,y:410.5}},{t:this.shape_69},{t:this.shape_95},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:404.3,y:394.8}},{t:this.shape_40,p:{x:404.3,y:394.8}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:378.1,y:437}},{t:this.shape_36,p:{x:378.1,y:437}},{t:this.shape_69},{t:this.shape_96},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},2).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:416.7,y:399.3}},{t:this.shape_40,p:{x:416.7,y:399.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:401.4,y:448}},{t:this.shape_36,p:{x:401.4,y:448}},{t:this.shape_69},{t:this.shape_97},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:424.2,y:399.3}},{t:this.shape_40,p:{x:424.2,y:399.3}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:418,y:450.2}},{t:this.shape_36,p:{x:418,y:450.2}},{t:this.shape_69},{t:this.shape_98},{t:this.shape_33},{t:this.shape_32},{t:this.shape_67},{t:this.shape_30,p:{y:528.8}},{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.instance_19}]},67).to({state:[{t:this.instance_19}]},10).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(124).to({_off:false},0).to({alpha:1},9).to({_off:true},33).wait(155));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(310).to({_off:false},0).to({y:349.9,alpha:0},10).wait(1));

	// Camera
	this.instance_20 = new lib.Symbol11();
	this.instance_20.parent = this;
	this.instance_20.setTransform(325.5,248.4);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(118).to({_off:false},0).to({x:368.6,y:248.5,alpha:0.871},9).to({alpha:0.781},6).to({x:369,y:248.9,alpha:0.301},33).wait(98).to({alpha:0},6).wait(51));

	// Kinet
	this.instance_21 = new lib.Symbol12();
	this.instance_21.parent = this;
	this.instance_21.setTransform(191.9,354.8,3.933,3.933,0,0,0,0,0.2);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(111).to({_off:false},0).to({x:277.9,y:354.9,alpha:0.891},9).to({regY:0,y:354,alpha:0.301},46).wait(98).to({regY:0.2,y:354.8},0).to({alpha:0},6).wait(51));

	// IOT 1
	this.instance_22 = new lib.iot();
	this.instance_22.parent = this;
	this.instance_22.setTransform(588.5,425.8,0.678,0.678);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(105).to({_off:false},0).to({x:571,y:426.9,alpha:1},9).wait(19).to({x:570.9,alpha:0.52},33).to({regX:0.1,regY:0.1,x:571},52).to({regX:0,regY:0,x:570.9},46).to({alpha:0},6).wait(51));

	// Layer_33 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_233 = new cjs.Graphics().p("AglHSIAAujIBLAAIAAOjg");
	var mask_6_graphics_234 = new cjs.Graphics().p("EAU6A+zIAAukID/AAIAAOkg");
	var mask_6_graphics_235 = new cjs.Graphics().p("EASQA+zIAAukIGzAAIAAOkg");
	var mask_6_graphics_236 = new cjs.Graphics().p("EAPmA+zIAAukIJmAAIAAOkg");
	var mask_6_graphics_237 = new cjs.Graphics().p("EAM7A+zIAAukIMbAAIAAOkg");
	var mask_6_graphics_238 = new cjs.Graphics().p("EAKRA+zIAAukIPPAAIAAOkg");
	var mask_6_graphics_239 = new cjs.Graphics().p("EAHnA+zIAAukISCAAIAAOkg");
	var mask_6_graphics_240 = new cjs.Graphics().p("EAE9A+zIAAukIU2AAIAAOkg");
	var mask_6_graphics_241 = new cjs.Graphics().p("EACTA+zIAAukIXpAAIAAOkg");
	var mask_6_graphics_242 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_243 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_244 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_245 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_246 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_247 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_248 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_249 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_250 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_251 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_252 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_253 = new cjs.Graphics().p("EgCAA+zIAAukIacAAIAAOkg");
	var mask_6_graphics_254 = new cjs.Graphics().p("EADNA+zIAAukIVlAAIAAOkg");
	var mask_6_graphics_255 = new cjs.Graphics().p("EAIaA+zIAAukIQvAAIAAOkg");
	var mask_6_graphics_256 = new cjs.Graphics().p("EANoA+zIAAukIL3AAIAAOkg");
	var mask_6_graphics_257 = new cjs.Graphics().p("EAS1A+zIAAukIHBAAIAAOkg");
	var mask_6_graphics_258 = new cjs.Graphics().p("EAYCA+zIAAukICKAAIAAOkg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(233).to({graphics:mask_6_graphics_233,x:313,y:757.2}).wait(1).to({graphics:mask_6_graphics_234,x:159.3,y:401.9}).wait(1).to({graphics:mask_6_graphics_235,x:160.3,y:401.9}).wait(1).to({graphics:mask_6_graphics_236,x:161.2,y:401.9}).wait(1).to({graphics:mask_6_graphics_237,x:162.2,y:401.9}).wait(1).to({graphics:mask_6_graphics_238,x:163.2,y:401.9}).wait(1).to({graphics:mask_6_graphics_239,x:164.1,y:401.9}).wait(1).to({graphics:mask_6_graphics_240,x:165.1,y:401.9}).wait(1).to({graphics:mask_6_graphics_241,x:166,y:401.9}).wait(1).to({graphics:mask_6_graphics_242,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_243,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_244,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_245,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_246,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_247,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_248,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_249,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_250,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_251,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_252,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_253,x:156.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_254,x:158.6,y:401.9}).wait(1).to({graphics:mask_6_graphics_255,x:160.9,y:401.9}).wait(1).to({graphics:mask_6_graphics_256,x:163.1,y:401.9}).wait(1).to({graphics:mask_6_graphics_257,x:165.4,y:401.9}).wait(1).to({graphics:mask_6_graphics_258,x:167.6,y:401.9}).wait(63));

	// Layer_34
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("ACGCFQgFAAgEgDQibhkh0iDQgEgEgBgIQgBgIADgGQACgFAFAAQAEgBAFAFQCECJCQBdQAHAEABAGQACAHgEAHQgFAHgIAAIgCAAg");
	this.shape_99.setTransform(187.7,736.5,1.95,1.95);
	this.shape_99._off = true;

	var maskedShapeInstanceList = [this.shape_99];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_99).wait(242).to({_off:false},0).wait(79));

	// Layer_32
	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("ACNB9QhigvhvhDQhDgoiGhXQgEgDADgDQABgEAEACQCMBaA9AkQBvBEBhAvIB6g4QAEgCACAEQACAEgEACIh9A4IgCAAIgBAAIgBAAg");
	this.shape_100.setTransform(244.8,747.1,1.95,1.95);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAAAhQgJgGgHgPQgHgOAAgOQAAgOAHgEQAHgFAJAHQAKAGAHAPQAHAOAAAOQAAAOgHAFQgCABgEAAQgFAAgGgEg");
	this.shape_101.setTransform(192.5,723.6,1.95,1.95);

	var maskedShapeInstanceList = [this.shape_100,this.shape_101];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_101},{t:this.shape_100}]},233).wait(88));

	// Layer_30 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	var mask_7_graphics_218 = new cjs.Graphics().p("AhZI1IAAxpICzAAIAARpg");
	var mask_7_graphics_219 = new cjs.Graphics().p("EAT9A6nIAAxqIGMAAIAARqg");
	var mask_7_graphics_220 = new cjs.Graphics().p("EASRA6nIAAxqIJkAAIAARqg");
	var mask_7_graphics_221 = new cjs.Graphics().p("EAQmA6nIAAxqIM7AAIAARqg");
	var mask_7_graphics_222 = new cjs.Graphics().p("EAO6A6nIAAxqIQTAAIAARqg");
	var mask_7_graphics_223 = new cjs.Graphics().p("EANOA6nIAAxqITqAAIAARqg");
	var mask_7_graphics_224 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_225 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_226 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_227 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_228 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_229 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_230 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_231 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_232 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_233 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_234 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_235 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_236 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_237 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_238 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_239 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_240 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_241 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_242 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_243 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_244 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_245 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_246 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_247 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_248 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_249 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_250 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_251 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_252 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_253 = new cjs.Graphics().p("EALgA6nIAAxrIXCAAIAARrg");
	var mask_7_graphics_254 = new cjs.Graphics().p("EANoA6nIAAxrIS0AAIAARrg");
	var mask_7_graphics_255 = new cjs.Graphics().p("EAPwA6nIAAxrIOmAAIAARrg");
	var mask_7_graphics_256 = new cjs.Graphics().p("EAR4A6nIAAxrIKXAAIAARrg");
	var mask_7_graphics_257 = new cjs.Graphics().p("EAUAA6nIAAxrIGJAAIAARrg");
	var mask_7_graphics_258 = new cjs.Graphics().p("EAWIA6nIAAxrIB7AAIAARrg");

	this.timeline.addTween(cjs.Tween.get(mask_7).to({graphics:null,x:0,y:0}).wait(218).to({graphics:mask_7_graphics_218,x:304.1,y:693.7}).wait(1).to({graphics:mask_7_graphics_219,x:167.3,y:375.1}).wait(1).to({graphics:mask_7_graphics_220,x:178.1,y:375.1}).wait(1).to({graphics:mask_7_graphics_221,x:188.9,y:375.1}).wait(1).to({graphics:mask_7_graphics_222,x:199.7,y:375.1}).wait(1).to({graphics:mask_7_graphics_223,x:210.4,y:375.1}).wait(1).to({graphics:mask_7_graphics_224,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_225,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_226,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_227,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_228,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_229,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_230,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_231,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_232,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_233,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_234,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_235,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_236,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_237,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_238,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_239,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_240,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_241,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_242,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_243,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_244,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_245,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_246,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_247,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_248,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_249,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_250,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_251,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_252,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_253,x:221,y:375.1}).wait(1).to({graphics:mask_7_graphics_254,x:207.6,y:375.1}).wait(1).to({graphics:mask_7_graphics_255,x:194.2,y:375.1}).wait(1).to({graphics:mask_7_graphics_256,x:180.7,y:375.1}).wait(1).to({graphics:mask_7_graphics_257,x:167.3,y:375.1}).wait(1).to({graphics:mask_7_graphics_258,x:153.9,y:375.1}).wait(63));

	// Layer_31
	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AiyACQgHgBgEgGQgEgIABgHQABgIAGgDQAFgEAHACQChAlC/gJQAHgBAEAFQAEAEgBAIQgDAPgNAEIgCABQgyAEgwAAQiEAAh7ghg");
	this.shape_102.setTransform(397.8,703.4,1.95,1.95);
	this.shape_102._off = true;

	var maskedShapeInstanceList = [this.shape_102];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_102).wait(224).to({_off:false},0).wait(97));

	// Layer_29
	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#FFFFFF").ss(0.5,1,1).p("AjRCPQATg5AghWQAxiAAFgOQBiAUA6AJQBVANBJAB");
	this.shape_103.setTransform(357.4,708.7,1.95,1.95);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgGAgQgMgJgGgRQgGgPAEgOQADgNAKgDQAKgCALAJQALAKAGAQQAGAQgDANQgDAOgLACIgFABQgIAAgHgIg");
	this.shape_104.setTransform(401.9,688.7,1.95,1.95);

	var maskedShapeInstanceList = [this.shape_103,this.shape_104];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_104},{t:this.shape_103}]},218).wait(103));

	// marker
	this.instance_23 = new lib.Tween36("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(254.7,590.9);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(200).to({_off:false},0).wait(4).to({startPosition:0},0).to({x:199.9,y:556.5},7).to({x:283.3,y:683.8},5).to({x:316.6,y:734.7},2).to({startPosition:0},6).to({startPosition:0},4).to({x:304.3,y:757.5},5).to({startPosition:0},25).to({_off:true},1).wait(62));

	// hand
	this.instance_24 = new lib.Tween35("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(383.9,346.4,1,1,0,0,0,6,31.2);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(200).to({_off:false},0).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({rotation:-21},7).to({regY:31.4,rotation:-8,x:384,y:346.6},2).to({regY:31.3,rotation:24,x:383.9,y:346.5},5).to({startPosition:0},6).to({startPosition:0},4).to({regX:6.1,regY:31.4,rotation:9,x:384,y:346.6},5).to({startPosition:0},1).to({_off:true},1).wait(2).to({_off:false,regX:6,rotation:-44.5,x:393.5,y:381.6},0).wait(1).to({regY:31.6,rotation:-74.5,x:393.3,y:380.3},0).wait(1).to({regX:5.9,rotation:-114.7,x:393,y:379.8},0).to({_off:true},1).wait(81));

	// char hand 1
	this.instance_25 = new lib.ClipGroup_22();
	this.instance_25.parent = this;
	this.instance_25.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_26 = new lib.ClipGroup_1_12();
	this.instance_26.parent = this;
	this.instance_26.setTransform(416.7,423.6,3.598,3.598,0,0,0,6.5,9.5);

	this.instance_27 = new lib.ClipGroup_2_5();
	this.instance_27.parent = this;
	this.instance_27.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_28 = new lib.ClipGroup_3_8();
	this.instance_28.parent = this;
	this.instance_28.setTransform(460.6,399.2,3.598,3.598,0,0,0,10.1,16.7);

	this.instance_29 = new lib.ClipGroup_4_5();
	this.instance_29.parent = this;
	this.instance_29.setTransform(428.3,373.8,3.598,3.598,0,0,0,13.3,13.3);

	this.instance_30 = new lib.ClipGroup_5_4();
	this.instance_30.parent = this;
	this.instance_30.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFC0BF").s().p("AgKgjIAcAIIAAA5IgjAGg");
	this.shape_105.setTransform(433.7,598.1,3.598,3.598);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#142849").s().p("AgeA9QgugHgIgzIACgxIA8gRQAEgCAgACIAgACIASAIQATANABAeQABAZgcAXQgYAVgdAFIgGABQgKAAgSgEg");
	this.shape_106.setTransform(461.5,446.2,3.598,3.598);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#142849").s().p("AgGCCQgQgFgFgVQgIghgFhlIgEhfQA6gHAVACQAKAAgCACQAEAkgFC/QgBANgGAIQgJANgTgCIgFABQgDAAgFgCg");
	this.shape_107.setTransform(476.2,486.4,3.598,3.598);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#142849").s().p("AgEB2QgYiJgHg+QgBgTANgLQAIgGALAAIASADQATAHABASIACDPg");
	this.shape_108.setTransform(479,553.6,3.598,3.598);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#142849").s().p("AgNB+QgMAAgKgJQgNgLABgUIAOiwQACgaAZgHQAYgIAQAVQANARABAbQAAANgCAKQgDANgUB8QgCAOgKAJQgKAJgLAAIgDAAg");
	this.shape_109.setTransform(442.7,480.4,3.598,3.598);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#142849").s().p("AggB7IgCjdQAEgSASgIQAJgDAHAAQAWAGAHATQADAJgCAIQgSBxgIBkg");
	this.shape_110.setTransform(438,550.7,3.598,3.598);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFC0BF").s().p("AgIAeQgKgEgEgPQAAgFACgGQAFgQAOgOIAYAJIAAAcQABAEgDADQgEAEgEgHIgCgMIgDAMQgDAOgDAFQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgHgBg");
	this.shape_111.setTransform(404,458.9,3.598,3.598);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFF9F5").s().p("AgpAvQgCgCABgGQADgKAIgLIANgSQAJgNAEgGQAFgMgBgLQAQACAOgEQAIgBACgDQACACAAAEIACAqQgWAXgMAJQgUAQgVACQgIAAgBgDg");
	this.shape_112.setTransform(479.2,621,3.598,3.598);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFC0BF").s().p("AgSgkIAdAFIAIA4IghAMg");
	this.shape_113.setTransform(485.9,599.4,3.598,3.598);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFF9F5").s().p("AguAoQgCgDADgFQAEgJAJgKIAQgQQAVgXAAgQQAQADAPgBQAIgBADgCQABACgBAEIgDAqQgXATgPAIQgWAMgVAAQgIgBgBgDg");
	this.shape_114.setTransform(424.6,619.6,3.598,3.598);

	this.instance_31 = new lib.Tween35("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(393,379.8,1,1,-114.7,0,0,5.9,31.6);

	this.instance_32 = new lib.Tween41("synched",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(456.7,466.9);
	this.instance_32._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_105},{t:this.instance_30},{t:this.instance_29,p:{rotation:0,x:428.3,y:373.8,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:0,x:416.7,y:423.6,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},190).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111,p:{rotation:0,x:404,y:458.9,skewX:0,skewY:0,scaleX:3.598,scaleY:3.598}},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:0,x:428.3,y:373.8,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:0,x:416.7,y:423.6,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},5).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111,p:{rotation:30,x:377.6,y:441.9,skewX:0,skewY:0,scaleX:3.598,scaleY:3.598}},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:0,x:428.3,y:373.8,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:30,x:406.2,y:417.8,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111,p:{rotation:70.5,x:361.3,y:403.2,skewX:0,skewY:0,scaleX:3.598,scaleY:3.598}},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:0,x:428.3,y:373.8,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:70.5,x:398.8,y:403.4,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111,p:{rotation:109.2,x:342.8,y:347.2,skewX:0,skewY:0,scaleX:3.598,scaleY:3.598}},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:38.7,x:413.5,y:366.1,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:109.2,x:372,y:370.8,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111,p:{rotation:0,x:373.8,y:285.9,skewX:-154.2,skewY:25.8,scaleX:3.598,scaleY:3.598}},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:83.7,x:409.6,y:349.3,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26,p:{rotation:154.2,x:376.9,y:323.2,scaleX:3.598,scaleY:3.598}},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:83.7,x:409.6,y:349.3,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:83.7,x:409.6,y:349.3,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},34).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_111,p:{rotation:0,x:373.8,y:285.9,skewX:-154.2,skewY:25.8,scaleX:3.598,scaleY:3.598}},{t:this.instance_29,p:{rotation:83.7,x:409.6,y:349.3,regY:13.3}},{t:this.instance_26,p:{rotation:154.2,x:376.9,y:323.2,scaleX:3.598,scaleY:3.598}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_111,p:{rotation:0,x:353.3,y:313.2,skewX:-176,skewY:4,scaleX:3.598,scaleY:3.598}},{t:this.instance_29,p:{rotation:62,x:410,y:358.8,regY:13.3}},{t:this.instance_26,p:{rotation:132.5,x:370,y:346.8,scaleX:3.598,scaleY:3.598}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:40.3,x:413.8,y:366.5,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:40.3,x:413.8,y:366.5,regY:13.3}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25},{t:this.instance_31,p:{regX:5.9,rotation:-114.7,x:393,y:379.8}}]},3).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:18.4,x:420,y:372.5,regY:13.4}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25},{t:this.instance_31,p:{regX:5.8,rotation:-136.6,x:405.9,y:392.4}}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:3.4,x:425.5,y:375,regY:13.4}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25},{t:this.instance_31,p:{regX:5.8,rotation:-151.6,x:417,y:397.7}}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:-6.6,x:429.4,y:375.7,regY:13.4}},{t:this.shape_111,p:{rotation:-14.1,x:416.5,y:460.5,skewX:0,skewY:0,scaleX:3.597,scaleY:3.597}},{t:this.instance_26,p:{rotation:-7.4,x:424,y:424.1,scaleX:3.597,scaleY:3.597}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.shape_105},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.instance_29,p:{rotation:-6.6,x:429.4,y:375.7,regY:13.4}},{t:this.shape_111,p:{rotation:-14.1,x:416.5,y:460.5,skewX:0,skewY:0,scaleX:3.597,scaleY:3.597}},{t:this.instance_26,p:{rotation:-7.4,x:424,y:424.1,scaleX:3.597,scaleY:3.597}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_25}]},1).to({state:[{t:this.instance_32}]},66).to({state:[{t:this.instance_32}]},10).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(310).to({_off:false},0).to({y:384.4,alpha:0},10).wait(1));

	// char
	this.instance_33 = new lib.ClipGroup_22();
	this.instance_33.parent = this;
	this.instance_33.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_34 = new lib.ClipGroup_1_12();
	this.instance_34.parent = this;
	this.instance_34.setTransform(416.7,423.6,3.598,3.598,0,0,0,6.5,9.5);

	this.instance_35 = new lib.ClipGroup_2_5();
	this.instance_35.parent = this;
	this.instance_35.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.instance_36 = new lib.ClipGroup_3_8();
	this.instance_36.parent = this;
	this.instance_36.setTransform(460.6,399.2,3.598,3.598,0,0,0,10.1,16.7);

	this.instance_37 = new lib.ClipGroup_4_5();
	this.instance_37.parent = this;
	this.instance_37.setTransform(428.3,373.8,3.598,3.598,0,0,0,13.3,13.3);

	this.instance_38 = new lib.ClipGroup_5_4();
	this.instance_38.parent = this;
	this.instance_38.setTransform(452.1,467,3.598,3.598,0,0,0,15.7,47.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFC0BF").s().p("AgKgjIAcAIIAAA5IgjAGg");
	this.shape_115.setTransform(433.7,598.1,3.598,3.598);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_115},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33}]},66).to({state:[]},124).wait(131));

	// dotted circle
	this.instance_39 = new lib.Symbol5();
	this.instance_39.parent = this;
	this.instance_39.setTransform(503.5,409.2,0.91,0.807,0,0,27.5,0,0.1);
	this.instance_39.alpha = 0;
	this.instance_39._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(13).to({_off:false},0).to({alpha:1},12).wait(54).to({alpha:0},5).to({_off:true},1).wait(236));

	// Right glow
	this.instance_40 = new lib.ClipGroup_25();
	this.instance_40.parent = this;
	this.instance_40.setTransform(501.6,622.2,4.338,4.334,0,0,2.6,0,93.2);
	this.instance_40.alpha = 0;
	this.instance_40._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_40).wait(25).to({_off:false},0).to({alpha:1},8).wait(46).to({alpha:0},5).to({_off:true},1).wait(236));

	// Layer_8 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	var mask_8_graphics_158 = new cjs.Graphics().p("A12DWIAAmrMArtAAAIAAGrg");
	var mask_8_graphics_159 = new cjs.Graphics().p("EACiA5hIAAyYMArvAAAIAASYg");
	var mask_8_graphics_160 = new cjs.Graphics().p("EACiA5nIAA+FMArvAAAIAAeFg");
	var mask_8_graphics_161 = new cjs.Graphics().p("EACiA5tMAAAgpyMArvAAAMAAAApyg");
	var mask_8_graphics_162 = new cjs.Graphics().p("EACiA5zMAAAg1fMArvAAAMAAAA1fg");
	var mask_8_graphics_163 = new cjs.Graphics().p("EACiA55MAAAhBLMArvAAAMAAABBLg");
	var mask_8_graphics_164 = new cjs.Graphics().p("EACiA5/MAAAhM4MArvAAAMAAABM4g");
	var mask_8_graphics_165 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_166 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_167 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_168 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_169 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_170 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_171 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_172 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_173 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_174 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_175 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_176 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_177 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_178 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_179 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_180 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_181 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_182 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_183 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_184 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_185 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_186 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_187 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_188 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_189 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_190 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_191 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_192 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_193 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_194 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_195 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_196 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_197 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_198 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_199 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_200 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_201 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_202 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_203 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_204 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_205 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_206 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_207 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_208 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_209 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_210 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_211 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_212 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_213 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_214 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_215 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_216 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_217 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_218 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_219 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_220 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_221 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_222 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_223 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_224 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_225 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_226 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_227 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_228 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_229 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_230 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_231 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_232 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_233 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_234 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_235 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_236 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_237 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_238 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_239 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_240 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_241 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_242 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_243 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_244 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_245 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_246 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_247 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_248 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_249 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_250 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_251 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_252 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_253 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_254 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_255 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_256 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_257 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_258 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_259 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_260 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_261 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_262 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_263 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_264 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_265 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_266 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_267 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_268 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_269 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_270 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_271 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_272 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_273 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_274 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_275 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_276 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_277 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_278 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_279 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_280 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_281 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_282 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_283 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_284 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_285 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_286 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_287 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_288 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_289 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_290 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_291 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_292 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_293 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_294 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_295 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_296 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_297 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_298 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_299 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_300 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_301 = new cjs.Graphics().p("EACiA5bMAAAhYnMArvAAAMAAABYng");
	var mask_8_graphics_302 = new cjs.Graphics().p("EACiA5gMAAAhPIMArvAAAMAAABPIg");
	var mask_8_graphics_303 = new cjs.Graphics().p("EACiA5mMAAAhFqMArvAAAMAAABFqg");
	var mask_8_graphics_304 = new cjs.Graphics().p("EACiA5rMAAAg8LMArvAAAMAAAA8Lg");
	var mask_8_graphics_305 = new cjs.Graphics().p("EACiA5xMAAAgyuMArvAAAMAAAAyug");
	var mask_8_graphics_306 = new cjs.Graphics().p("EACiA53MAAAgpRMArvAAAMAAAApRg");
	var mask_8_graphics_307 = new cjs.Graphics().p("EACiA58IAA/yMArvAAAIAAfyg");
	var mask_8_graphics_308 = new cjs.Graphics().p("EACiA6CIAA2UMArvAAAIAAWUg");
	var mask_8_graphics_309 = new cjs.Graphics().p("EACiA6HIAAs1MArvAAAIAAM1g");
	var mask_8_graphics_310 = new cjs.Graphics().p("EACiA6NIAAjYMArvAAAIAADYg");

	this.timeline.addTween(cjs.Tween.get(mask_8).to({graphics:null,x:0,y:0}).wait(158).to({graphics:mask_8_graphics_158,x:452.2,y:713.6}).wait(1).to({graphics:mask_8_graphics_159,x:296.1,y:368.1}).wait(1).to({graphics:mask_8_graphics_160,x:296.1,y:368.7}).wait(1).to({graphics:mask_8_graphics_161,x:296.1,y:369.3}).wait(1).to({graphics:mask_8_graphics_162,x:296.1,y:369.9}).wait(1).to({graphics:mask_8_graphics_163,x:296.1,y:370.5}).wait(1).to({graphics:mask_8_graphics_164,x:296.1,y:371.1}).wait(1).to({graphics:mask_8_graphics_165,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_166,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_167,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_168,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_169,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_170,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_171,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_172,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_173,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_174,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_175,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_176,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_177,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_178,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_179,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_180,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_181,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_182,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_183,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_184,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_185,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_186,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_187,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_188,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_189,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_190,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_191,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_192,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_193,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_194,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_195,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_196,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_197,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_198,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_199,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_200,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_201,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_202,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_203,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_204,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_205,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_206,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_207,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_208,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_209,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_210,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_211,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_212,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_213,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_214,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_215,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_216,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_217,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_218,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_219,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_220,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_221,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_222,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_223,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_224,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_225,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_226,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_227,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_228,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_229,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_230,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_231,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_232,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_233,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_234,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_235,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_236,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_237,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_238,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_239,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_240,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_241,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_242,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_243,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_244,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_245,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_246,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_247,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_248,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_249,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_250,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_251,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_252,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_253,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_254,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_255,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_256,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_257,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_258,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_259,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_260,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_261,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_262,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_263,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_264,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_265,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_266,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_267,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_268,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_269,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_270,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_271,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_272,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_273,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_274,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_275,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_276,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_277,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_278,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_279,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_280,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_281,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_282,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_283,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_284,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_285,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_286,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_287,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_288,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_289,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_290,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_291,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_292,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_293,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_294,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_295,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_296,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_297,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_298,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_299,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_300,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_301,x:296.1,y:367.5}).wait(1).to({graphics:mask_8_graphics_302,x:296.1,y:368}).wait(1).to({graphics:mask_8_graphics_303,x:296.1,y:368.6}).wait(1).to({graphics:mask_8_graphics_304,x:296.1,y:369.1}).wait(1).to({graphics:mask_8_graphics_305,x:296.1,y:369.7}).wait(1).to({graphics:mask_8_graphics_306,x:296.1,y:370.3}).wait(1).to({graphics:mask_8_graphics_307,x:296.1,y:370.8}).wait(1).to({graphics:mask_8_graphics_308,x:296.1,y:371.4}).wait(1).to({graphics:mask_8_graphics_309,x:296.1,y:371.9}).wait(1).to({graphics:mask_8_graphics_310,x:296.1,y:372.5}).wait(11));

	// char gradient
	this.instance_41 = new lib.glow();
	this.instance_41.parent = this;
	this.instance_41.setTransform(451.1,424.4);
	this.instance_41.alpha = 0.781;
	this.instance_41.compositeOperation = "lighter";
	this.instance_41._off = true;

	var maskedShapeInstanceList = [this.instance_41];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(158).to({_off:false},0).wait(163));

	// char static
	this.instance_42 = new lib.Tween23("synched",0);
	this.instance_42.parent = this;
	this.instance_42.setTransform(680.1,169.9);
	this.instance_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(21).to({_off:false},0).to({y:304.3},6).to({_off:true},7).wait(287));

	// char - 1
	this.instance_43 = new lib.walk();
	this.instance_43.parent = this;
	this.instance_43.setTransform(674.6,293.7,1,1,0,0,0,-7.5,0);
	this.instance_43._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(33).to({_off:false},0).to({x:457,y:444.3},31).to({_off:true},1).wait(256));

	// Left glow
	this.instance_44 = new lib.ClipGroup_26();
	this.instance_44.parent = this;
	this.instance_44.setTransform(406.7,395,4.34,4.336,0,0,2.6,22.2,46.2);
	this.instance_44.alpha = 0;
	this.instance_44._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(25).to({_off:false},0).to({alpha:1},8).wait(46).to({alpha:0},5).to({_off:true},1).wait(236));

	// char stand
	this.instance_45 = new lib.ClipGroup_28();
	this.instance_45.parent = this;
	this.instance_45.setTransform(450.6,633.3,4.246,4.246,0,0,0,28.7,10.5);
	this.instance_45.alpha = 0;
	this.instance_45._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_45).wait(66).to({_off:false},0).to({alpha:1},3).wait(241).to({y:682.8,alpha:0},10).wait(1));

	// wall frame
	this.instance_46 = new lib.Tween21("synched",0);
	this.instance_46.parent = this;
	this.instance_46.setTransform(359.4,196.4);
	this.instance_46.alpha = 0;
	this.instance_46._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(5).to({_off:false},0).to({y:100.4,alpha:1},13,cjs.Ease.cubicIn).to({startPosition:0},56).to({y:180.4,alpha:0},8).to({_off:true},2).wait(237));

	// plant
	this.instance_47 = new lib.ClipGroup_23();
	this.instance_47.parent = this;
	this.instance_47.setTransform(821.5,310.6,2.886,2.886,0,0,0,14.4,16.8);
	this.instance_47.alpha = 0;
	this.instance_47._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(12).to({_off:false},0).to({x:858.3,y:280.2,alpha:1},13,cjs.Ease.cubicIn).wait(44).to({x:811.9,y:309,alpha:0},10).to({_off:true},5).wait(237));

	// sofa
	this.instance_48 = new lib.Tween22("synched",0);
	this.instance_48.parent = this;
	this.instance_48.setTransform(708.8,100.5);
	this.instance_48.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_48).to({y:164.5,alpha:1},13,cjs.Ease.cubicIn).to({startPosition:0},52).to({y:84.5,alpha:0},10).to({_off:true},9).wait(237));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(987,395.9,343.6,309.4);
// library properties:
lib.properties = {
	id: 'AD811C5866F34123B9CC5B51EAE37341',
	width: 900,
	height: 900,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AD811C5866F34123B9CC5B51EAE37341'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;