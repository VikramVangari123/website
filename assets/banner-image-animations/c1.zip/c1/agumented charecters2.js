(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"agumented charecters2_atlas_", frames: [[1763,541,185,44],[1966,558,42,57],[2013,382,33,46],[1956,688,15,16],[2022,642,23,24],[2047,610,1,1],[2047,598,1,4],[2047,604,1,4],[2039,598,5,9],[1931,439,31,9],[1931,298,82,82],[2044,75,4,4],[2044,476,4,13],[2028,136,17,30],[1912,654,108,32],[1506,706,216,392],[1772,380,60,17],[2039,619,6,6],[2023,180,3,3],[1717,0,201,110],[1711,657,199,43],[1717,112,201,47],[1763,451,199,43],[1655,403,201,46],[1763,496,199,43],[1508,657,201,46],[1763,622,199,30],[1763,587,201,33],[1508,178,370,89],[1609,635,21,19],[2026,69,16,35],[1867,285,7,10],[1717,161,19,14],[2026,106,19,28],[1508,0,207,176],[1772,269,93,109],[1880,187,107,109],[2026,0,22,29],[1996,149,30,29],[2010,552,38,44],[2010,598,27,42],[2026,31,17,36],[2015,268,26,42],[1989,187,51,79],[1950,541,11,14],[1950,558,13,17],[2008,642,12,7],[1867,298,62,145],[1996,0,28,147],[1508,635,40,19],[2015,312,28,25],[1550,635,35,19],[1964,622,42,22],[1652,453,109,202],[1508,453,142,180],[1508,269,145,182],[2015,339,17,39],[1912,688,42,41],[2010,496,38,54],[1989,268,22,26],[1880,161,37,20],[1920,0,74,185],[1950,577,14,8],[0,706,1504,696],[0,0,1506,704],[1834,380,20,20],[2018,476,24,17],[1856,380,9,13],[2028,168,16,17],[2017,180,4,4],[1964,496,44,60],[2039,609,5,8],[2039,627,7,4],[2044,69,4,4],[2003,180,5,5],[1856,395,6,6],[2039,633,5,5],[2044,491,2,2],[1867,269,10,14],[1996,180,5,5],[1931,382,80,55],[1655,269,115,132],[2018,430,30,44],[1964,439,52,55],[1779,161,13,14],[2022,668,18,26],[1738,161,22,12],[2034,339,12,12],[1632,635,18,18],[1587,635,20,20],[1762,161,15,15],[2010,180,5,5]]}
];


// symbols:



(lib.CachedTexturedBitmap_1 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_10 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_100 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_101 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_102 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_103 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_104 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_105 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_106 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_107 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_108 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_109 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_111 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_112 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_113 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_127 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_128 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_129 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_130 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_131 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_132 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_133 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_134 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_135 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_136 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_137 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_138 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_139 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_2 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_29 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_30 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_31 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_32 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_33 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_34 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_35 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_36 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_37 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_38 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_39 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_4 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_40 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_41 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_42 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_43 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_44 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_45 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_46 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_5 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_59 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_6 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_60 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_61 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_62 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_63 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_64 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_65 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_66 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_67 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_69 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_7 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_70 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_71 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_72 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_75 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_76 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_77 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_78 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_79 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_8 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_80 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_81 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_82 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_83 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_84 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_85 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_86 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_87 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_88 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_89 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_9 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_90 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_91 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_92 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_93 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_94 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_95 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_96 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_97 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_98 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_99 = function() {
	this.initialize(ss["agumented charecters2_atlas_"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_139();
	this.instance.parent = this;
	this.instance.setTransform(-50.25,-41.45,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_138();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-49.75,-40.65,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_137();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-50.2,-52.6,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_136();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-49.7,-51.8,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_135();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-50.2,-62.25,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_134();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-49.7,-61.45,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_133();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-50.25,-71.45,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_132();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-49.75,-70,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_131();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-50.2,-79.55,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_130();
	this.instance_9.parent = this;
	this.instance_9.setTransform(9.95,-99.9,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_129();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-12.4,-100.6,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_128();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-15,-103.25,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_127();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-54,-93.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-103.2,108,206);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_139();
	this.instance.parent = this;
	this.instance.setTransform(-50.25,-41.45,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_138();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-49.75,-40.65,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_137();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-50.2,-52.6,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_136();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-49.7,-51.8,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_135();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-50.2,-62.25,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_134();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-49.7,-61.45,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_133();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-50.25,-71.45,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_132();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-49.75,-70,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_131();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-50.2,-79.55,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_130();
	this.instance_9.parent = this;
	this.instance_9.setTransform(9.95,-99.9,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_129();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-12.4,-100.6,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_128();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-15,-103.25,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_127();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-54,-93.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-103.2,108,206);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_113();
	this.instance.parent = this;
	this.instance.setTransform(-21.65,14.65,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_112();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-32.45,16.8,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_111();
	this.instance_2.parent = this;
	this.instance_2.setTransform(10.85,11.4,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_111();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.25,9.2,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_109();
	this.instance_4.parent = this;
	this.instance_4.setTransform(16.25,4.9,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_108();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-20.55,-31.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.4,-31.9,64.8,63.7);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_107();
	this.instance.parent = this;
	this.instance.setTransform(-21.6,14.65,1.7496,1.7496);

	this.instance_1 = new lib.CachedTexturedBitmap_106();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-32.35,16.85,1.7496,1.7496);

	this.instance_2 = new lib.CachedTexturedBitmap_105();
	this.instance_2.parent = this;
	this.instance_2.setTransform(10.9,11.45,1.7496,1.7496);

	this.instance_3 = new lib.CachedTexturedBitmap_104();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.25,9.25,1.7496,1.7496);

	this.instance_4 = new lib.CachedTexturedBitmap_103();
	this.instance_4.parent = this;
	this.instance_4.setTransform(16.25,4.95,1.7496,1.7496);

	this.instance_5 = new lib.CachedTexturedBitmap_102();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-20.45,-31.8,1.7496,1.7496);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.3,-31.8,65,64.4);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_101();
	this.instance.parent = this;
	this.instance.setTransform(3.55,7.95,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_100();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-36,-22.2,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_99();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-32.75,-5.6,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_98();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-2.25,14.65,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_97();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-8.05,9.05,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_96();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-13.65,6.3,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_95();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-18.55,5,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_94();
	this.instance_7.parent = this;
	this.instance_7.setTransform(12.95,8.1,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_93();
	this.instance_8.parent = this;
	this.instance_8.setTransform(8.15,3.9,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_92();
	this.instance_9.parent = this;
	this.instance_9.setTransform(5.2,14.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_91();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-26.25,-20.95,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_90();
	this.instance_11.parent = this;
	this.instance_11.setTransform(20.85,-21.7,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_89();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-12.1,-20.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-22.2,71.9,44.4);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_88();
	this.instance.parent = this;
	this.instance.setTransform(3.6,7.95,1.6463,1.6463);

	this.instance_1 = new lib.CachedTexturedBitmap_87();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-35.95,-22.1,1.6463,1.6463);

	this.instance_2 = new lib.CachedTexturedBitmap_86();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-32.65,-5.5,1.6463,1.6463);

	this.instance_3 = new lib.CachedTexturedBitmap_85();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-2.2,14.7,1.6463,1.6463);

	this.instance_4 = new lib.CachedTexturedBitmap_84();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-7.95,9.1,1.6463,1.6463);

	this.instance_5 = new lib.CachedTexturedBitmap_83();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-13.55,6.3,1.6463,1.6463);

	this.instance_6 = new lib.CachedTexturedBitmap_82();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-18.5,5,1.6463,1.6463);

	this.instance_7 = new lib.CachedTexturedBitmap_81();
	this.instance_7.parent = this;
	this.instance_7.setTransform(13,8.1,1.6463,1.6463);

	this.instance_8 = new lib.CachedTexturedBitmap_80();
	this.instance_8.parent = this;
	this.instance_8.setTransform(8.2,3.95,1.6463,1.6463);

	this.instance_9 = new lib.CachedTexturedBitmap_79();
	this.instance_9.parent = this;
	this.instance_9.setTransform(5.25,14.2,1.6463,1.6463);

	this.instance_10 = new lib.CachedTexturedBitmap_78();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-26.15,-20.9,1.6463,1.6463);

	this.instance_11 = new lib.CachedTexturedBitmap_77();
	this.instance_11.parent = this;
	this.instance_11.setTransform(20.9,-21.6,1.6463,1.6463);

	this.instance_12 = new lib.CachedTexturedBitmap_76();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-12,-20,1.6463,1.6463);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.9,-22.1,71.6,45.1);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_75();
	this.instance.parent = this;
	this.instance.setTransform(368.2,-177.4,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-3.4,-104.45,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_75();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-241.6,-32.9,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_72();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-379.2,-173.55,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_71();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-376.05,-172.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-379.2,-177.4,757.4,355.9);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_70();
	this.instance.parent = this;
	this.instance.setTransform(-13.1,-73.9,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_69();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-5.5,-76.85,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_69();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-9.05,-76.85,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_67();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-31.55,2.05,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_66();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-13,-73.7,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_65();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-14.35,-86.75,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_64();
	this.instance_6.parent = this;
	this.instance_6.setTransform(32.65,-102.1,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_63();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-33.35,-84.85,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_62();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-32.6,-84.3,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_61();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-36.55,-8.6,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_60();
	this.instance_10.parent = this;
	this.instance_10.setTransform(7.45,89.3,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_59();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-41.05,89.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-102.1,82.2,203.89999999999998);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_70();
	this.instance.parent = this;
	this.instance.setTransform(-13.1,-73.9,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_69();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-5.5,-76.85,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_69();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-9.05,-76.85,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_67();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-31.55,2.05,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_66();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-13,-73.7,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_65();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-14.35,-86.75,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_64();
	this.instance_6.parent = this;
	this.instance_6.setTransform(32.65,-102.1,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_63();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-33.35,-84.85,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_62();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-32.6,-84.3,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_61();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-36.55,-8.6,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_60();
	this.instance_10.parent = this;
	this.instance_10.setTransform(7.45,89.3,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_59();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-41.05,89.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-102.1,82.2,203.89999999999998);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_46();
	this.instance.parent = this;
	this.instance.setTransform(1.4,17.05,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_45();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-35.9,18.45,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_44();
	this.instance_2.parent = this;
	this.instance_2.setTransform(47.4,-72.2,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_43();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50.3,-74.4,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_42();
	this.instance_4.parent = this;
	this.instance_4.setTransform(50.8,-73.55,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_41();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-15.5,-94.4,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_40();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-0.65,77.25,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_39();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-38.25,77.25,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_38();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-15.2,-90.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_37();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-10.65,-66.8,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_36();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-9.35,-73.05,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_35();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-4.55,-68.9,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_34();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-54.65,-66.35,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_33();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-54.65,-68.9,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_32();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-55.75,-76.1,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_31();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-56.9,-81.15,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_30();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-56.45,-75.05,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_29();
	this.instance_17.parent = this;
	this.instance_17.setTransform(46.65,-74,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.9,-94.4,114.1,192.7);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_46();
	this.instance.parent = this;
	this.instance.setTransform(1.4,17.05,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_45();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-35.9,18.45,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_44();
	this.instance_2.parent = this;
	this.instance_2.setTransform(47.4,-72.2,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_43();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50.3,-74.4,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_42();
	this.instance_4.parent = this;
	this.instance_4.setTransform(50.8,-73.55,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_41();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-15.5,-94.4,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_40();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-0.65,77.25,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_39();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-38.25,77.25,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_38();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-15.2,-90.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_37();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-10.65,-66.8,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_36();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-9.35,-73.05,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_35();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-4.55,-68.9,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_34();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-54.65,-66.35,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_33();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-54.65,-68.9,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_32();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-55.75,-76.1,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_31();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-56.9,-81.15,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_30();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-56.45,-75.05,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_29();
	this.instance_17.parent = this;
	this.instance_17.setTransform(46.65,-74,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.9,-94.4,114.1,192.7);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_10();
	this.instance.parent = this;
	this.instance.setTransform(-11.9,-99.35,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28.75,-65.3,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-11.65,-94.75,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-18.8,-2.95,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_6();
	this.instance_4.parent = this;
	this.instance_4.setTransform(3.75,88.55,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-24.5,88.55,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-27.65,-1.1,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(20.4,-3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.7,-99.3,57.5,197.39999999999998);


(lib.Ellipse109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ellipse109, new cjs.Rectangle(0,0,92.5,22.3), null);


(lib.Ellipse102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ellipse102, new cjs.Rectangle(0,0,92.5,22), null);


// stage content:
(lib.agumentedcharecters2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// icon_1
	this.instance = new lib.Tween15("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(344.05,144.05,0.3037,0.3037);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(352.5,138.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,x:352.5,y:138.2,alpha:1},4).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({_off:false},4).to({scaleX:0.3955,scaleY:0.3955},4).to({scaleX:0.9666,scaleY:0.9666},4).wait(39));

	// icon_2
	this.instance_2 = new lib.Tween17("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(584.05,40.3,0.2858,0.2858,0,0,0,0.1,0);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween18("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(601.85,52.75);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(103).to({_off:false},0).to({_off:true,regX:0,scaleX:1,scaleY:1,x:601.85,y:52.75,alpha:1},5).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(103).to({_off:false},5).to({scaleX:0.4655,scaleY:0.4655},5).to({regX:0.1,scaleX:0.9897,scaleY:0.9897,x:601.95},5).wait(22));

	// circle_3
	this.instance_4 = new lib.Ellipse109();
	this.instance_4.parent = this;
	this.instance_4.setTransform(620.55,383.2,1,1,0,0,0,46.3,11.1);
	this.instance_4.alpha = 0.1484;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(42).to({_off:false},0).wait(98));

	// player3
	this.instance_5 = new lib.Tween7("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(628.1,128.6);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween8("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(628.1,283.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},32).to({state:[{t:this.instance_6}]},12).wait(96));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(32).to({_off:false},0).to({_off:true,y:283.6,alpha:1},12,cjs.Ease.quartIn).wait(96));

	// circle_2
	this.instance_7 = new lib.Ellipse102();
	this.instance_7.parent = this;
	this.instance_7.setTransform(356.2,379.4,1,1,0,0,0,46.3,11);
	this.instance_7.alpha = 0.1484;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({_off:false},0).wait(111));

	// player_2
	this.instance_8 = new lib.Tween5("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(368.4,129.65);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween6("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(368.4,284.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},22).to({state:[{t:this.instance_9}]},10).wait(108));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(22).to({_off:false},0).to({_off:true,y:284.65,alpha:1},10,cjs.Ease.quartIn).wait(108));

	// player_1
	this.instance_10 = new lib.Tween4("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(121.75,136.8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(11).to({_off:false},0).to({y:278.85,alpha:1},11,cjs.Ease.quartIn).wait(118));

	// circle_1
	this.instance_11 = new lib.Ellipse102();
	this.instance_11.parent = this;
	this.instance_11.setTransform(121.8,374.7,1,1,0,0,0,46.3,11);
	this.instance_11.alpha = 0.1484;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(21).to({_off:false},0).wait(119));

	// kiosk
	this.instance_12 = new lib.Tween19("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(83.6,108.45);
	this.instance_12.alpha = 0;

	this.instance_13 = new lib.Tween20("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(83.6,261.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},11).wait(129));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,y:261.45,alpha:1},11).wait(129));

	// loop_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_55 = new cjs.Graphics().p("AxwbcMAAAg23MAjhAAAMAAAA23g");
	var mask_graphics_56 = new cjs.Graphics().p("AwyeWMAAAg23MAjhAAAMAAAA23g");
	var mask_graphics_57 = new cjs.Graphics().p("AuPeWMAAAg23MAjhAAAMAAAA23g");
	var mask_graphics_58 = new cjs.Graphics().p("AyXbcMAAAg23MAkvAAAMAAAA23g");
	var mask_graphics_59 = new cjs.Graphics().p("ArGeWMAAAg23MAjhAAAMAAAA23g");
	var mask_graphics_60 = new cjs.Graphics().p("AsleWMAAAg23MApDAAAMAAAA23g");
	var mask_graphics_61 = new cjs.Graphics().p("ApveWMAAAg23MAnXAAAMAAAA23g");
	var mask_graphics_62 = new cjs.Graphics().p("At9eWMAAAg23MAsMAAAMAAAA23g");
	var mask_graphics_63 = new cjs.Graphics().p("AuieWMAAAg23MAvTAAAMAAAA23g");
	var mask_graphics_64 = new cjs.Graphics().p("AwOeWMAAAg23MAxuAAAMAAAA23g");
	var mask_graphics_65 = new cjs.Graphics().p("Av3eWMAAAg23MAyNAAAMAAAA23g");
	var mask_graphics_66 = new cjs.Graphics().p("AxieWMAAAg23MA1FAAAMAAAA23g");
	var mask_graphics_67 = new cjs.Graphics().p("AzWeWMAAAg23MA4GAAAMAAAA23g");
	var mask_graphics_68 = new cjs.Graphics().p("A6peWMAAAg23MBBVAAAMAAAA23g");
	var mask_graphics_69 = new cjs.Graphics().p("A5feWMAAAg23MBBwAAAMAAAA23g");
	var mask_graphics_70 = new cjs.Graphics().p("EgmoAbcMAAAg23MBNRAAAMAAAA23g");
	var mask_graphics_71 = new cjs.Graphics().p("A+oeWMAAAg23MBJ6AAAMAAAA23g");
	var mask_graphics_72 = new cjs.Graphics().p("Egg6AeWMAAAg23MBNRAAAMAAAA23g");
	var mask_graphics_73 = new cjs.Graphics().p("EgogAeWMAAAg23MBWTAAAMAAAA23g");
	var mask_graphics_74 = new cjs.Graphics().p("A90eWMAAAg23MBNFAAAMAAAA23g");
	var mask_graphics_75 = new cjs.Graphics().p("EgnSAeWMAAAg23MBYXAAAMAAAA23g");
	var mask_graphics_76 = new cjs.Graphics().p("EgiNAeWMAAAg23MBU3AAAMAAAA23g");
	var mask_graphics_77 = new cjs.Graphics().p("EgngAeWMAAAg23MBcFAAAMAAAA23g");
	var mask_graphics_78 = new cjs.Graphics().p("EgpTAcSMAAAg23MBeAAAAMAAAA23g");
	var mask_graphics_79 = new cjs.Graphics().p("EglVAcSMAAAg23MBbIAAAMAAAA23g");
	var mask_graphics_81 = new cjs.Graphics().p("EgnrAcSMAAAg23MBg2AAAMAAAA23g");
	var mask_graphics_82 = new cjs.Graphics().p("EgppAcSMAAAg23MBjjAAAMAAAA23g");
	var mask_graphics_83 = new cjs.Graphics().p("EgsBAcSMAAAg23MBm4AAAMAAAA23g");
	var mask_graphics_84 = new cjs.Graphics().p("EgrUAcSMAAAg23MBnJAAAMAAAA23g");
	var mask_graphics_85 = new cjs.Graphics().p("EgwFAcSMAAAg23MBtfAAAMAAAA23g");
	var mask_graphics_86 = new cjs.Graphics().p("Eg1qAcSMAAAg23MB0oAAAMAAAA23g");
	var mask_graphics_87 = new cjs.Graphics().p("Eg1IAcKMAAAg23MB3mAAAMAAAA23g");
	var mask_graphics_88 = new cjs.Graphics().p("Eg6NAcKMAAAg23MB+QAAAMAAAA23g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(55).to({graphics:mask_graphics_55,x:124.55,y:212.75}).wait(1).to({graphics:mask_graphics_56,x:119.9,y:194.175}).wait(1).to({graphics:mask_graphics_57,x:136.175,y:194.175}).wait(1).to({graphics:mask_graphics_58,x:175.7,y:212.75}).wait(1).to({graphics:mask_graphics_59,x:156.325,y:194.175}).wait(1).to({graphics:mask_graphics_60,x:182.2487,y:194.175}).wait(1).to({graphics:mask_graphics_61,x:189.6131,y:194.175}).wait(1).to({graphics:mask_graphics_62,x:193.4692,y:194.175}).wait(1).to({graphics:mask_graphics_63,x:209.7281,y:194.175}).wait(1).to({graphics:mask_graphics_64,x:214.3523,y:194.175}).wait(1).to({graphics:mask_graphics_65,x:219.7776,y:194.175}).wait(1).to({graphics:mask_graphics_66,x:227.5156,y:194.175}).wait(1).to({graphics:mask_graphics_67,x:235.2419,y:194.175}).wait(1).to({graphics:mask_graphics_68,x:247.582,y:194.175}).wait(1).to({graphics:mask_graphics_69,x:257.6551,y:194.175}).wait(1).to({graphics:mask_graphics_70,x:289.55,y:212.75}).wait(1).to({graphics:mask_graphics_71,x:276.9716,y:194.175}).wait(1).to({graphics:mask_graphics_72,x:283.9206,y:194.175}).wait(1).to({graphics:mask_graphics_73,x:293.1468,y:194.175}).wait(1).to({graphics:mask_graphics_74,x:302.5238,y:194.175}).wait(1).to({graphics:mask_graphics_75,x:314.0566,y:194.175}).wait(1).to({graphics:mask_graphics_76,x:324.1644,y:194.175}).wait(1).to({graphics:mask_graphics_77,x:336.5028,y:194.175}).wait(1).to({graphics:mask_graphics_78,x:337.2669,y:181}).wait(1).to({graphics:mask_graphics_79,x:344.2597,y:181}).wait(2).to({graphics:mask_graphics_81,x:365.9197,y:181}).wait(1).to({graphics:mask_graphics_82,x:370.5724,y:181}).wait(1).to({graphics:mask_graphics_83,x:376.7449,y:181}).wait(1).to({graphics:mask_graphics_84,x:382.9357,y:181}).wait(1).to({graphics:mask_graphics_85,x:392.9771,y:181}).wait(1).to({graphics:mask_graphics_86,x:402.9888,y:181}).wait(1).to({graphics:mask_graphics_87,x:425.4415,y:180.225}).wait(1).to({graphics:mask_graphics_88,x:435.4651,y:180.225}).wait(52));

	// loop
	this.instance_14 = new lib.Tween12("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(488.75,186.15);
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(55).to({_off:false},0).wait(85));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(468.6,203.7,398.4,190.7);
// library properties:
lib.properties = {
	id: '6ABF32B7933F5D439CE070AC08E31968',
	width: 878,
	height: 397,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/agumented charecters2_atlas_.png", id:"agumented charecters2_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6ABF32B7933F5D439CE070AC08E31968'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;