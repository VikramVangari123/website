(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABHGfQhQmChxm2QgFgVAWgEQAWgEAGAVQBrGDBdGzQAFAZgaAFIgIABQgSAAgFgVg");
	this.shape.setTransform(-47.5,19.1,1.593,1.554);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiQGmQgYgJAIgYQCJlsCOmyQAHgVAVAIQAVAJgGAVQh2GBibGfQgGARgPAAQgFAAgHgDg");
	this.shape_1.setTransform(41.3,21.9,1.593,1.554);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AlYDrQgPgQAOgQQBEhJAjhZIgDgIQggh7A0hzQAEgKALgCQAJgBAKAEQAZALAIAhQAEAVgDAlQgGBGgRA2IgLAfQAKAdARAaQARAbAMANQAUAXAUADQAmAFAjg+QAVgjAMghQgXhHADhCQAEhMAng3QAGgIAJgDQAKgDAJAFQAZAQAHAiQAFAWgDAnQgHBPgVA+IgKAcIAKAUQARAgAYANQAbAQAggLQAUgGAUgPQgJgXgFgaQgPhNAUhDIANgkQAJgVAMgLQAOgNARgFQATgGAOALQARAMAGASQAEAOAAAYQgBAygEAjQgKBUgnAwQAYAtAnAcQAYASgRAXQgSAXgXgUQgqgjgbguQgzAjg2gIQg4gIgkg5QgMAYgRAYQgxBDgygDQg3gDgwhDQgOgTgLgVQgnBLg5A6QgIAHgIAAQgHAAgIgHgAERiBQgHALgFAOQgMAjgCAZQgDApAKArIAHgRQAVhBgEhWIgBgGgAAngvQAJgkACgdIADgZQACgTgBgNQgXAyAIBIg");
	this.shape_2.setTransform(-1.2,-50.2,1.593,1.554);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67.2,-87.8,134.6,175.8);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#808183").s().p("Aj7AOQgLgBgBgLQAAgKALAAQBVgECmABQCoAABSgDQAOgBABAPQAAAPgOgBQhTgCinACIiHABQhGAAgugBg");
	this.shape.setTransform(-0.6,1,1.593,1.554);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#808183").s().p("Aj7ANQgLAAgBgLQAAgKALAAQBVgECmABQCoAABSgDQAOgBABAPQAAAPgOgBQhSgDioADIiGABQhHAAgugCg");
	this.shape_1.setTransform(-0.6,-10.3,1.593,1.554);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#59595B").s().p("AiFDIQg4AAgpgkQgqglgEg0IgWkOIJVgEIgaESQgDA0gqAlQgqAkg4AAg");
	this.shape_2.setTransform(0,0,1.593,1.554);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.6,-31,95.3,62.1);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4F4F4").s().p("A13V4QpEpEAAs0QAAszJEpEQJEpEMzAAQM1AAJDJEQJEJEAAMzQAAM0pEJEQpDJEs1AAQszAApEpEg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-198,-198,396,396);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzoJwIAAzfMAnRAAAIAATfg");
	mask.setTransform(125.7,62.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5D15C").s().p("AhQA+QgogFgagWQgZgWADgZQADgaAfgPQAegPAnAFQA3AHBTAeQBjAhgDAXQgDAXhoAJQgtADgjAAQgkAAgagDg");
	this.shape.setTransform(16.9,104.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5D15C").s().p("AAeBUQhQgogrghQgfgYgLggQgLggAQgUQAQgVAiADQAiADAfAYQAqAiA6BEQBDBPgOATQgEAFgLAAQgaAAhDghg");
	this.shape_1.setTransform(50.4,41.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F5D15C").s().p("Ag9A9QhogIgDgXQgDgXBjghQBUgeA1gHQAogFAeAPQAfAPADAaQADAZgZAWQgaAWgoAFQgZADghAAQglAAgvgEg");
	this.shape_2.setTransform(234.4,118.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F5D15C").s().p("AiFB1QgPgRBAhTQA3hHAogjQAegaAigFQAhgEARAUQARAUgJAgQgJAhgfAZQgpAjhOArQhDAmgbAAQgJAAgEgFg");
	this.shape_3.setTransform(210.8,48.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5D15C").s().p("AgsBFQgShYAAg2QAAgoASgcQATgcAZgBQAaABATAcQASAcAAAoQAAA2gSBYQgWBlgXABQgXgBgVhlg");
	this.shape_4.setTransform(126.7,17.1);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,251.4,124.8), null);


// stage content:
(lib.bulb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_27 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(27).call(this.frame_27).wait(1));

	// filment
	this.instance = new lib.Tween6("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(254.4,206.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).to({y:308.8},4,cjs.Ease.quartIn).wait(8));

	// base
	this.instance_1 = new lib.Tween5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(249.5,147.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({y:427.9},6,cjs.Ease.cubicIn).to({startPosition:0},5).wait(12));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("EgjyA3AMAAAgv/MBKFAAAMAAAAv/g");
	var mask_graphics_12 = new cjs.Graphics().p("EgjyAyOMAAAgv/MBKFAAAMAAAAv/g");
	var mask_graphics_13 = new cjs.Graphics().p("EgjyAtcMAAAgv+MBKFAAAMAAAAv+g");
	var mask_graphics_14 = new cjs.Graphics().p("EgjyAoqMAAAgv+MBKFAAAMAAAAv+g");
	var mask_graphics_15 = new cjs.Graphics().p("EgjyAj4MAAAgv+MBKFAAAMAAAAv+g");
	var mask_graphics_16 = new cjs.Graphics().p("EgjyAfGMAAAgv+MBKFAAAMAAAAv+g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:245.1,y:352.1}).wait(1).to({graphics:mask_graphics_12,x:245.1,y:321.5}).wait(1).to({graphics:mask_graphics_13,x:245.1,y:290.9}).wait(1).to({graphics:mask_graphics_14,x:245.1,y:260.3}).wait(1).to({graphics:mask_graphics_15,x:245.1,y:229.7}).wait(1).to({graphics:mask_graphics_16,x:245.1,y:199.1}).wait(12));

	// glass
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#808183").s().p("AkTQNIhCj3QhBjuiyizQhyhxg+iUQhBiXAAinQgBioBBiaQA/iVByhzQBzhzCUg/QCahCCnAAQCoAACZBBQCVA/ByByQBzBzA+CUQBBCaAACoQAACqhCCaQhACWh1ByQhaBZg/BrQhABsghB4Ig/Dqg");
	this.shape.setTransform(250.3,253.1,1.593,1.554);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(11).to({_off:false},0).to({_off:true},10).wait(7));

	// glow
	this.instance_2 = new lib.ClipGroup();
	this.instance_2.parent = this;
	this.instance_2.setTransform(250.1,111.5,1.662,1.662,0,0,0,125.7,62.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({_off:false},0).wait(5));

	// glass yellow
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5D15C").s().p("AkTQNIhCj3QhBjuiyizQhyhxg+iUQhBiXAAinQgBioBBiaQA/iVByhzQBzhzCUg/QCahCCnAAQCoAACZBBQCVA/ByByQBzBzA+CUQBBCaAACoQAACqhCCaQhACWh1ByQhaBZg/BrQhABsghB4Ig/Dqg");
	this.shape_1.setTransform(250.3,253.1,1.593,1.554);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(21).to({_off:false},0).wait(7));

	// circle
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(250,290,0.04,0.04);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1,scaleY:1},5,cjs.Ease.quadIn).to({startPosition:0},11).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(492.1,532.1,15.9,15.9);
// library properties:
lib.properties = {
	id: 'FF537AC0C40549C48F1C608498008AD1',
	width: 500,
	height: 500,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FF537AC0C40549C48F1C608498008AD1'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;